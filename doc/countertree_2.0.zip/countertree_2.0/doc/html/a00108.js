var a00108 =
[
    [ "base_node", "a00003.html", "a00003" ],
    [ "red", "a00108.html#a1e959cb37ceb26b9d39f524b1c4481e2a54b3ed300cd0e30c48b5dc8779c70621", null ],
    [ "black", "a00108.html#a1e959cb37ceb26b9d39f524b1c4481e2af702cde9a58ec94dad3e9e56ba21a88f", null ]
];