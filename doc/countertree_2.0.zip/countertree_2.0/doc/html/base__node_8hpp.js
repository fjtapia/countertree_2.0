var base__node_8hpp =
[
    [ "base_node", "structcountertree_1_1forest_1_1base__node.html", "structcountertree_1_1forest_1_1base__node" ],
    [ "red", "base__node_8hpp.html#a1e959cb37ceb26b9d39f524b1c4481e2a54b3ed300cd0e30c48b5dc8779c70621", null ],
    [ "black", "base__node_8hpp.html#a1e959cb37ceb26b9d39f524b1c4481e2af702cde9a58ec94dad3e9e56ba21a88f", null ]
];