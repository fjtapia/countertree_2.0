var searchData=
[
  ['definitions_2ehpp',['definitions.hpp',['../definitions_8hpp.html',1,'']]]
];
