var searchData=
[
  ['unique_5fobject',['unique_object',['../classcountertree_1_1common_1_1unique__object.html',1,'countertree::common']]],
  ['unique_5fobject_3c_20countertree_3a_3aalloc_3a_3apool32_20_3e',['unique_object&lt; countertree::alloc::pool32 &gt;',['../classcountertree_1_1common_1_1unique__object.html',1,'countertree::common']]],
  ['unique_5fobject_3c_20countertree_3a_3aalloc_3a_3apool64_20_3e',['unique_object&lt; countertree::alloc::pool64 &gt;',['../classcountertree_1_1common_1_1unique__object.html',1,'countertree::common']]]
];
