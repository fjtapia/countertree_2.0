var searchData=
[
  ['black',['black',['../namespacecountertree_1_1forest.html#a1e959cb37ceb26b9d39f524b1c4481e2af702cde9a58ec94dad3e9e56ba21a88f',1,'countertree::forest']]]
];
