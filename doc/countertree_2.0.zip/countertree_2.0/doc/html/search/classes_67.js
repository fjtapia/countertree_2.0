var searchData=
[
  ['global_5falloc_5fcnc',['global_alloc_cnc',['../classcountertree_1_1common_1_1global__alloc__cnc.html',1,'countertree::common']]]
];
