var searchData=
[
  ['noalias',['NOALIAS',['../definitions_8hpp.html#aa8a0498c61178c1ad0d57c74ec280b24',1,'definitions.hpp']]],
  ['noexcept',['NOEXCEPT',['../definitions_8hpp.html#a10a59554805ac7ce3905fd3540f98137',1,'definitions.hpp']]]
];
