var searchData=
[
  ['heap32',['heap32',['../structcountertree_1_1alloc_1_1heap32.html',1,'countertree::alloc']]],
  ['heap64',['heap64',['../structcountertree_1_1alloc_1_1heap64.html',1,'countertree::alloc']]]
];
