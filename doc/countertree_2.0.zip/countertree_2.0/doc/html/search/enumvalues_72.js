var searchData=
[
  ['red',['red',['../namespacecountertree_1_1forest.html#a1e959cb37ceb26b9d39f524b1c4481e2a54b3ed300cd0e30c48b5dc8779c70621',1,'countertree::forest']]]
];
