var a00004 =
[
    [ "value_type", "a00004.html#aeb1b1f450d098e8a136c4e4c131632d8", null ],
    [ "basic_heap32", "a00004.html#a6b31c710066d0136e8d5ca066896c962", null ],
    [ "~basic_heap32", "a00004.html#a7f3dad411915c86c16394009d3623944", null ],
    [ "allocate", "a00004.html#ae90b3697a247711bd14eca0b554635bd", null ],
    [ "capacity", "a00004.html#a9d11e869b78868d05bb3907f96f331e1", null ],
    [ "create_son", "a00004.html#a0b74cbf24c182814ee071195cdbca5be", null ],
    [ "deallocate", "a00004.html#a4ddeba7b8a4d04960494aa2910fafcba", null ],
    [ "is_empty", "a00004.html#adced3598d62afeb2e36a5b6549aee623", null ],
    [ "is_full", "a00004.html#a7d29bd0e62036ca5d2e675449e74c378", null ],
    [ "read_bit", "a00004.html#ae0422382e81a62ed94558add141501f9", null ],
    [ "SIZEOF", "a00004.html#af22108918684b8829212bc9dafe664f4", null ],
    [ "Cursor", "a00004.html#a10d44235f37b29774feac5657c6757d6", null ],
    [ "L", "a00004.html#acb95071029f97a49126d008028410c7d", null ],
    [ "NElem", "a00004.html#ae6346980f110cd33fcaa5aeb0fa821c7", null ],
    [ "NElemMax", "a00004.html#a7bdf105822612731309995b2bd12011b", null ],
    [ "NLevel", "a00004.html#a40c119f1f2a38467c196e935c40e18ef", null ],
    [ "Ptr", "a00004.html#a3de56b9a49318b5dc3c58889eee5b1e2", null ]
];