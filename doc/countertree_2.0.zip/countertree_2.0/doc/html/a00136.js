var a00136 =
[
    [ "time_point", "a00136.html#a143e26ba630e2df409e424ea6112f486", null ],
    [ "now", "a00136.html#a8e37212c88f1d758c62f932c7d326c97", null ],
    [ "subtract_time", "a00136.html#a3538a835415e1b42860cb14ad76ad258", null ]
];