var a00106 =
[
    [ "AlignSize64", "a00106.html#a73aff125ab123fa63315886d9c2d82c3", null ],
    [ "BitsAlign64", "a00106.html#af60ae135a3d5cd48958ede498d670547", null ],
    [ "LS1B_64", "a00106.html#a22e775122a614346376f7ae52119e693", null ],
    [ "Mask64", "a00106.html#a839b77fd71697968307144c0acc024f8", null ],
    [ "MS1B_64", "a00106.html#af4971fafd9b3bf75d36b1ded439d49e8", null ],
    [ "MS1B_64< 0 >", "a00106.html#a499d84c3ebef59a91bbab2d15f4dd070", null ],
    [ "ReadBit64", "a00106.html#ae400520cbff37c118d400ed78df6db7d", null ],
    [ "ResetBit64", "a00106.html#ad3d04638399460b376fd4ce54a9f7c0a", null ],
    [ "SetBit64", "a00106.html#a36c94283d94ff199058fca14b054d26b", null ],
    [ "SizeAligned64", "a00106.html#a9b8fe7dd909a927c91c4f11798a58b82", null ]
];