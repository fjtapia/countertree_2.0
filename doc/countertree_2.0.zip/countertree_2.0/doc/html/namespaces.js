var namespaces =
[
    [ "countertree", "namespacecountertree.html", "namespacecountertree" ],
    [ "std", "namespacestd.html", null ]
];