var a00018 =
[
    [ "difference_type", "a00018.html#add80b46ccd30bc9e87061dd776c1e214", null ],
    [ "size_type", "a00018.html#ac63fa8afb26aa9cc97a9407eea373f9e", null ],
    [ "value_type", "a00018.html#a077f5e05de4865603e9c57243a12c402", null ],
    [ "basic_suballoc64", "a00018.html#a81457356ba773b03a6954de3ff2f95c3", null ],
    [ "basic_suballoc64", "a00018.html#ae7eb2d5e7712e7cd096e7bfc8701f932", null ],
    [ "basic_suballoc64", "a00018.html#a99a45e058b512ffc262eb3cfc9a2df3c", null ]
];