var a00070 =
[
    [ "config_lock", "a00070.html#a16d8e6e1a73fe5086ddecac1f76b9e77", null ],
    [ "difference_type", "a00070.html#a542a19e99e1133447df7b50c049da4f6", null ],
    [ "lock_data", "a00070.html#a7053f7229dc7434bb0edb1562ffd9f68", null ],
    [ "mylock", "a00070.html#a463bb4608c011189504dac2beb9c6a99", null ],
    [ "singleton", "a00070.html#a93dedc8e057867478e88b6a93cfdc055", null ],
    [ "size_type", "a00070.html#a4a2c29d342d626187ffa2525cb9ef676", null ],
    [ "pool64", "a00070.html#a8f4c1d836464c955be89bf22c5ebec2f", null ],
    [ "~pool64", "a00070.html#a1d6451856874cd0054fc36f65e1f9f65", null ],
    [ "allocate", "a00070.html#a4ad6d6decea68e99bed14d5d13c872cb", null ],
    [ "capacity", "a00070.html#ab468a5c94d39be94eb3ab4a4831cc4c8", null ],
    [ "clear", "a00070.html#a6d057a5888aadf5ac413a374b1057998", null ],
    [ "deallocate", "a00070.html#aa52d3f74948dc271bb9256491c24885e", null ],
    [ "size", "a00070.html#a79435496f9c95edb6858870835037d63", null ]
];