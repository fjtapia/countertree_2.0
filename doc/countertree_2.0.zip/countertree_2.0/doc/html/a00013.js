var a00013 =
[
    [ "difference_type", "a00013.html#a0cec9e870ce3ae745b62b4b5400dac64", null ],
    [ "size_type", "a00013.html#a5286aef45b2a9ea42b70a6831027aafd", null ],
    [ "value_type", "a00013.html#acf950adbaa7dc4f0290009d539941eaa", null ],
    [ "basic_suballoc64_cnc", "a00013.html#ab606317e9fa35e962d0332c6643048fe", null ],
    [ "basic_suballoc64_cnc", "a00013.html#a01be39fe82135a3443ebbbda6153c764", null ],
    [ "basic_suballoc64_cnc", "a00013.html#a40c8836da05c7548e117cba8ddf81f06", null ]
];