var a00104 =
[
    [ "unique_object", "a00104.html#ac58dba04ad3be2924983d330d6daec80", null ],
    [ "~unique_object", "a00104.html#aaa3209d3dbea1887fb81c78ed290bafc", null ],
    [ "operator()", "a00104.html#a7ed837fea253ff122b641e3068cf5c27", null ],
    [ "operator*", "a00104.html#a55531b3630bc2ce6d4f89f0e7495a86e", null ],
    [ "operator->", "a00104.html#a64be1a2c1c43c1516acf5f376c1b9ba9", null ]
];