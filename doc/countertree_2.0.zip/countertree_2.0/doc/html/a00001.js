var a00001 =
[
    [ "barrier_data_cnc", "a00001.html#a54316689eac73789ff3ae45b12819fd5", null ],
    [ "M", "a00001.html#a245a08a01afa6be8b4f979fcfec2fa20", null ],
    [ "NR", "a00001.html#a56048f1d914fa226adff9f403ff04fc9", null ]
];