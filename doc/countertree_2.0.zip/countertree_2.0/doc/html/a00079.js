var a00079 =
[
    [ "base_other", "a00079.html#a8e3b7c021819ce5da88330eea11558b8", null ],
    [ "other", "a00079.html#ac21ad10ac9aebc9b93273610d8c9b306", null ]
];