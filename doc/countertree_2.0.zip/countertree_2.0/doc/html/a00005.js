var a00005 =
[
    [ "value_type", "a00005.html#a528e0028222dee59e3c7e77a3c2060ba", null ],
    [ "basic_heap64", "a00005.html#a372a47c261cdd952282bd611bf6499dc", null ],
    [ "~basic_heap64", "a00005.html#a2f06a29b237ad365b78240086a8258ff", null ],
    [ "allocate", "a00005.html#ab283d8f2125f36aa15868f1890c2df57", null ],
    [ "capacity", "a00005.html#aeed8e6c35f53ebac12fd3383d0dc87c0", null ],
    [ "create_son", "a00005.html#a107582c4e9ce7d4b0135475d58f8cf90", null ],
    [ "deallocate", "a00005.html#af076fc4f6fdff7c8e8b2e81245abb136", null ],
    [ "is_empty", "a00005.html#a942a277ecd12d58d3b9b43ca161de4ce", null ],
    [ "is_full", "a00005.html#af4ab3d33b978c8b176e67abf517c9cf6", null ],
    [ "read_bit", "a00005.html#a8495a6fb405d9bf12181c1c448748381", null ],
    [ "SIZEOF", "a00005.html#aa3092cb67183f5a9670733855de4faf9", null ],
    [ "Cursor", "a00005.html#a98e07851d27d338f8088398a7eaead0d", null ],
    [ "L", "a00005.html#a51a1a9607a7a46bfd5e2442270803e51", null ],
    [ "NElem", "a00005.html#a885b3aac8de51c8bb5aec8d25db9bbdd", null ],
    [ "NElemMax", "a00005.html#a4f4d5a4ed7a4aae698fadd16d1184b4f", null ],
    [ "NLevel", "a00005.html#a40d0eb692a91c1e29fe907702d8bcfe4", null ],
    [ "Ptr", "a00005.html#af53286c24bc03d3a2445eb9e97c903e2", null ]
];