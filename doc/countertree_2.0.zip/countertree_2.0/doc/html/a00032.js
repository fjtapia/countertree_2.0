var a00032 =
[
    [ "barrier_data", "a00032.html#a8355673df8720172122b86ac7937c3dd", null ],
    [ "barrier_modify", "a00032.html#a7cea2741c075afd41bc1318c876cab23", null ],
    [ "barrier_read", "a00032.html#a0cd1e671d7d27a22f005eaadc6e1ac2c", null ]
];