var definitions_8hpp =
[
    [ "ASSERT", "definitions_8hpp.html#af343b20373ba49a92fce523e948f2ab3", null ],
    [ "CONSTEXPR", "definitions_8hpp.html#acaa06fbc27c59926a41e7575667e5280", null ],
    [ "NOALIAS", "definitions_8hpp.html#aa8a0498c61178c1ad0d57c74ec280b24", null ],
    [ "NOEXCEPT", "definitions_8hpp.html#a10a59554805ac7ce3905fd3540f98137", null ],
    [ "RESTRICT", "definitions_8hpp.html#aae3356b63849abbe8789dd41648ee90a", null ]
];