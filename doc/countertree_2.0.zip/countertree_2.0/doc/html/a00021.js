var a00021 =
[
    [ "bitfield_t", "a00021.html#a24edbd6a7641c36bffaf4b5de531a13a", null ],
    [ "difference_type", "a00021.html#a853b0d5182b5dfd88f250e8c21c4e656", null ],
    [ "size_type", "a00021.html#ad6d2960dcd967cae6dceae4f74c840b0", null ]
];