var a00021 =
[
    [ "branch", "a00021.html#a0fbf55ef0859f5cc4c95980603dd4742", null ],
    [ "disconnect_node", "a00021.html#a7c4df2fcfcac0cfd399098afa6948d2c", null ],
    [ "insert_node", "a00021.html#a9660b6fae3e788ae83e1d6c85560c696", null ],
    [ "n_nodes", "a00021.html#a622ef881e099124f0888c26f8fe24cc9", null ],
    [ "pointer_Cod", "a00021.html#a06ad77d327e4a8d27c47e97415915746", null ],
    [ "pointer_father", "a00021.html#aa3b398eb73379a8068964e37350b1037", null ],
    [ "rotate_left_aligned", "a00021.html#a4814b2279d0864aaf83072a608185b67", null ],
    [ "rotate_left_not_aligned", "a00021.html#aebe6cb61673f06f99997e808fe6acc76", null ],
    [ "rotate_right_aligned", "a00021.html#aa57de4de45ddc1fdc04ec35e502c1223", null ],
    [ "rotate_right_not_aligned", "a00021.html#a6a7455ece08403c2c8c30eaecc7d68c9", null ],
    [ "ppblack", "a00021.html#afa86c54ad54c92e2dc5f2a49c3f0f1e1", null ]
];