INSTALLATION INSTRUCTIONS
--------------------------

The easy option is to copy the folder srs/countertree in the folder boost, where are 
located the Boost libraries. 

If this is not possible, create a folder boost, and copy inside the folder 
countertree, and include the path in the list of folders for to find the include files.

The folders benchmarks_GCC_4.7, benchmarks_CLANG_3.3 and benchmarks_VC12CTP, 
contain the programs for to generate the results showed in the web pages. 

Take care about the results, they can vary a lot depending of the machine, 
and mainly of the size of the cache memory.

My idea when create this library is to be useful to the community of programmers. 

I need you for to improve the library.  If you find any fail or problem, 
or have an idea or suggestion, please, mail me, and help me to reach the 
final objective, to be useful.


Francisco José Tapia
fjtapia@gmail.com
