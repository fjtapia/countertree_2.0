///--------------------------------------------------------------------------
// FILE : node_debug.hpp
//
// DESCRIPTION : This class contains the code for to print and debug the
//  class node
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TREE_NODE_DEBUG_HPP
#define __CNTREE_TREE_NODE_DEBUG_HPP

#include <iostream>
#include <boost/cntree/tree/node.hpp>



#if __DEBUG_CNTREE != 0
namespace cntree
{
namespace tree
{
//##########################################################################
//                                                                        ##
//                      F U N C T I O N S                                 ##
//                                                                        ##
//##########################################################################

/*
template <class T>
std::ostream & operator << (std::ostream &salida, const node<T> &N );

template <class T>
std::ostream &  print_tree_struct (std::ostream & out, node<T> *P);

template <class T>
std::ostream &  internal_print_tree_struct (std::ostream & out, node<T> *P);

template <class T>
bool Colombo ( node<T> *Father, node<T> *P1, unsigned Deep,
               bool BlackFather , std::ostream & out = std::cout);
*/
//------------------------------------------------------------------------
//  function : operator<<
/// @brief Print operator for the node
/// @param [in/out] salida : ostream where print
/// @param [in] N : node to print
/// @return reference to salida after the printing
/// @remarks Only for debugger purpose
//------------------------------------------------------------------------
template <class T>
std::ostream & operator << (std::ostream &salida,
                            const node<T> & N )
{   //------------ Inicio ------------------------
    salida<<"["<<( void*) (&N)<<"] ";
    salida<<"left:";
    if( N.left != NULL ) salida<<N.left;
    else                 salida<<"NULL";
    salida<<" right:";
    if ( N.right != NULL ) salida<<N.right;
    else                   salida<<"NULL" ;
    salida<<" up:";
    if ( N.up != NULL )  salida<<N.up;
    else                 salida<<"NULL" ;
    salida<<" N:"<<N.N();
    salida<<" COLOR:";
    if (N.is_black() ) salida <<"BLACK";
    else               salida <<"RED";
    salida <<" data:"<<N.data ;
    return salida ;
};

//------------------------------------------------------------------------
//  function : internal_print_tree_struct
/// @brief Print all the node struct, with recursive calls
/// @param [in/out] out : ostream where print the information of the tree
///                       structure
/// @param [in] P : Pointer to node
/// @return reference to the ostream after the printing
/// @remarks Only for debugger purpose
//------------------------------------------------------------------------
template <class T>
std::ostream &  internal_print_tree_struct (std::ostream & out, node<T> *P)
{   //------------ Inicio ------------------------
    if ( P == NULL ) return out;
    if ( P->left == NULL and P->right == NULL) return out;

    out<<(*P)<<std::endl;
    if ( P->left == NULL) out<<"left NULL\n";
    else out<<"left "<<(*P->left)<<std::endl;
    if ( P->right == NULL) out<<"right NULL\n";
    else out<<"right "<<(*P->right)<<std::endl;
    out<<"---------------------------------------------------------------\n";
    if ( P->left  != NULL) internal_print_tree_struct (out, P->left);
    if ( P->right != NULL) internal_print_tree_struct (out, P->right);
    return out ;
};

//------------------------------------------------------------------------
//  function :print_tree_struct
/// @brief This function print the node struct beginning in P
/// @param [in/out] out : ostream where print the information of the tree
///                       structure
/// @param [in] P : Pointer to node
/// @return reference to the ostream after the printing
/// @remarks Only for debugger purpose
//------------------------------------------------------------------------
template <class T>
std::ostream &  print_tree_struct (std::ostream & out, node<T> * P )
{	//------------ Inicio ------------------------
    out<<"                   U P P E R   L E V E L\n";
    out<<"--------------------------------------------------------------------------\n";
    if ( P == NULL ) out<<"NULL\n";
    else
    {   if ( P->left == NULL and P->right == NULL)
            out<<(*P)<<std::endl;
        else internal_print_tree_struct (out, P ) ;
    };
    out<<"\n                   L O W E R   L E V E L \n";
    out<<"#############################################################################\n\n";
    return out ;
};
//------------------------------------------------------------------------
//  function : Colombo
/// @brief Examine  the errors in the node struct
/// @param [in] Father : Pointer to the father
/// @param [in] P1 : Pointer to the node
/// @param [in] Deep : Deep level
/// @param [in] BlackFather : Indicate if the father is Black
/// @param [in] out : ostream where print the information
/// @return bool (true : OK, false : Error in the struct)
/// @remarks Only for debugger purpose
//------------------------------------------------------------------------
template <class T>
bool Colombo ( node<T> *Father,
               node<T> *P1,
               unsigned Deep,
               bool BlackFather ,
               std::ostream & out= std::cout     )
{   //----------------- Inicio ---------------------------------
   if ( Deep == 0 )
    {   //cout<<"Deep 0 \n" ;
        return ( P1 == NULL ) ;
    };
    if ( P1->up != Father )
    {   out<<"El puntero padre no coincide\n";
        return false ;
    }
    if (P1 == NULL )
    {   out<<"El puntero recibido es NULL \n" ;
        return false ;
    };
    if ( not BlackFather and  P1->is_red()  )
    {   out<<"Hay dos nodos rojos seguidos\n";
        out<<(*P1)<<std::endl ;
        return false ;
    };
    //-------------------------------------------------------------------
    // Solo los nodos de profundidad 1 pueden tener punteros NULL
    //------------------------------------------------------------------
    if ( Deep == 1 )
    {   if (P1->is_red() and (P1->left != NULL or P1->right != NULL))
        {   out<<" Un nodo rojo de profundidad 1 no tiene" ;
            out<<" los dos punteros NULL \n" ;
            out<<*P1 ;
            return false ;
        };
    }
    else
    {   if ( P1->left == NULL or P1->right == NULL )
        {   out<<"node de profundidad "<<Deep ;
            out<<"  con punteros NULL \n" ;
            out<<*P1 ;
            return false ;
        };
    };
    if ( Deep == 1 and P1->left == NULL and P1->right == NULL )
        return true ;
    //-------------------------------------------------------------------
    // Llamadas recursivas
    //------------------------------------------------------------------
    bool is_black =  P1->is_black()  ;
    if ( P1->left != NULL )
    {   if ( P1->left->is_black()  )
        {   if ( not Colombo( P1,P1->left, Deep -1, is_black,out)) return false ;
        }
        else
        {   if (not Colombo ( P1,P1->left, Deep, is_black,out))   return false ;
        };
    };
    if ( P1->right != NULL )
    {   if ( P1->right->is_black()  )
        {   if (not Colombo (P1, P1->right, Deep -1, is_black,out ))
                return false ;
        }
        else
        {   if ( not Colombo ( P1, P1->right, Deep, is_black,out ) )
                return false ;
        };
    };
    return true ;
};
}; //-------------------- end namespace tools ----------------------------------------
}; // -------------------- end namespace cntree ---------------------------------------
#endif
#endif
