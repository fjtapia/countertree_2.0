//----------------------------------------------------------------------------
/// @file   basic_tree.hpp
/// @brief  This file contains the class basic_tree used  in the Iterator and
///         const_iterator definition
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TREE_BASIC_TREE_HPP
#define __CNTREE_TREE_BASIC_TREE_HPP

#include <boost/cntree/tree/definitions.hpp>
#include <boost/cntree/tree/node.hpp>
#include <iterator>

namespace cntree
{
namespace tree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #            B A S I C _ T R E E                   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @struct  basic_tree
/// @brief  This struct is for  the iterators, the number of
///         elements and the pointers to the first and last nodes of the tree
///
/// @remarks
//----------------------------------------------------------------
template <class T>
struct basic_tree
{
    //-------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //-------------------------------------------------------------------------
    typedef  node<T> *         pnode ;
    typedef  const node<T>*    const_pnode   ;

    //---------------------------------------------------------------------
    //                  V A R I A B L E S
    //---------------------------------------------------------------------
    pnode root ;
    pnode first;
    pnode last ;

    //--------------------------------------------------------------------
    //                  F U N C T I O N S
    //--------------------------------------------------------------------
    basic_tree ( pnode r1 = NULL, pnode f1=NULL, pnode l1=NULL);
    basic_tree ( const basic_tree &B);

    size_type n_elem ( void) const;

    pnode       get_first ( void);
    const_pnode get_first ( void) const;

    pnode       get_last  ( void);
    const_pnode get_last  ( void) const;

//###########################################################################
};//        E N D    O F    B A S I C _ T R E E     S T R U C T
//##########################################################################


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #            B A S I C _ T R E E                   #             ##
//       #                                                  #             ##
//       #             F U N C T I O N S                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : basic_tree
/// @param [in] r1 : pointer to the root of the structure
/// @param [in] f1 : pointer to the first elemet of the structure
/// @param [in] l1 : pointer to the last element of the structure
//----------------------------------------------------------------
template <typename T>
inline basic_tree<T>::basic_tree ( pnode r1 , pnode f1, pnode l1)
                      :root(r1),first(f1),last(l1){};

//----------------------------------------------------------------
//  function : basic_tree
/// @param [in] B : basic_tree structure to copy
//----------------------------------------------------------------
template <typename T>
inline basic_tree<T>::basic_tree ( const basic_tree &B)
                      :root(B.root),first(B.first),last(B.last){};

//----------------------------------------------------------------
//  function : n_elem
/// @brief return the number of elements in the vector_tree
/// @return number of elements in the vector_tree
//----------------------------------------------------------------
template <typename T>
inline size_type basic_tree<T>::n_elem ( void) const
{   return node<T>::nd(root);
};

//------------------------------------------------------------------------
//  function : get_first
/// @brief return a pointer of the first node to the vector_tree
/// @param [in] none
/// @return pointer
/// @remarks This is only for to implement the interface of basic_tree
//------------------------------------------------------------------------
template <typename T>
inline typename basic_tree<T>::pnode
basic_tree<T>::get_first ( void)
{   return first ;
} ;

//------------------------------------------------------------------------
//  function : get_first
/// @brief return a  const pointer of the first node to the vector_tree
/// @param [in] none
/// @return pointer
/// @remarks This is only for to implement the interface of basic_tree
//------------------------------------------------------------------------
template <typename T>
inline typename basic_tree<T>::const_pnode
basic_tree<T>::get_first ( void) const
{   return first ;
} ;

//------------------------------------------------------------------------
//  function : get_last
/// @brief return a pointer of the last node to the vector_tree
/// @param [in] none
/// @return pointer
/// @remarks This is only for to implement the interface of basic_tree
//------------------------------------------------------------------------
template <typename T>
inline typename basic_tree<T>::pnode
basic_tree<T>::get_last  ( void)
{   return last  ;
} ;

//------------------------------------------------------------------------
//  function : get_last
/// @brief return a  const pointer of the first node to the vector_tree
/// @param [in] none
/// @return pointer
/// @remarks This is only for to implement the interface of basic_tree
//------------------------------------------------------------------------
template <typename T>
inline typename  basic_tree<T>::const_pnode
basic_tree<T>::get_last  ( void) const
{   return last  ;
} ;

//########################################################################
};//     E N D     N A M E S P A C E     T O O L S
//########################################################################

//########################################################################
};//     E N D     N A M E S P A C E     C N T R E E
//########################################################################
#endif
