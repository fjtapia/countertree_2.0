///------------------------------------------------------------------------------
// FILE : Config.h
//
// DESCRIPTION : This file contains the definition of the data formats used
//  in the impementation of tree234 and all the classes related
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TREE_CONFIG_HPP
#define __CNTREE_TREE_CONFIG_HPP

#include <limits>
//#include <stdint.h>
#include <boost/cstdint.hpp>
#include <ciso646>
#include <cassert>

//------------------------------------------------------------------
// if __DEBUG_CNTREE is defined , the compilation is done checking all
// the parameters of  every functions, and lost around 20% of speed
// This must be the first line of code in the program
// You have 2 levels of debug
// 1 - Checking  the parameters of  the functions, and if error
//     raise an exception ( default )
// 0 - No debug
//-------------------------------------------------------------------
#ifndef __DEBUG_CNTREE
#define __DEBUG_CNTREE 0
#endif

namespace cntree
{
namespace tree
{

//-----------------------------------------------------------------
// Public data definitions
//-----------------------------------------------------------------
const unsigned NByte = sizeof(size_t) ;
//----------------------------------------------------------
//    32 bits compiler
//----------------------------------------------------------
template <unsigned NByte >
struct Conf
{   //--------------- Type definition--------------
    typedef int32_t  size_type;
    typedef int32_t  difference_type ;
    typedef uint32_t bitfield_t ;
    static const uint32_t  n_bits_number = 31 ;
    static const uint32_t  n_bits_max = 31 ;
    static const uint32_t  MAX = 0xFFFFFFFFU ;
    //enum { n_bits_number = 31 };
};
//----------------------------------------------------------
//    64 bits compiler
//----------------------------------------------------------
template < >
struct Conf<8>
{   //------Type definition -------------
    typedef int64_t  size_type;
    typedef int64_t  difference_type;
    typedef uint64_t bitfield_t ;
    //enum{  n_bits_number = 63 };
    static const uint32_t n_bits_number = 63;
    static const uint32_t n_bits_max = 63;
    static const uint64_t MAX = 0xFFFFFFFFFFFFFFFFULL ;
};
//static const uint64_t MAX64 = std::numeric_limits<uint64_t>::max() ;
//static const uint32_t MAX32 = std::numeric_limits<uint32_t>::max() ;
static const uint64_t MAX64 = Conf<8>::MAX ;
static const uint32_t MAX32 = Conf<4>::MAX ;


typedef Conf<NByte>::size_type       size_type ;
typedef Conf<NByte>::difference_type difference_type ;
static const uint32_t n_bits_max = Conf<NByte>::n_bits_max ;

}; //------------ End namespace tools ------------------------------------
}; //-------------------- End namespace cntree ----------------------------
#endif
