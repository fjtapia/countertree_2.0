//----------------------------------------------------------------------------
/// @file   node.hpp
/// @brief  This file contains the implementation of the node in the countertree
///         data structure
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TOOLS_NODE_HPP
#define __CNTREE_TOOLS_NODE_HPP

#include <stdexcept>
#include <boost/cntree/tree/definitions.hpp>
#include <boost/cntree/tree/config.hpp>
#include <boost/cntree/tree/num_color.hpp>

namespace cntree
{
namespace tree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #           C L A S S        N O D E               #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  node
/// @brief  This class represent a node of the tree
//
/// @remarks
//----------------------------------------------------------------
template <typename T>
struct node
{   //------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //------------------------------------------------------------------------
    typedef Conf<NByte>::bitfield_t  bitfield_t ;
    typedef       node <T> *            pnode ;
	typedef const node <T> *            const_pnode    ;
	typedef       node <T> **           address_pnode ;
	typedef       node <T> &            refnode   ;
	typedef const node <T> &            const_refnode ;

    //-------------------------------------------------------------------------
    //                       V A R I A B L E S
    //-------------------------------------------------------------------------
    pnode left ;
    pnode right;
    pnode up   ;
    //bitfield_t  N : Conf<NByte>::n_bits_number ;
    //unsigned color :1;
    num_color N ;
    T data ;

    //--------------------------------------------------------------------------
    //        C O N S T R U C T O R , D E S T R U C T O R
    //--------------------------------------------------------------------------
    node ( const T & Dt = T()) ;
    node ( const_refnode N1 );

    //--------------------------------------------------------------------------
    //         O P E R A T O R = , I N I T , R E M O V E _ C O N S T
    //--------------------------------------------------------------------------
    refnode  operator =  ( const_refnode Nd);
    void     init        ( void );
    pnode    remove_const( void) const;


    //--------------------------------------------------------------------------
    //  I S _ B L A C K , I S _ R E D , S E T _ B L A C K , S E T _ R E D
    //--------------------------------------------------------------------------
    bool is_black  ( void ) const;
    bool is_red    ( void ) const;
    void set_black ( void );
    void set_red   ( void );
    bool color ( void ) const ;
    void color ( bool color1);


    //--------------------------------------------------------------------------
    //            P R E V I O U S , N E X T , S H I F T
    //--------------------------------------------------------------------------
    pnode   previous  ( void );
    pnode   next      ( void );
    pnode   shift     ( size_type NDesp );

    //--------------------------------------------------------------------------
    //                G E T T I N G   I N F O R M A T I O N
    //--------------------------------------------------------------------------
            size_type get_pos ( void ) const;
            size_type n_left ( void )const;
            size_type n_right ( void )const;
    static  size_type nd( const_pnode P);

    //--------------------------------------------------------------------------
    //          S W A P P I N G   N O D E S
    //--------------------------------------------------------------------------
    static void swap_node ( address_pnode   PP1, address_pnode   PP2);
    static void swap_contiguous_left ( address_pnode   PPup);

    //--------------------------------------------------------------------------
    //                       R O T A T I O N S
    //--------------------------------------------------------------------------
    static void rotate_left_aligned      ( address_pnode   PPup );
    static void rotate_left_not_aligned  ( address_pnode   PPup );
    static void rotate_right_aligned     ( address_pnode   PPup );
    static void rotate_right_not_aligned ( address_pnode   PPup );

//###################################################################
};//         E N D      C L A S S      N O D E
//###################################################################


//##########################################################################
//                                                                        ##
//        C O N S T R U C T O R , D E S T R U C T O R                     ##
//                                                                        ##
//             O P E R A T O R = , I N I T                                ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : node
/// @brief Constructor
/// @param [in] DT : Value to copy in the node. By default the empty
///                  constructor of the value
//------------------------------------------------------------------------
template <typename T>
inline node<T>::node ( const T &Dt ) :
left(NULL),right(NULL),up(NULL),data(Dt){ };

//------------------------------------------------------------------------
//  function : node
/// @brief Copy constructor. We copy the data, color and counter, but
///        don't copy the pnodes
/// @param [in] N1 : reference const  to the object to be copied
//------------------------------------------------------------------------
template <typename T>
inline node<T>::node ( const_refnode N1 ):
left(NULL),right(NULL),up(NULL),N(N1.N),data(N1.data){};

//------------------------------------------------------------------------
//  function : operator=
/// @brief Asignation operator
/// @param [in] Nd : node to be copied
/// @return reference to the object after the copy
/// @remarks This function copy the data, color and counter , but don't
///          copy the pnodes
//------------------------------------------------------------------------
template <typename T>
inline typename node<T>::refnode  node<T>::operator = ( const_refnode Nd)
{   //------------------ begin -------------------
    N.copy ( Nd.N);
    data= Nd.data;
    return *this ;
};

//------------------------------------------------------------------------
//  function : init
/// @brief Initialize the node, but don't modify the data
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::init ( void )
{   left =right=up=NULL;
    N = 1 ;
    set_red() ;
};
//------------------------------------------------------------------------
//  function : remove_const
/// @brief Generate a pnode from a const node<T>*
/// @param [in] none
/// @return Pointer
//------------------------------------------------------------------------
template <typename T>
inline typename node<T>::pnode  node<T>::remove_const ( void) const
{   return  const_cast < pnode >(this );
};

//##########################################################################
//                                                                        ##
//                         C O L O R                                      ##
//                                                                        ##
//  I S _ B L A C K , I S _ R E D , S E T _ B L A C K , S E T _ R E D     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : is_black
/// @brief Indicate if the node color is black
/// @param [in] none
/// @return bool
//------------------------------------------------------------------------
template <typename T>
inline bool node<T>::is_black  ( void ) const
{   return N.is_black() ;
    //return ( color == 1 );
};

//------------------------------------------------------------------------
//  function : is_red
/// @brief Indicate if the node color is red
/// @param [in] none
/// @return bool
//------------------------------------------------------------------------
template <typename T>
inline bool node<T>::is_red    ( void ) const
{   return N.is_red() ;
    //return ( color == 0 );
};

//------------------------------------------------------------------------
//  function : set_black
/// @brief Set the node color to black
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::set_black ( void )
{   N.set_black() ;
    //color = 1 ;
};

//------------------------------------------------------------------------
//  function : set_red
/// @brief Set the node color to red
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::set_red   ( void )
{   N.set_red() ;
    //color = 0 ;
};
template <typename T>
inline bool node<T>::color   ( void ) const
{   return N.color() ;
};
template <typename T>
inline void node<T>::color   ( bool color1 )
{   N.color(color1) ;
};


//##########################################################################
//                                                                        ##
//                          J U M P S                                     ##
//                                                                        ##
//            P R E V I O U S , N E X T , S H I F T                       ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : previous
/// @brief Obtain the pnode to the previous node. If don't exist return NULL
/// @param [in] none
/// @return Pointer to the node.
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
template <typename T>
typename node<T>::pnode   node<T>::previous  ( void )
{   //------------------------- Inicio ---------------------------
    pnode   P = this ;
    //-------------------------------------------------------------------
    // Primero tratamos de buscarlo hacia abajo. Si no fuera así , lo
    // buscamos hacia arriba
    //-------------------------------------------------------------------
    if ( left != NULL )
    {   P = left ;
        while ( P->right != NULL ) P = P->right ;
    }
    else
    {   //---------------------------------------------------------------
        // Subir por la dcha todo lo que puedas y luego un salto hacia
        // arriba a la izda
        // Si no es posible saltar a la izda devuelve NULL, porque no
        // tiene nada posterior
        //---------------------------------------------------------------
        while ( P->up != NULL and P->up->left == P ) P = P->up ;
        P =( P->up != NULL and P->up->right != P ) ?NULL :P->up ;
    };
    return P ;
};

//------------------------------------------------------------------------
//  function : next
/// @brief Obtain the pnode of the next node. If don't exist return NULL
/// @param [in] none
/// @return pnode
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
template <typename T>
typename node<T>::pnode   node<T>::next ( void )
{   //---------------------- Inicio ------------------------------
    pnode   P = this ;
    //-------------------------------------------------------------------
    // Primero tratamos de buscarlo hacia abajo. Si no fuera así , lo
    // buscamos hacia arriba
    //-------------------------------------------------------------------
    if ( right != NULL )
    {   P = right;
        while ( P->left != NULL ) P = P->left ;
    }
    else
    {   //----------------------------------------------------------------
        // Subir todo lo que puedas por la left, y luego un salto hacia
        // arriba hacia la dcha
        // Si no puede saltar a la dcha devuelve NULL, porque no tiene
        // nodo posterior
        //----------------------------------------------------------------
        while (P->up != NULL and P->up->right == P) P= P->up;
        P= ( P->up != NULL and P->up->left == P) ?  P->up :NULL;
    };
    return P;
};

//##########################################################################
//                                                                        ##
//                G E T T I N G   I N F O R M A T I O N                   ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : get_pos
/// @brief Get the position of the node in the tree structure
/// @param [in] none
/// @return Position in the structure
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
template <typename T>
size_type node<T>::get_pos ( void ) const
{   //----------------------- Inicio -----------------------------
    const_pnode   P1 = up;
    const_pnode   P = this ;
    size_type Pos = P->n_left () ;
    while ( P1 != NULL)
    {   if ( P == P1->right ) Pos += P1->n_left() +1 ;
        P = P1 ;
        P1 = P1->up ;
    };
    return Pos ;
};

//------------------------------------------------------------------------
//  function :n_left
/// @brief Counter of the node linked by the left pnode. If the left
///        pnode is NULL return 0
/// @param [in] none
/// @return Number of nodes
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline size_type node<T>::n_left ( void )const
{   return (left == NULL) ? 0 : left->N() ;
};

//------------------------------------------------------------------------
//  function : n_right
/// @brief Counter of the node linked by the right pnode. If the right
///        pnode is NULL return 0
/// @param [in]
/// @return Number of nodes
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline size_type node<T>::n_right ( void )const
{   return (right == NULL) ? 0 : right->N() ;
};

//------------------------------------------------------------------------
//  function : nd
/// @brief Counter of a node pointed by P. If P is NULL return 0
/// @param [in] P : pnode to the node to exam
/// @return Counter of the node
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline size_type node<T>::nd( const_pnode  P)
{   return ( P == NULL)?0:P->N();
};

//##########################################################################
//                                                                        ##
//       S H I F T    A N D     S W A P P I N G   N O D E S               ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : shift
/// @brief Obtain the pnode of the node located several positions
///        after or before the node
/// @param [in] NDesp : Number of positions to shift. This value can be
///                     positive  or negative
/// @return Pointer to the node. If don't exist return NULL
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
template <typename T>
typename node<T>::pnode   node<T>::shift ( size_type NDesp )
{   //-------------------------Inicio -----------------------------------
    pnode   P = this ;
    if ( NDesp == 0 ) return P;
    while ( NDesp != 0)
    {   if (NDesp > 0 )
        {   //---------------------------------------------------------------
            //               Desplazamiento hacia adelante
            // Trata de bajar por la right. Lo máximo que puede avanzar por
            // ese camino está determinado por el contador del nodo a su dcha.
            // Si esto no fuera suficiente, emprende el camino hacia el nodo
            // superior. Si este no existiera quiere decir que no puede
            // alcanzar ese desplazamiento por lo que devuelve NULL
            //----------------------------------------------------------------
            if ( NDesp > (size_type)(P->n_right()) )
            {   if ( P->up == NULL ) return NULL ;
                if ( P->up->right == P ) NDesp += P->n_left() + 1;
                else                     NDesp -= P->n_right() + 1;
                P = P->up ;
            }
            else
            {   //-------------------------------------------------
                //           Bajada por la derecha
                //-------------------------------------------------
                P = P->right ;
                NDesp -= P->n_left() +1 ;
            };
        }
        else
        {   //---------------------------------------------------------------
            //                 Desplazamiento hacia atrás
            // Trata de bajar por la left. Lo máximo que puede retroceder por
            // ese camino está determinado por el contador del nodo a su izda.
            // Si esto no fuera suficiente, emprende el camino hacia el nodo
            // superior. Si este no existiera quiere decir que no puede
            // alcanzar ese desplazamiento por lo que devuelve NULL
            //--------------------------------------------------------------
            if ( -NDesp > (size_type)(P->n_left()) )
            {   if ( P->up == NULL ) return NULL ;
                if ( P->up->right == P ) NDesp += P->n_left () + 1;
                else                     NDesp -= P->n_right () + 1;
                P = P->up ;
            }
            else
            {   //-----------------------------------------------------------
                //               Bajada por la left
                //----------------------------------------------------------
                P = P->left ;
                NDesp += P->n_right() +1 ;
            };
        };
    }; // Fin while
    return P;
};

//------------------------------------------------------------------------
//  function : swap_node
/// @brief Swap two nodes. They can't be contiguous
/// @param [in] PP1 : Pointer to the pnode to the first node
/// @param [in] PP2 : Pointer to the pnode to the second node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::swap_node ( address_pnode  PP1, address_pnode  PP2)
{   //------------------------------- Inicio ---------------------
#if __DEBUG_CNTREE != 0
    assert ( PP1 != NULL and *PP1 != NULL );
#endif
    pnode  P1 = *PP1 ;
#if __DEBUG_CNTREE != 0
    assert ( PP2 != NULL and *PP2 != NULL);
#endif
    pnode   P2 = *PP2 ;
    *PP1 = P2 ;
    *PP2 = P1 ;

    //------------------------ up ----------------------------
    std::swap ( P1->up ,  P2->up) ;

    std::swap ( P1->left , P2->left);
    if ( P1->left != NULL) P1->left->up = P1 ;
    if ( P2->left != NULL) P2->left->up = P2 ;

    std::swap ( P1->right , P2->right);
    if ( P1->right != NULL) P1->right->up = P1 ;
    if ( P2->right != NULL) P2->right->up = P2 ;

    //------------------------ color -------------------
    P1->N.swap ( P2->N);
    //bool color1 = P1->color() ;
    //P1->color( P2->color() ) ;
    //P2->color( color1) ;

    //-------------------------- N -------------------------
    //bitfield_t N1 = P1->N ;
    //P1->N = P2->N ;
    //P2->N = N1 ;
};

//------------------------------------------------------------------------
//  function :swap_contiguous_left
/// @brief Swap two nodes contiguous by the left pnode of the upper
///        node.
/// @param [in][out] PPup : address of the pnode to the upper node\n
///                         When finish the function PPup contains the
///                         address  to the new upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::swap_contiguous_left ( address_pnode  PPup)
{   //------------------------------ Inicio -----------------------
#if __DEBUG_CNTREE != 0
    assert (PPup != NULL and *PPup != NULL );
#endif
    pnode  Pup = *PPup ;

#if __DEBUG_CNTREE != 0
    assert (Pup->left != NULL and Pup->left->right == NULL  );
#endif
    pnode  PInf = Pup->left ;

    // ----------- Actualizacion de PPup y Pup ---------------------
    (*PPup ) = PInf ;
    PInf->up = Pup->up ;
    //----------------------- left ---------------------
    Pup->left = PInf->left ;
    if ( Pup->left != NULL ) Pup->left->up = Pup ;

    PInf->left = Pup ;
    Pup->up = PInf ;
    //------------------------ right --------------------
    PInf->right = Pup->right ;
    if ( PInf->right != NULL) PInf->right->up = PInf ;
    Pup->right = NULL ;

    //------------------------ color -------------------
    Pup->N.swap (PInf->N);
    //unsigned color1 = Pup->color ;
    //Pup->color  = PInf->color ;
    //PInf->color = color1 ;

    //-------------------------- N -------------------------
    //bitfield_t N1 = Pup->N ;
    //Pup->N = PInf->N ;
    //PInf->N = N1 ;
};
//##########################################################################
//                                                                        ##
//                       R O T A T I O N S                                ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function :rotate_left_aligned
/// @brief rotate to the left two or three nodes aligned
/// @param [in]PPup : pnode to the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::rotate_left_aligned    ( address_pnode  PPup )
{   //---------------------- Inicio ------------------------
    pnode   PBlack ;
    pnode   P1;
#if __DEBUG_CNTREE != 0
    assert (PPup != NULL and (*PPup) != NULL );
#endif
    PBlack=*PPup ;

#if __DEBUG_CNTREE != 0
    assert (PBlack->right != NULL);
#endif
    P1=PBlack->right;

    //---------------- Asignaciones -------------------------------
    (*PPup) = P1 ;
    P1->up = PBlack->up ;
    PBlack->up = P1 ;
    P1->N = PBlack->N ;
    PBlack->N -= ( P1->n_right() +1 ) ;
    PBlack->right = P1->left ;
    if ( P1->left != NULL ) P1->left->up = PBlack ;
    P1->left = PBlack ;
};

//------------------------------------------------------------------------
//  function :rotate_left_not_aligned
/// @brief rotate three nodes not aligned to the left
/// @param [in] PPup : address of the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::rotate_left_not_aligned ( node<T> **  PPup )
{   //---------------------- Inicio -------------------------------
    pnode  PBlack ;
    pnode  P1;
    pnode  P2;
#if __DEBUG_CNTREE != 0
    assert ( PPup != NULL and (*PPup) != NULL );
#endif
    PBlack = *PPup ;

#if __DEBUG_CNTREE != 0
    assert ( PBlack->right != NULL );
#endif
    P1 = PBlack->right ;

#if __DEBUG_CNTREE > 0
    assert ( P1->left != NULL );
#endif
    P2 = P1->left ;

    //-------------------------- Asignaciones -----------------------
    pnode  PtrA = P2->left ;
    pnode  PtrB = P2->right;
    pnode  PtrC = P1->right;
    pnode  PtrD = PBlack->left ;
    (*PPup) = P2 ;
    P2->up = PBlack->up ;
    PBlack->up = P1->up = P2 ;
    P2->N = PBlack->N;
    P2->left = PBlack ;
    P2->right = P1 ;
    PBlack->right = PtrA ;
    if ( PtrA != NULL ) PtrA->up = PBlack ;
    PBlack->N = nd(PtrD) + nd(PtrA) + 1 ;
    P1->left = PtrB ;
    if ( PtrB != NULL ) PtrB->up = P1 ;
    P1->N = nd(PtrB) + nd(PtrC) + 1 ;
};

//------------------------------------------------------------------------
//  function :rotate_right_aligned
/// @brief Rotate two or three aligned nodes to the right
/// @param [in] PPup : address of the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::rotate_right_aligned   ( address_pnode PPup )
{   //----------------------- Inicio ---------------------------------
    pnode PBlack ;
    pnode P1 ;
#if __DEBUG_CNTREE != 0
    assert ( PPup != NULL and (*PPup) != NULL);
#endif
    PBlack=*PPup ;

#if __DEBUG_CNTREE !=  0
    assert( (PBlack->left)!= NULL);
#endif
    P1=PBlack->left ;

    //------------------------ Asignaciones --------------------------
    (*PPup)  = P1 ;
    P1->up = PBlack->up ;
    PBlack->up = P1 ;
    P1->N = PBlack->N ;
    PBlack->N -= ( P1->n_left() + 1 ) ;
    PBlack->left = P1->right ;
    if ( P1->right != NULL ) P1->right->up = PBlack;
    P1->right = PBlack ;
};
//------------------------------------------------------------------------
//  function :rotate_right_not_aligned
/// @brief Rotate to the right 3 nodes not aligned
/// @param [in] PPup : address to the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void node<T>::rotate_right_not_aligned ( address_pnode PPup )
{   //----------------- Inicio ----------------------------------
    pnode PBlack ;
    pnode P1 ;
    pnode P2 ;

#if __DEBUG_CNTREE != 0
    assert ( PPup != NULL and  (*PPup) != NULL);
#endif
    PBlack = *PPup ;

#if __DEBUG_CNTREE != 0
    assert ( PBlack->left != NULL) ;
#endif
    P1 = PBlack->left ;

#if __DEBUG_CNTREE != 0
    assert ( P1->right != NULL );
#endif
    P2 = P1->right ;

    //----------------------- Asignaciones -------------------------
    pnode  PtrA = P1->left;
    pnode  PtrB = P2->left;
    pnode  PtrC = P2->right;
    pnode  PtrD = PBlack->right ;

    (*PPup) = P2 ;

    P2->up = PBlack->up ;
    PBlack->up = P1->up = P2 ;
    P2->N = PBlack->N ;
    P2->left = P1 ;
    P2->right = PBlack ;
    P2->set_black() ;
    P1->right = PtrB ;
    if ( PtrB != NULL ) PtrB->up = P1 ;
    P1->N = nd(PtrA) + nd(PtrB) + 1;
    PBlack->left = PtrC ;
    if ( PtrC != NULL) PtrC->up = PBlack ;
    PBlack->N = nd(PtrC) + nd(PtrD)+1 ;
    PBlack->set_red() ;
};

}; //---------------------- end namespace tools ---------------------------------
}; //---------------------- end namespace cntree --------------------------------
#endif
