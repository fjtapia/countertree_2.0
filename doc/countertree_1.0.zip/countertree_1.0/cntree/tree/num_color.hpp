//----------------------------------------------------------------------------
/// @file   num_color.hpp
/// @brief  This file contains the class num_color
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TOOLS_NUM_COLOR_HPP
#define __CNTREE_TOOLS_NUM_COLOR_HPP
#include <algorithm>
#include <boost/cntree/tree/config.hpp>


namespace cntree
{
namespace tree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #           C L A S S     N U M _ C O L O R        #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  num_color
/// @brief  This class encapsulate the counter and the color of a node
//
/// @remarks The code color is true : black, false :red
//----------------------------------------------------------------
class num_color
{   //------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //------------------------------------------------------------------------
    static size_t const MNUMBER = Conf<NByte>::MAX >> 1 ;
    static size_t const MCOLOR = MNUMBER + 1 ;

    //-------------------------------------------------------------------------
    //                       V A R I A B L E S
    //-------------------------------------------------------------------------
    size_t Num ;

public:
    //--------------------------------------------------------------------------
    //        C O N S T R U C T O R
    //--------------------------------------------------------------------------
    explicit num_color ( void) : Num(MCOLOR+1){} ;
    explicit num_color ( size_t N1 , bool color1) : Num ((color1)?MCOLOR:0 + N1){} ;
    explicit num_color ( const num_color &N1 ): Num( N1.Num){} ;

    //--------------------------------------------------------------------------
    //         O P E R A T O R =
    //--------------------------------------------------------------------------
    void operator =  ( size_t N1)    { Num = N1 | ( Num & MCOLOR ) ; };
    void operator =  ( const num_color &N1 ){ Num =(N1.Num & MNUMBER)|(Num & MCOLOR);};

    size_t operator () ( void) const { return (Num & MNUMBER) ;};
    void copy ( const num_color &N1 ){ Num = N1.Num ;};
    void swap ( num_color & C1){ std::swap ( Num, C1.Num);};

    //--------------------------------------------------------------------------
    //  I S _ B L A C K , I S _ R E D , S E T _ B L A C K , S E T _ R E D
    //--------------------------------------------------------------------------
    bool is_black  ( void ) const{ return ( (Num &MCOLOR) != 0  );  };
    bool is_red    ( void ) const{ return not is_black() ;          };
    void set_black ( void )      { Num = ( Num & MNUMBER ) | MCOLOR;};
    void set_red   ( void )      { Num = ( Num & MNUMBER ) ;        };
    bool color ( void ) const { return is_black();};
    void color (bool c1){ Num = (Num & MNUMBER)| ((c1)?MCOLOR : 0 );};


    //--------------------------------------------------------------------------
    //      O P E R A T O R + + , O P E R A T O R - -
    //--------------------------------------------------------------------------
    void operator ++ ( void         ){ Num++;};
    void operator ++ ( int          ){ Num++;};
    void operator -- ( void         ){ Num--;};
    void operator -- ( int          ){ Num--;};
    void operator += ( size_t N1    ){ Num += N1 ;};
    void operator += ( const num_color &N1 ){ Num += ( N1.Num & MNUMBER ) ;};
    void operator -= ( size_t N1    ){ Num -= N1 ;};
    void operator -= ( const num_color &N1 ){ Num -= ( N1.Num & MNUMBER ) ;};

//###################################################################
};//         E N D      C L A S S     N U M _ C O L O R
//###################################################################

}; //---------------------- end namespace tools ---------------------------------
}; //---------------------- end namespace cntree --------------------------------
#endif
