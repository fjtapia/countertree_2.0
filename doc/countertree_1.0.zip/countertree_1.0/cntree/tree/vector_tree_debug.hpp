///----------------------------------------------------------------------------
// FILE : debug_vector_tree.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TOOLS_DEBUG_VECTOR_TREE_HPP
#define __CNTREE_TOOLS_DEBUG_VECTOR_TREE_HPP

#if __DEBUG_CNTREE != 0

#include <boost/cntree/tree/branch_debug.hpp>
#include <boost/cntree/vector_tree.hpp>


namespace cntree
{

template <class T, class Alloc>
bool vector_tree<T,Alloc>::check (  void ) const
{   //--------------- Inicio -----------------------------------
    if ( root == NULL and first != NULL)
    {   std::cout<<"Error en el puntero first\n";
        return false ;
    };

    if ( root == NULL and last != NULL)
    {   std::cout<<"Error en el puntero last\n";
        return false ;
    };
    if ( root == NULL ) return true ;
    pnode P1 = root ;
    while ( P1->left != NULL ) P1 = P1->left ;
    if ( P1 != first)
    {   std::cout<<"Error en el puntero first\n";
        return false ;
    };
    P1 = root ;
    while ( P1->right != NULL ) P1 = P1->right ;
    if ( P1 != last)
    {   std::cout<<"Error en el puntero last\n";
        return false ;
    };

    return tree::Colombo<T>( NULL,root, n_level , false) ;

};
//-------------------------------------------------------------
//            I M P R I M I R
//-------------------------------------------------------------
template <class T, class Alloc>
void vector_tree<T,Alloc>::Imprimir(void)const
{   std::cout<<"############################################################################\n";
    std::cout<<"                               S T R U C T\n\n";
    //std::cout<<"--------------------------------------------------------------------------\n";
    std::cout<<"root :["<<root <<" :";
    if( root == NULL) std::cout<<"NULL";
    else                std::cout<<(root->data);
    std::cout<<"]  first :["<<first <<" :";
    if(first == NULL) std::cout<<"NULL";
    else                std::cout<<(first->data);
    std::cout<<"] last :["<<last<<" :";
    if(last == NULL)  std::cout<<"NULL"<<std::endl;
    else                std::cout<<(last->data);
    std::cout<<"]"<<std::endl<<std::endl;

    print_tree_struct(std::cout,root);
};

//----------------------------------------------------------------
// FUNCION : operator<<
//
// DESCRIPCION : operador de impresion del vector_tree
//
// PARAMETROS :
//  salida : ostream en el que imprimimos
//  A : vector_tree a imprimir
//
// PARAMETRO DEVUELTO : ostream despues de la impresion
//
// OBSERVACIONES :
//
//----------------------------------------------------------------
template <class T, class Alloc>
std::ostream & operator<<( std::ostream &salida , const vector_tree<T, Alloc> & A)
{   //----------------------------- Inicio -------------------------------
    salida<<"Number of nodes :"<<A.size() ;
    salida<<"  Number of levels :"<<A.levels()<<std::endl ;
    for ( tree::size_type i = 0 ; i < A.size() ; ++i)
        salida<<A[i]<<"  ";
    salida<<std::endl;
    //A.Imprimir ( ) ;
    return salida ;
};
}; //----------------------------------- end namespace cntree -----------------
#endif
#endif

