///----------------------------------------------------------------------------
// FILE : branch_debug.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TOOLS_BRANCH_DEBUG_HPP
#define __CNTREE_TOOLS_BRANCH_DEBUG_HPP

#if __DEBUG_CNTREE != 0

#include <boost/cntree/tree/node_debug.hpp>
#include <boost/cntree/tree/branch.hpp>

namespace cntree
{
namespace tree
{

//----------------------------------------------------------------
// FUNCION : operator<<
//
// DESCRIPCION : Operador de impresion para la branch
//
// PARAMETROS :
//  salida : ostream en el que vamos a imprimir
//  R : branch a imprimir
//
// PARAMETRO DEVUELTO : ostream despues de la impresion
//
// OBSERVACIONES :
//
//----------------------------------------------------------------
template <typename  T>
inline std::ostream & operator<<(std::ostream &salida, const branch<T> & H )
{	//------------ Inicio ------------------------
	salida<<"["<<( void*)(&H)<< "] ";
	salida<<"ppblack:"<<( void*)(H.ppblack);
	salida<<" PBlack:"<<(*H.ppblack);
	salida<<" N :"<<H.n_nodes()<<std::endl ;
	if (H.n_nodes() == 0 ) return salida ;


    node<T> *PAux = *(H.ppblack) ;
    salida<<"Black :"<<(*PAux)<<std::endl;

    if ( PAux->left != NULL and PAux->left->is_red() )
    {   PAux = PAux->left ;
        salida<<"left  :"<<( *PAux )<<std::endl;
        if ( PAux->left!= NULL and PAux->left->is_red() )
            salida<<"left->left :"<<( * PAux->left)<<std::endl;
        if ( PAux->right!= NULL and PAux->right->is_red() )
            salida<<"left->right :"<<( * PAux->right)<<std::endl;
    };
    PAux = *(H.ppblack) ;
    if ( PAux->right != NULL and PAux->right->is_red() )
    {   PAux = PAux->right ;
        salida<<"right  :"<<( *PAux )<<std::endl;
        if ( PAux->left!= NULL and PAux->left->is_red() )
            salida<<"right->left :"<<( * PAux->left)<<std::endl;
        if ( PAux->right!= NULL and PAux->right->is_red() )
            salida<<"right->right :"<<( * PAux->right)<<std::endl;
    };
 	return salida ;
};
}; // -------------------------- End namespace tools -----------------
}; // -------------------------- End  namespace cntree-------------------
#endif
#endif
