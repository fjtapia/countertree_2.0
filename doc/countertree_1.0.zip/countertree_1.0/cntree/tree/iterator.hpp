//----------------------------------------------------------------------------
/// @file   iterator.hpp
/// @brief  This file contains the Iterator and const_iterator definition
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TOOLS_ITERATOR_HPP
#define __CNTREE_TOOLS_ITERATOR_HPP

#include <boost/cntree/tree/definitions.hpp>
#include <boost/cntree/tree/basic_tree.hpp>
#include <iterator>

namespace cntree
{
namespace tree
{
void * const PMIN = (void* ) (size_t) 0 ;
void * const PMAX = ( void*)(~ ((size_t) 0));


template <class T> class const_iterator ;

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #      C L A S S        I T E R A T O R            #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @class  iterator
/// @brief  This class represent the iterators of the vector_tree structure
/// @remarks
//------------------------------------------------------------------------
template <typename T>
class iterator
{
public :
    //--------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef cntree::tree::size_type         size_type ;
    typedef cntree::tree::difference_type   difference_type ;
    typedef       T                         value_type ;
    typedef       value_type *              pointer;
    typedef       value_type &              reference;
    typedef const value_type *              const_pointer;
    typedef const value_type &              const_reference;
    typedef std::random_access_iterator_tag iterator_category;

private:
    //--------------------------------------------------------------------------
    //                     V A R I A B L E S
    //--------------------------------------------------------------------------
    node<T> *   P ;
    basic_tree< T > *  BT ;

    //--------------------------------------------------------------------------
    //               P R I V A T E    F U N C T I O N S
    //
    //       I N H E R I T E D    F R O M    B A S I C _ T R E E
    //--------------------------------------------------------------------------
    static node<T>*  get_first  ( basic_tree<T> *  BT);
    static node<T>*  get_last   ( basic_tree<T> *  BT);

    void next       ( void);
    void previous   ( void);
    void shift      ( size_type Distance);


public :
    //--------------------------------------------------------------------------
    //   C O N S T R U C T O R    &   D E S T R U C T O R
    //--------------------------------------------------------------------------
    iterator ( void);
    iterator ( node<T>*  P1 ,basic_tree<T> *  BT1);
    bool is_valid ( void) const ;
    //--------------------------------------------------------------------------
    //          A R I T H M E T I C    O P E R A T O R S
    //--------------------------------------------------------------------------
    iterator   operator++ ( void  );
    iterator   operator++ ( int   );
    iterator   operator-- ( void  );
    iterator   operator-- ( int   );

    iterator   operator+= ( size_type Distance );
    iterator   operator-= ( size_type Distance );

    iterator   operator + ( size_type Distance )const ;
    iterator   operator - ( size_type Distance )const ;
    size_type  operator - ( const_iterator<T> I ) const;
    size_type  operator - ( iterator<T> I ) const;
    //--------------------------------------------------------------------------
    //          L O G I C A L     O P E R A T O R S
    //--------------------------------------------------------------------------
    bool operator == ( const_iterator<T> I )const ;
    bool operator != ( const_iterator<T> I )const ;
    bool operator <  ( const_iterator<T> I )const ;
    bool operator >  ( const_iterator<T> I )const ;
    bool operator <= ( const_iterator<T> I )const ;
    bool operator >= ( const_iterator<T> I )const ;

    //--------------------------------------------------------------------------
    //          D E R E F E R E N C E D     O P E R A T O R S
    //--------------------------------------------------------------------------
    T &         operator * ( void );
    T *         operator-> ( void );

    size_type   pos ( void ) const;
    //--------------------------------------------------------------------------
    //                 S P E C I A L    V A L U E S
    //--------------------------------------------------------------------------
    static iterator end     ( basic_tree<T> *  BT );
    static iterator rend    ( basic_tree<T> *  BT );
    static iterator rbegin  ( basic_tree<T> *  BT );
    static iterator begin   ( basic_tree<T> *  BT );

    static iterator end     ( iterator V );
    static iterator rend    ( iterator V );
    static iterator begin   ( iterator V );
    static iterator rbegin  ( iterator V );
    node<T>*       ptr ( void ) const;
    basic_tree<T> *   ptr_basic_tree ( void ) const;
private:


    friend class const_iterator<T> ;
//##########################################################################
}; //         E N D     C L A S S     I T E R A T O R
//##########################################################################


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #    C L A S S     C O N S T _ I T E R A T O R     #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @class  const_iterator
/// @brief  This class represent the iterators of the vector_tree structure
/// @remarks
//------------------------------------------------------------------------
template <typename  T>
class const_iterator
{
public:
    //--------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef cntree::tree::size_type         size_type ;
    typedef cntree::tree::difference_type   difference_type ;
    typedef       T                         value_type ;
    typedef const value_type *              pointer;
    typedef const value_type &              reference;
    typedef const value_type *              const_pointer;
    typedef const value_type &              const_reference;
    typedef std::random_access_iterator_tag iterator_category;

private:
    //--------------------------------------------------------------------------
    //                     V A R I A B L E S
    //--------------------------------------------------------------------------
    const node<T>*         P ;
    const basic_tree<T> *  BT ;

    //--------------------------------------------------------------------------
    //               P R I V A T E    F U N C T I O N S
    //
    //       I N H E R I T E D    F R O M    B A S I C _ T R E E
    //--------------------------------------------------------------------------
    static const node<T>*  get_first(const basic_tree<T> *  BT );
    static const node<T>*  get_last (const basic_tree<T> *  BT);

    void next       ( void);
    void previous   ( void);
    void shift      ( difference_type Distance) ;

public :
    //--------------------------------------------------------------------------
    //   C O N S T R U C T O R    &   D E S T R U C T O R
    //--------------------------------------------------------------------------
    const_iterator(void);
    const_iterator ( const node<T>*  P1 ,const basic_tree<T> *  BT1);

    const_iterator ( iterator<T>  C) ;
    bool is_valid ( void) const ;
    //--------------------------------------------------------------------------
    //          A R I T H M E T I C    O P E R A T O R S
    //--------------------------------------------------------------------------
    const_iterator     operator++ ( void  );
    const_iterator     operator++ ( int   );
    const_iterator     operator-- ( void  );
    const_iterator     operator-- ( int   );

    const_iterator  operator+= ( size_type Distance );
    const_iterator  operator-= ( size_type Distance );

    const_iterator   operator + ( size_type Distance )const ;
    const_iterator   operator - ( size_type Distance )const ;
    size_type  operator - ( const_iterator I ) const;

    //--------------------------------------------------------------------------
    //          L O G I C A L     O P E R A T O R S
    //--------------------------------------------------------------------------
    bool operator == ( const_iterator I )const ;
    bool operator != ( const_iterator I )const ;
    bool operator <  ( const_iterator I )const ;
    bool operator >  ( const_iterator I )const ;
    bool operator <= ( const_iterator I )const ;
    bool operator >= ( const_iterator I )const ;

    //--------------------------------------------------------------------------
    //          D E R E F E R E N C E D     O P E R A T O R S
    //--------------------------------------------------------------------------
    const T & operator * ( void ) const;
    const T * operator-> ( void ) const;

    size_type   pos ( void) const;
    //--------------------------------------------------------------------------
    //                 S P E C I A L    V A L U E S
    //--------------------------------------------------------------------------
    static const_iterator end       (const basic_tree<T> *  BT );
    static const_iterator rend      (const basic_tree<T> *  BT);
    static const_iterator begin     (const basic_tree<T> *  BT);
    static const_iterator rbegin    (const basic_tree<T> *  BT);

    static const_iterator end       (const_iterator  V);
    static const_iterator rend      (const_iterator  V);
    static const_iterator begin     (const_iterator  V);
    static const_iterator rbegin    (const_iterator  V);

    const node<T>* ptr ( void ) const;
    const basic_tree<T> * ptr_basic_tree ( void ) const;
private:


    static node<T> *  remove_const ( const node<T>* P) ;

    friend class iterator<T>;
//########################################################################
};//     E N D     C L A S S     C O N S T _ I T E R A T O R
//########################################################################


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #     E X T E R N A L       O P E R A T O R S      #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//--------------------------------------------------------------------------
//      A R I T H M E T I C A L     O P E R A T O R S
//--------------------------------------------------------------------------
//------------------------------------------------------------------------
//  function : operator +
/// @brief Adds an iterator and a number
/// @param [in] C2 : number to add to the iterator
/// @param [in] C1 : iterator
/// @return iterator scrolled C2 positions
//------------------------------------------------------------------------
template <class T>
inline iterator<T> operator + ( size_type C2, iterator<T> C1);

//------------------------------------------------------------------------
//  function : operator +
/// @brief Adds an const_iterator and a number
/// @param [in] C2 : number to add to the iterator
/// @param [in] C1 : const_iterator
/// @return iterator scrolled C2 positions
//------------------------------------------------------------------------
template <class T>
inline const_iterator<T> operator + ( size_type C2, const_iterator<T> C1);


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #         C L A S S        I T E R A T O R         #             ##
//       #                                                  #             ##
//       #             F U N C T I O N S                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//##########################################################################
//                                                                        ##
//             S P E C I A L    F U N C T I O N S                         ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : get_first
/// @brief Return a pointer to the first element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline node<T> *  iterator<T>::get_first(basic_tree<T> *BT)
{   //----------------------- begin ------------------------
    node<T>*  P = BT->get_first();
    return ( P == NULL )? (node<T>*)PMAX :P ;
};

//------------------------------------------------------------------------
//  function : get_last
/// @brief Return a pointer to the last element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline node<T> *  iterator<T>::get_last( basic_tree<T> *BT)
{   //----------------------- begin --------------------
    node<T>*  P = BT->get_last();
    return ( P == NULL )? ( node<T>*)PMIN :P ;
};
//------------------------------------------------------------------------
//  function : next
/// @brief Return a pointer to the next element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void iterator<T>::next ( void)
{   //-------------------------- begin ------------------
    if ( P != PMAX )
    {   if ( P == PMIN ) P = get_first(BT) ;
        else if ( (P = P->next()) == NULL ) P =( node<T>*) PMAX ;
    }
};
//------------------------------------------------------------------------
//  function : previous
/// @brief Return a pointer to the previous element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void iterator<T>::previous ( void)
{   //-------------------------- begin ------------------
    if ( P != PMIN )
    {   if ( P == PMAX )  P = get_last(BT) ;
        else if ( (P = P->previous()) == NULL) P =( node<T>*) PMIN;
    };
};

//------------------------------------------------------------------------
//  function : shift
/// @brief Shift the iterator forward positions
/// @param [in] Distance : positions to go shift ( it can be negative)
/// @return none
//------------------------------------------------------------------------
template <typename T>
void iterator<T>::shift ( difference_type Distance)
{   //--------------------- Inicio -------------------------
    if ( Distance != 0 )
    {   if (Distance > 0 )
        {   if (P == PMIN)
            {   next() ;
                --Distance ;
            };
            if ( Distance != 0 and P != PMAX )
            {   if ((P = P->shift(Distance))== NULL ) P = (node<T>*)PMAX;
            };
        }
        else
        {   if (P == PMAX)
            {   previous();
                ++Distance;
            };
            if ( Distance != 0 and P != PMIN)
            {   if ( (P = P->shift(Distance)) == NULL) P = (node<T>*)PMIN ;
            };
        };
    };
};


//##########################################################################
//                                                                        ##
//   C O N S T R U C T O R    &   D E S T R U C T O R                     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : iterator
/// @brief void constructor
/// @param [in] none
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>::iterator ( void):P ((node<T>*)PMAX),BT(NULL){ };

//------------------------------------------------------------------------
//  function : iterator
/// @brief constructor
/// @param [in] P1 : pointer to a node
/// @param [in] BT1 : pointer to a basic_tree structure
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>::iterator( node<T>*  P1 ,basic_tree<T> *  BT1):P(P1),BT(BT1)
{   //--------------------- begin -----------------------
    if ( BT == NULL) P = ( node<T>*)PMAX;
};
template <typename T>
inline bool iterator<T>::is_valid ( void) const
{   //--------------------- begin -----------------------
    return ( BT != NULL) ;
};
//##########################################################################
//                                                                        ##
//          A R I T H M E T I C    O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator ++
/// @brief pre increment operator
/// @param [in] none
/// @return reference to the iterator incremented
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>   iterator<T>::operator++ ( void  )
{   //--------------------- Begin --------------------------
    if ( BT == NULL ) throw std::invalid_argument("") ;
    next() ;
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator++
/// @brief post increment operator
/// @param [in] int : not used
/// @return iterator before the increment
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>  iterator<T>::operator++ ( int  )
{   //-------------- Begin ---------------
    iterator C1 ( *this);
    ++(*this) ;
    return C1 ;
};

//------------------------------------------------------------------------
//  function . operator--
/// @brief pre decrement operator
/// @param [in] none
/// @return reference to the iterator decremented
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>   iterator<T>::operator-- ( void  )
{   //--------------------------- Begin ---------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    previous();
    return *this ;
};

//------------------------------------------------------------------------
//  function : operator--
/// @brief post decrement operator
/// @param [in] not used
/// @return iterator before the decrement
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>  iterator<T>::operator-- ( int  )
{   //------------------ Begin -----------------------
    iterator C1 ( *this);
    --(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function : operator+=
/// @brief self addition operator
/// @param [in] Distance : number of elements to jump forward
/// @return iterator after the addition
///
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::operator+= ( size_type Distance )
{   //---------------------- Begin --------------------
    if ( BT == NULL )   throw std::invalid_argument ("iterator::operator+=");
    shift ( Distance);
    return *this ;
};

//------------------------------------------------------------------------
//  function : operator-=
/// @brief self sustract operator
/// @param [in] Distance : number to elements to jump backward
/// @return iterator after the sustraction
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::operator-= ( size_type Distance )
{   return ((*this )+= -Distance );
};
//------------------------------------------------------------------------
//  function : operator+
/// @brief self add operator
/// @param [in] Distance : number to elements to jump forward
/// @return iterator after the addition
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>   iterator<T>::operator + ( size_type Distance )const
{   //----------------------- begin ---------------------
    iterator Alfa ( *this);
    return Alfa += Distance;
}
//------------------------------------------------------------------------
//  function : operator-
/// @brief post sustract operator
/// @param [in] Distance : number to sustract
/// @return iterator after the decrement
//------------------------------------------------------------------------
template <typename T>
inline iterator<T>   iterator<T>::operator - ( size_type Distance )const
{   //--------------------- begin --------------------
    iterator Alfa ( *this ) ;
    return (Alfa -= Distance);
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief post sustract operator
/// @param [in] I : iterator to sustract
/// @return Distance between the two iterators
//------------------------------------------------------------------------
template <typename T>
inline size_type  iterator<T>::operator - ( const_iterator<T> I ) const
{   //---------------------- Begin --------------------------
    iterator<T> Alfa ( static_cast <iterator<T> > ( I));
    if ( BT !=  Alfa.BT or BT == NULL ) throw std::invalid_argument("");
    return ( pos() - Alfa.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief post sustract operator
/// @param [in] Alfa : iterator to sustract
/// @return Distance between the two iterators
//------------------------------------------------------------------------
template <typename T>
inline size_type  iterator<T>::operator - ( iterator<T> Alfa ) const
{   //---------------------- Begin --------------------------
    if ( BT !=  Alfa.BT or BT == NULL ) throw std::invalid_argument("");
    return ( pos() - Alfa.pos() ) ;
};
//##########################################################################
//                                                                        ##
//               L O G I C A L     O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : operator==
/// @brief equal comparison operator
/// @param [in] I : iterator to compare
/// @return true if equals
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator == ( const_iterator<T> I )const
{   //-------------------- begin --------------------
    return ( BT == I.BT and P == I.P);
};
//------------------------------------------------------------------------
//  function : operator!=
/// @brief not equal comparison operator
/// @param [in] I : iterator to compare
/// @return false if equals
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator != ( const_iterator<T> I )const
{   return not ( *this == I);
};
//------------------------------------------------------------------------
//  function : operator<
/// @brief less than comparison operator
/// @param [in] I : iterator to compare
/// @return true if less
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator <  ( const_iterator<T> I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() < I.pos() );
};
//------------------------------------------------------------------------
//  function : operator<
/// @brief greather than comparison operator
/// @param [in] I : iterator to compare
/// @return ftrue if greather
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator >  ( const_iterator<T> I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() > I.pos());
};
//------------------------------------------------------------------------
//  function : operator <=
/// @brief less or equal than  operator
/// @param [in] I : iterator to compare
/// @return true: less or equals
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator <= ( const_iterator<T> I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() <= I.pos());
};
//------------------------------------------------------------------------
//  function : operator >=
/// @brief greather or equal   operator
/// @param [in] I : iterator to compare
/// @return true: greather or equal
//------------------------------------------------------------------------
template <typename T>
inline bool iterator<T>::operator >= ( const_iterator<T> I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() >= I.pos());
};

//##########################################################################
//                                                                        ##
//          D E R E F E R E N C E D     O P E R A T O R S                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator*
/// @brief dereferenced operator
/// @param [in] none
/// @return reference to the data pointed by the iterator
//------------------------------------------------------------------------
template <typename T>
inline T & iterator<T>::operator * ( void )
{   //------------------- Begin --------------
    if  (  BT == NULL or P == PMAX or P == PMIN ) throw std::invalid_argument("") ;
    return ( P->data ) ;
};

//------------------------------------------------------------------------
//  function : operator->
/// @brief dereferenced operator
/// @param [in] none
/// @return pointer to the data pointed by the iterator
//------------------------------------------------------------------------
template <typename T>
inline T * iterator<T>::operator-> ( void )
{   //------------------- Begin --------------
    if ( BT == NULL or P == PMAX or P == PMIN) throw std::invalid_argument("");
    return (& (P->data)) ;
};

//------------------------------------------------------------------------
//  function : pos
/// @brief return the position of the iterator in the data structure
/// @param [in] none
/// @return position
//------------------------------------------------------------------------
template <typename T>
inline size_type iterator<T>::pos ( void) const
{   //------------------------ begin -------------------
    if  ( BT == NULL ) throw std::invalid_argument("");
    if ( P == PMIN ) return  -1 ;
    return ( P == PMAX ) ? BT->n_elem() : P->get_pos () ;
};

//------------------------------------------------------------------------
//  function : ptr
/// @brief return the pointer to the node pointed by the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
template <typename T>
inline node<T>*   iterator<T>::ptr ( void ) const
{   //-------------------- begin ------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return P;
};
//------------------------------------------------------------------------
//  function : ptr_basic_tree
/// @brief return the pointer to the basic_tree contained in the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
template <typename T>
inline basic_tree<T> *  iterator<T>::ptr_basic_tree ( void ) const
{   //----------------- Inicio ----------------------
    return BT ;
};
//##########################################################################
//                                                                        ##
//                 S P E C I A L    V A L U E S                           ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::end (basic_tree<T> *BT)
{   //-------------------------- begin -------------------------
    if  ( BT == NULL ) throw std::invalid_argument("");
    return iterator( (node<T>*)PMAX ,BT);
};

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::end ( iterator<T>  V)
{   return end ( V.BT);
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::rend(basic_tree<T> *BT1)
{   //------------------------------- begin --------------------------
    if  ( BT1 == NULL ) throw std::invalid_argument("");
    return iterator((node<T>*)PMIN ,BT1);
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::rend(iterator<T> V)
{   return rend (V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::begin (basic_tree<T> *BT)
{   //----------------------- begin -----------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return iterator(get_first(BT), BT);
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::begin (iterator<T> V)
{   return begin ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::rbegin (basic_tree<T> *BT)
{   //----------------------- begin ------------------------
    if  ( BT == NULL ) throw std::invalid_argument("");
    return iterator(get_last(BT), BT);
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline iterator<T> iterator<T>::rbegin (iterator V)
{   return rbegin ( V.BT);
};


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #           C O N S T _ I T E R A T O R            #             ##
//       #                                                  #             ##
//       #             F U N C T I O N S                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//##########################################################################
//                                                                        ##
//             S P E C I A L    F U N C T I O N S                         ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : remove_const
/// @brief Generate a node<T> * from a const node<T> *
/// @param [in] pointer to a const node
/// @return pointer to a node
//------------------------------------------------------------------------
template <typename T>
inline  node<T> *  const_iterator<T>::remove_const ( const node<T>* P)
{   return  const_cast < node<T> * >(P );
};

//##########################################################################
//                                                                        ##
//               P R I V A T E    F U N C T I O N S                       ##
//                                                                        ##
//       I N H E R I T E D    F R O M    B A S I C _ T R E E              ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : get_first
/// @brief Return a pointer to the first element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline const node<T> *  const_iterator<T>::get_first(const basic_tree<T> *  BT )
{   //----------------------- begin ------------------------
    const node<T>* P ;
    if ( ( P = BT->get_first() ) == NULL) P = (const node<T>*)PMAX ;
    return P ;
};

//------------------------------------------------------------------------
//  function : get_last
/// @brief Return a pointer to the last element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline const node<T> *  const_iterator<T>::get_last(const basic_tree<T> *  BT)
{   //----------------------- begin --------------------
    const node<T> * P ;
    if ( (P = BT->get_last() )== NULL) P = (const node<T>*)PMIN ;
    return P ;
};
//------------------------------------------------------------------------
//  function : next
/// @brief Return a pointer to the next element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void const_iterator<T>::next ( void)
{   //-------------------------- begin ------------------
    if ( P != PMAX )
    {   if ( P == PMIN) P = get_first(BT) ;
        else if ( (P = remove_const(P)->next()) == NULL ) P = (const node<T>*)PMAX ;
    }
};

//------------------------------------------------------------------------
//  function : previous
/// @brief Return a pointer to the previous element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
inline void const_iterator<T>::previous ( void)
{   //-------------------------- begin ------------------
    if ( P != PMIN )
    {   if ( P == PMAX) P = get_last(BT) ;
        else if ( (P = remove_const(P)->previous()) == NULL) P = (const node<T>*)PMIN;
    };
};
//------------------------------------------------------------------------
//  function : shift
/// @brief Shift the iterator forward positions
/// @param [in] Distance : positions to go shift ( it can be negative)
/// @return none
//------------------------------------------------------------------------
template <typename T>
void const_iterator<T>::shift ( size_type Distance)
{   //--------------------- Inicio -------------------------
    if ( Distance != 0 )
    {   if (Distance > 0 )
        {   if (P == PMIN)
            {   next() ;
                --Distance ;
            };
            if ( Distance != 0 and P != PMAX )
            {   if ((P = remove_const(P)->shift(Distance))== NULL ) P = (const node<T>*)PMAX;
            };
        }
        else
        {   if (P == PMAX)
            {   previous();
                ++Distance;
            };
            if ( Distance != 0 and P != PMIN)
            {   if ( (P = remove_const(P)->shift(Distance)) == NULL) P =(const node<T>*) PMIN ;
            };
        };
    };
};

//##########################################################################
//                                                                        ##
//   C O N S T R U C T O R    &   D E S T R U C T O R                     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : const_iterator
/// @brief void constructor
/// @param [in] none
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>::const_iterator(void):P((const node<T>*) PMAX ),BT(NULL){};

//------------------------------------------------------------------------
//  function : const_iterator
/// @brief constructor
/// @param [in] P1 : pointer to a node
/// @param [in] BT1 : pointer to a basic_tree structure
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>::const_iterator ( const node<T>*  P1 ,
                    const basic_tree<T> *BT1) : P(P1),BT(BT1)
{   //-------------------------- begin -----------------------------
    if ( BT == NULL ) P = (const node<T>*) PMAX;
};

//------------------------------------------------------------------------
//  function : const_iterator
/// @brief constructor from an iterator
/// @param [in] C : iterator to copy
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>::const_iterator ( iterator<T>  C) :P (C.P ),BT (C.BT){};

//------------------------------------------------------------------------
//  function : is_valid
/// @brief Indicate if the iterator is pointing a any data structure
/// @return true : is valid
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::is_valid ( void) const
{   //-------------------------- begin -----------------------------
    return ( BT != NULL ) ;
};


//##########################################################################
//                                                                        ##
//          A R I T H M E T I C    O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator++
/// @brief post increment operator
/// @param [in] int : not used
/// @return iterator before the increment
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator++ ( int  )
{   const_iterator C1 ( *this);
    ++(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function : operator ++
/// @brief pre increment operator
/// @param [in] none
/// @return reference to the iterator incremented
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator++ ( void  )
{   //--------------------- Begin --------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    next() ;
    return *this ;
};

//------------------------------------------------------------------------
//  function . operator--
/// @brief pre decrement operator
/// @param [in] none
/// @return reference to the iterator decremented
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator-- ( void  )
{   //--------------------------- Begin ---------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    previous();
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator--
/// @brief post decrement operator
/// @param [in] not used
/// @return iterator before the decrement
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator-- ( int  )
{   //----------------------------- begin -----------------------
    const_iterator C1 ( *this);
    --(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function : operator+=
/// @brief self addition operator
/// @param [in] Distance : number of elements to jump forward
/// @return reference to the iterator after the addition
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator+= ( size_type Distance )
{   //---------------------- Begin --------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    shift ( Distance);
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator-=
/// @brief self sustract operator
/// @param [in] Distance : number to elements to jump backward
/// @return reference to the iterator after the sustraction
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>  const_iterator<T>::operator-= ( size_type Distance )
{   return ((*this )+= -Distance );
};

template <typename T>
inline const_iterator<T>   const_iterator<T>::operator + ( size_type Distance )const
{   //----------------------- begin ---------------------
    const_iterator Alfa ( *this);
    return Alfa += Distance;
}
//------------------------------------------------------------------------
//  function : operator -
/// @brief substraction operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in]Distance : Number of positions to shift ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>   const_iterator<T>::operator - ( size_type Distance )const
{   //--------------------- begin --------------------
    const_iterator Alfa ( *this ) ;
    return ( Alfa -= Distance);
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] I :  iterator to substract
/// @return distance between the two iterators
//------------------------------------------------------------------------
template <typename T>
inline size_type  const_iterator<T>::operator - ( const_iterator<T> Alfa ) const
{   //---------------------- Begin --------------------------
    if ( BT !=  Alfa.BT or BT == NULL ) throw std::invalid_argument("");
    return ( pos() - Alfa.pos() ) ;
};

//##########################################################################
//                                                                        ##
//               L O G I C A L     O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : operator==
/// @brief equal comparison operator
/// @param [in] I : iterator to compare
/// @return true if equals
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator == ( const_iterator I )const
{   //-------------------- begin --------------------
    return ( BT == I.BT and P == I.P);
};
//------------------------------------------------------------------------
//  function : operator!=
/// @brief not equal comparison operator
/// @param [in] I : iterator to compare
/// @return false if equals
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator != ( const_iterator I )const
{   return not ( *this == I);
};
//------------------------------------------------------------------------
//  function : operator<
/// @brief less than comparison operator
/// @param [in] I : iterator to compare
/// @return true if less
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator <  ( const_iterator I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() < I.pos());
};
//------------------------------------------------------------------------
//  function : operator<
/// @brief greather than comparison operator
/// @param [in] I : iterator to compare
/// @return ftrue if greather
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator >  ( const_iterator I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() > I.pos());
};
//------------------------------------------------------------------------
//  function : operator <=
/// @brief less or equal than  operator
/// @param [in] I : iterator to compare
/// @return true: less or equals
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator <= ( const_iterator I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() <= I.pos());
};
//------------------------------------------------------------------------
//  function : operator >=
/// @brief greather or equal   operator
/// @param [in] I : iterator to compare
/// @return true: greather or equal
//------------------------------------------------------------------------
template <typename T>
inline bool const_iterator<T>::operator >= ( const_iterator I )const
{   //----------------------- begin ----------------------
    if ( BT != I.BT) throw std::invalid_argument("") ;
    return ( pos() >= I.pos());
};

//##########################################################################
//                                                                        ##
//          D E R E F E R E N C E D     O P E R A T O R S                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator*
/// @brief dereferenced operator
/// @param [in] none
/// @return reference to the data pointed by the iterator
//------------------------------------------------------------------------
template <typename T>
inline const T & const_iterator<T>::operator * ( void ) const
{   //------------------------ begin -------------------------------
    if  ( BT == NULL or P == PMAX or P == PMIN ) throw std::invalid_argument("");
    return ( P->data ) ;
};

//------------------------------------------------------------------------
//  function : operator->
/// @brief dereferenced operator
/// @param [in] none
/// @return pointer to the data pointed by the iterator
//------------------------------------------------------------------------
template <typename T>
inline const T * const_iterator<T>::operator-> ( void ) const
{   //-------------------------- begin --------------------------------
    if  ( BT == NULL or P == PMAX or P == PMIN) throw std::invalid_argument("");
    return (& (P->data));
};
//------------------------------------------------------------------------
//  function : pos
/// @brief return the position of the iterator in the data structure
/// @param [in] none
/// @return position
//------------------------------------------------------------------------
template <typename T>
inline size_type const_iterator<T>::pos ( void) const
{   //------------------------ begin -------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    if ( P == PMIN ) return -1 ;
    return ( P == PMAX ) ? BT->n_elem() : P->get_pos () ;
};
//------------------------------------------------------------------------
//  function : ptr
/// @brief return the pointer to the node pointed by the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
template <typename T>
inline const  node<T> *  const_iterator<T>::ptr ( void ) const
{   //---------------------------- begin ------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return P;
};
//------------------------------------------------------------------------
//  function : ptr_basic_tree
/// @brief return the pointer to the basic_tree contained in the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
template <typename T>
inline const basic_tree<T> * const_iterator<T>::ptr_basic_tree ( void ) const
{   //----------------- Inicio ----------------------
    return BT ;
};

//##########################################################################
//                                                                        ##
//                 S P E C I A L    V A L U E S                           ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T> const_iterator<T>::end (const basic_tree<T> *BT )
{   //------------------------- begin -------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return const_iterator((const node<T>*)PMAX,BT);
};

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T> const_iterator<T>::end (const_iterator  V)
{   return end(V.ptr_basic_tree() );
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T> const_iterator<T>::rend(const basic_tree<T> *BT)
{   //------------------------- begin ---------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return const_iterator( (const node<T>*)PMIN,BT);
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T> const_iterator<T>::rend(const_iterator  V)
{   return rend ( V.BT);
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>
const_iterator<T>::begin (const basic_tree<T> *BT)
{   //--------------------------- begin --------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return const_iterator(get_first(BT), BT);
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>
const_iterator<T>::begin (const_iterator<T>  V)
{   return begin ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator<T>
const_iterator<T>::rbegin (const basic_tree<T> *BT)
{   //----------------------- begin --------------------------------
    if ( BT == NULL ) throw std::invalid_argument("");
    return const_iterator(get_last(BT), BT);
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
template <typename T>
inline const_iterator< T>
const_iterator<T>::rbegin (const_iterator<T>  V)
{   return rbegin ( V.ptr_basic_tree());
};


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #     E X T E R N A L       O P E R A T O R S      #             ##
//       #                                                  #             ##
//       #             F U N C T I O N S                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
/*
//------------------------------------------------------------------------
//  function : operator ==
/// @brief equality operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator == (const_iterator<T> C1, const_iterator<T> C2 )
{   return (C1.ptr_basic_tree()==C2.ptr_basic_tree() and C1.ptr()==C2.ptr());
};

//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator != (const_iterator<T> C1, const_iterator<T> C2 )
{   return not( C1 == C2);
};

//------------------------------------------------------------------------
//  function : operator <
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator < (const_iterator<T> C1, const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() < C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator >
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator > (const_iterator<T> C1, const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() > C2.pos() ) ;
};

//------------------------------------------------------------------------
//  function : operator <=
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator <= (const_iterator<T> C1, const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() <= C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator >=
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <typename T >
inline bool operator >= (const_iterator<T> C1, const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() >= C2.pos() ) ;
};

//######################################################################
//
//    A R I T H M EW T I C    O P E R A T O R S
//
//######################################################################
//------------------------------------------------------------------------
//  function : operator -
/// @brief substraction operator. Return the iterator shifted forward Distance
///        positions  from C1 without modify it
/// @param [in] C1 : iterator used as origin
/// @param [in]Distance : Number of positions to shift ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T >
inline iterator<T> operator - (iterator<T> C1, difference_type Distance )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree() != NULL );
#endif
    iterator<T> Aux ( C1);
    return ( Aux -= Distance ) ;
};

//------------------------------------------------------------------------
//  function : operator -
/// @brief substraction operator. Return the iterator shifted forward Distance
///        positions  from C1 without modify it
/// @param [in] C1 : iterator used as origin
/// @param [in]Distance : Number of positions to shift ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T >
inline const_iterator<T> operator - (const_iterator<T> C1, difference_type Distance )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree() != NULL );
#endif
    const_iterator<T> Aux ( C1);
    return ( Aux -= Distance ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] C1 :  iterator to substract
/// @param [in] C2 :  iterator substracted
/// @return distance between the two iterators
//------------------------------------------------------------------------
template <class T>
inline difference_type operator - (iterator<T> C1, iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() - C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] C1 :  iterator to substract
/// @param [in] C2 :  iterator substracted
/// @return distance between the two iterators
//------------------------------------------------------------------------
template <class T>
inline difference_type operator - (iterator<T> C1,  const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() - C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] C1 :  iterator to substract
/// @param [in] C2 :  iterator substracted
/// @return distance between the two iterators
//------------------------------------------------------------------------
template <class T>
inline difference_type operator - (const_iterator<T> C1,  iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() - C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] C1 :  iterator to substract
/// @param [in] C2 :  iterator substracted
/// @return distance between the two iterators
//------------------------------------------------------------------------
template <class T>
inline difference_type operator - (const_iterator<T> C1, const_iterator<T> C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree()== C2.ptr_basic_tree() and C2.ptr_basic_tree() != NULL );
#endif
    return ( C1.pos() - C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] C1 : iterator to add a Distance
/// @param [in] Distance : Number of positions to shift from C1 ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T>
inline iterator<T> operator + (iterator<T> C1, difference_type C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree() != NULL );
#endif
    iterator<T> Aux ( C1);
    return ( Aux += C2 ) ;
};
*/
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] C1 : iterator to add a Distance
/// @param [in] Distance : Number of positions to shift from C1 ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T>
inline iterator<T> operator + ( size_type C2, iterator<T> C1)
{   //---------------------- Begin --------------------------
    return C1+= C2;
};
/*
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] C1 : iterator to add a Distance
/// @param [in] Distance : Number of positions to shift from C1 ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T>
inline const_iterator<T> operator + (const_iterator<T> C1, difference_type C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_CNTREE != 0
    assert( C1.ptr_basic_tree() != NULL );
#endif
    const_iterator<T> Aux ( C1);
    return ( Aux += C2 ) ;
};
*/
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] C1 : iterator to add a Distance
/// @param [in] Distance : Number of positions to shift from C1 ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
template <class T>
inline const_iterator<T> operator + ( size_type C2, const_iterator<T> C1)
{   //---------------------- Begin --------------------------
    return C1 += C2 ;
};


//########################################################################
};//     E N D     N A M E S P A C E     T O O L S
//########################################################################

//########################################################################
};//     E N D     N A M E S P A C E     C N T R E E
//########################################################################
#endif
