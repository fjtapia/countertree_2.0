///----------------------------------------------------------------------------
// FILE : branch.h
//
// DESCRIPTION : This class represent the branch of the vector_tree
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_TREE_BRANCH_HPP
#define __CNTREE_TREE_BRANCH_HPP

#include <boost/cntree/tree/definitions.hpp>
#include <boost/cntree/tree/node.hpp>

namespace cntree
{
namespace tree
{
//-------------------------------------------------------------
/// @class  branch
/// @brief  This class represent a branch of the tree
//
/// @remarks All the pointers of the branch are identified by a code
///  The description of this code is
///         000 : pointer left black node
///         001 : pointer right black node
///         010 : pointer left  of left node
///         011 : pointer right of left node
///         100 : pointer left of right node
///         101 : pointer right of right node
///  This description is valid by all the functions
//----------------------------------------------------------------
template <typename  T>
class branch
{
public:
    //-------------------------------------------------------------------------
    //                 D E F I N I T I O N S
    //-------------------------------------------------------------------------
    typedef typename  node <T>::pnode          pnode         ;
	typedef typename  node <T>::const_pnode    const_pnode   ;
	typedef typename  node <T>::address_pnode  address_pnode ;
	typedef typename  node <T>::refnode        refnode       ;
	typedef typename  node <T>::const_refnode  const_refnode ;
    //--------------------------------------------------------------------------
    //                       V A R I A B L E S
    //--------------------------------------------------------------------------
    address_pnode  ppblack ;

    //--------------------------------------------------------------------------
    //                     C O N S T R U C T O R
    //--------------------------------------------------------------------------
    branch ( address_pnode  P1);

    //--------------------------------------------------------------------------
    //        C O N S U L T    I N T E R N A L   I N F O R M A T I O N
    //--------------------------------------------------------------------------
    size_type        n_nodes         ( void ) const;
    address_pnode    pointer_Cod     ( unsigned Cod);
    address_pnode    pointer_father  ( pnode  P );

    //--------------------------------------------------------------------------
    //       I N S E R T _ N O D E   ,   D I S C O N N E C T _ N O D E
    //--------------------------------------------------------------------------
    void insert_node ( pnode  P1 , uint32_t Cod);
    bool disconnect_node ( unsigned Cod , pnode  &  PAux);

    //--------------------------------------------------------------------------
    //                        R O T A T I O N S
    //--------------------------------------------------------------------------
    void rotate_left_aligned        ( void );
    void rotate_left_not_aligned    ( void );
    void rotate_right_aligned       ( void );
    void rotate_right_not_aligned   ( void );

    //--------------------------------------------------------------------------
    //                  C A K E    O P E R A T I O N S
    //--------------------------------------------------------------------------
    static void break_cake ( branch<T> &  R);
    static bool reverse_cake (branch<T> &  Rup, branch<T> & RInf,uint32_t CodS) ;

//#############################################################################
};//           E N D     B R A N C H    C L A S S
//#############################################################################



//##########################################################################
//                                                                        ##
//                     C O N S T R U C T O R                              ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : branch
/// @brief Constructor of the class
/// @param [in] P1 : address to the pointer to the black node of the branch
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline branch<T>::branch ( address_pnode  P1): ppblack ( P1)
{   //----------------------------- begin -----------------------
#if __DEBUG_CNTREE != 0
    assert ( P1 != NULL and *P1 != NULL);
#endif
};

//##########################################################################
//                                                                        ##
//        C O N S U L T    I N T E R N A L   I N F O R M A T I O N        ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : n_nodes
/// @brief provide the number of nodes in the branch. They can
///        be 4 after a break cake
/// @param [in] none
/// @return number of nodes
//------------------------------------------------------------------------
template <typename T>
size_type branch<T>::n_nodes ( void ) const
{   //------------------------------- Inicio -----------------------
    size_type N = 0 ;
    pnode PBlack = *ppblack ;
    if ( PBlack != NULL )
    {   N++ ;
        pnode  P1 = PBlack->left ;
        if ( P1 != NULL and P1->is_red())
        {   N++;
            if ( P1->left != NULL and P1->left->is_red() ) N++ ;
            if ( P1->right != NULL and P1->right->is_red() ) N++ ;
        };

        P1 = PBlack->right ;
        if ( P1 != NULL and P1->is_red())
        {   N++;
            if ( P1->left != NULL and P1->left->is_red() ) N++ ;
            if ( P1->right != NULL and P1->right->is_red() ) N++ ;
        };
    };
    return N ;
};

//------------------------------------------------------------------------
//  function : pointer_Cod
/// @brief Obtain the address of a node<T>* with the code Cod
/// @param [in] Cod : code of the node<T>*
/// @return address of the node<T>*
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline typename node<T>::address_pnode  branch<T>::pointer_Cod ( unsigned Cod)
{   //----------------------- Inicio ------------------------------
#if __DEBUG_CNTREE != 0
    assert ( Cod < 6 );
#endif
    address_pnode  PP= NULL ;
    pnode  PAux = NULL ;
    pnode  PBlack = *ppblack ;
    switch ( Cod >>1 )
    {   case 0: PP =  ((Cod == 0)? &(PBlack->left) : &(PBlack->right)) ;
                break;
        case 1:if ( (PAux= PBlack->left) != NULL and PAux->is_red() )
                    PP = ((Cod==2)? &(PAux->left) : &(PAux->right)) ;
               break;
        case 2:if ((PAux=PBlack->right) != NULL and PAux->is_red() )
                    PP = ((Cod==4)? &(PAux->left) : &(PAux->right)) ;
               break;
#if __DEBUG_CNTREE != 0
        default : assert ( false );
#endif
    };
    return PP ;
};

//------------------------------------------------------------------------
//  function : pointer_father
/// @brief address of the pointer, pointing to the node pointed by P
/// @param [in] P : pointer
/// @return address of the pointer
//------------------------------------------------------------------------
template <typename T>
inline typename node<T>::address_pnode   branch<T>::pointer_father ( pnode P )
{   //----------------------- Inicio --------------------------
#if __DEBUG_CNTREE  != 0
    assert ( P != NULL );
#endif
    pnode  Pup = P->up ;
    if ( Pup == NULL ) return ppblack ;
    return (( Pup->left == P ) ?& ( Pup->left ) : &(Pup->right )) ;
};
//##########################################################################
//                                                                        ##
//       I N S E R T _ N O D E   ,   D I S C O N N E C T _ N O D E        ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function :insert_node
/// @brief Insert a node in the branch. All the counters of the
//         nodes must be incremented from the insertion point to the root.\n
//         Temporally a branch can have 4 nodes after a insertion. In this
//         case the structure of the branch is an V inverted in order to
//         simplify the rotations
/// @param [in] P1 : pointer to the node to insert
/// @param [in] Cod : code of the pointer where connect the node
/// @return none
/// @remarks The counters of the nodes must be incremented, due to this
//           they reflect the number of nodes after the insertion, not
///          before
//------------------------------------------------------------------------
template <typename T>
inline void branch<T>::insert_node ( pnode  P1 , uint32_t Cod)
{   //---------------------------- Begin ------------------------
#if __DEBUG_CNTREE != 0
    assert ( P1 != NULL and n_nodes() < 5);
#endif
    //--------------------- Preparacion del nodo a insertar ------------------
    pnode  PBlack = *ppblack ;
    P1->init() ;
    //PBlack->N++ ;

    //------------------------------- Insertion ------------------
    switch( Cod)
    {   case 0: PBlack->left = P1 ;
                P1->up = PBlack;
                break ;

        case 1: PBlack->right = P1 ;
                P1->up = PBlack;
                break ;

        case 2: PBlack->left->left = P1  ;
                P1->up = PBlack->left ;
                //PBlack->left->N++ ;
                break ;

        case 3: P1->left = PBlack->left ;
                PBlack->left->up = P1 ;
                PBlack->left = P1 ;
                P1->N =  2 ;
                P1->left->N = 1 ;
                P1->up = PBlack ;
                break ;

        case 4: P1->right = PBlack->right ;
                PBlack->right->up = P1 ;
                PBlack->right = P1 ;
                P1->N = 2 ;
                P1->right->N = 1 ;
                P1->up = PBlack ;
                break ;

        case 5: PBlack->right->right = P1 ;
                P1->up = PBlack->right ;
                //PBlack->right->N++;
                break ;
#if __DEBUG_CNTREE != 0
        default: assert ( false) ;
#endif
    };
    PBlack = *ppblack ;
    if ( PBlack->N() == 3 )
    {   if ( PBlack->left == NULL ) rotate_left_aligned() ;
        else
        {   if ( PBlack->right == NULL ) rotate_right_aligned() ;
        };
    };
};

//------------------------------------------------------------------------
//  function : disconnect_node
/// @brief disconnect a node of the branch, and leave the branch,
///        if possible , in a stable configuration
/// @param [in] Cod : code of the pointer to the node to disconnect.
/// @param [in] PAux : pointer to the disconnected node
/// @return bool (true : OK branch stable, false : the branch is empty)
/// @remarks The counters to the nodes must be previously decremented
//------------------------------------------------------------------------
template <typename T>
inline bool branch<T>::disconnect_node ( unsigned Cod , pnode  & PAux)
{   //--------------------------- Inicio -----------------------
#if __DEBUG_CNTREE != 0
    uint32_t Nnd = n_nodes() ;
    assert ( not ( Nnd > 3 or (Nnd == 3 and Cod < 2)) );
#endif
    pnode PBlack = *ppblack ;
    //,*P = PBlack ;
    //uint32_t N = P->N +1 ;
    bool Estable = true ;
    Cod = Cod>>1 ;
    switch ( Cod )
    {   case 0 :  // node negro de la hoja
            PAux = PBlack ;
            if (PBlack->left != NULL)
            {   PBlack->left->up = PBlack->up ;
                (*ppblack) = PBlack->left ;
                PBlack->left->set_black() ;
            }
            else
            {   if ( PBlack->right != NULL)
                {   PBlack->right->up = PBlack->up ;
                    (*ppblack) = PBlack->right ;
                    PBlack->right->set_black() ;
                }
                else
                {   (*ppblack) = NULL;
                    Estable = false ;
                };
            };
            break ;
        case 1 : // node izdo
            PAux = PBlack->left ;
            PBlack->left = NULL ;
            //PBlack->N-- ;
            break ;

        case 2 : // node Dcho
            PAux = PBlack->right ;
            PBlack->right = NULL ;
            //PBlack->N-- ;
            break ;
#if __DEBUG_CNTREE != 0
        default: assert ( false) ;
#endif
    };
    PAux->init();
    return Estable;
};


//##########################################################################
//                                                                        ##
//                        R O T A T I O N S                               ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : rotate_left_aligned
/// @brief rotate the nodes of the branch to the left, when they are aligned
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
void branch<T>::rotate_left_aligned ( void )
{   //-------------------------------Inicio ------------------------
    node<T>::rotate_left_aligned( ppblack);
    pnode  P = *ppblack ;
    P->set_black() ;
    P->left->set_red();
};

//------------------------------------------------------------------------
//  function : rotate_left_not_aligned
/// @brief rotate the nodes of the branch to the left, when they aren't
///        aligned
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
void branch<T>::rotate_left_not_aligned(void)
{   //---------------------- Inicio -------------------------------
    node<T>::rotate_left_not_aligned( ppblack);
    pnode  P = *ppblack ;
    P->set_black() ;
    P->left->set_red() ;
};
//------------------------------------------------------------------------
//  function :rotate_right_aligned
/// @brief rotate the nodes of the branch to the right, when they are
///        aligned
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
void branch<T>::rotate_right_aligned( void )
{   //----------------------- Inicio ---------------------------------
    node<T>::rotate_right_aligned ( ppblack) ;
    pnode  P = *ppblack ;
    P->set_black() ;
    P->right->set_red() ;
};

//------------------------------------------------------------------------
//  function :rotate_right_not_aligned
/// @brief rotate the nodes of the branch to the right, when they aren't
///        aligned
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
template <typename T>
void branch<T>::rotate_right_not_aligned ( void)
{   //----------------- Inicio ----------------------------------
    node<T>::rotate_right_not_aligned( ppblack);
    pnode  P = *ppblack ;
    P->set_black() ;
    P->right->set_red() ;
};

//##########################################################################
//                                                                        ##
//                  C A K E    O P E R A T I O N S                        ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : break_cake
/// @brief This function implement the break cake of the branch
/// @param [in] R : branch to break cake
/// @return none
/// @remarks
//------------------------------------------------------------------------
template <typename T>
inline void branch<T>::break_cake ( branch<T> & R)
{   //-------------------------- Inicio ---------------------------
    pnode  PBlack = (*R.ppblack) ;
    PBlack->left->set_black() ;
    PBlack->right->set_black() ;
    PBlack->set_red() ;
};

//------------------------------------------------------------------------
//  function : reverse_cake
/// @brief Implements the reverse cake mechanism between the
///        Rup and Rinf branches
/// @param [in] Rup : Upper branch
/// @param [in] RInf : lower branch
/// @param [in] CodS : Code of the pointer of Rup which connect the
///                    two branches
/// @return Estability of the branch (true : stable,false : Rup is
///         empty and the branch is not stable)
/// @remarks
//------------------------------------------------------------------------
template <typename  T>
bool branch<T>::reverse_cake (branch<T> &Rup, branch<T> &RInf,uint32_t CodS)
{   //------------------------------- Inicio --------------------------------
    uint32_t Nup = Rup.n_nodes() ;
#if __DEBUG_CNTREE != 0
    assert ( not ( CodS > 5 or ( CodS < 2 and Nup > 2)) );
#endif
    //----------------------------------------------------------------------
    //                 branch Superior
    // Si Cod > 1 indica que tenemos el nodo listo para el descenso
    // Si Cod < 2 la branch no puede tener mas de 2 nodos
    // Si Cod < 2 y hay mas de un nodo en la rama hay que hacer una rotacion
    // para tener el nodo listo para el descenso
    //-----------------------------------------------------------------------
    if ( CodS < 2 and Nup > 1 )
    {   if ( CodS == 0 )
        {   Rup.rotate_left_aligned() ;
            CodS = 2 ;
        }
        else
        {   Rup.rotate_right_aligned() ;
            CodS = 5 ;
        };
    };

    //-------------------------------------------------------------------------
    // Presuponemos que RInf está vacia, por lo que no nos vale para nada.
    // Hay que buscar la rama que cuelga del mismo nodo que RInf.
    // Si dicha rama tiene mas de 1 nodo, mediante una rotacion inserta un
    // nodo en RInf y el sistema queda estable.
    // Si solo tiene 1 nodo , descendemos el nod  de la rama superior.
    // Si dicha rama tiene mas de 1 nodo , el sistema está estable.
    // Si solo tiene un nodo , queda vacía y la inestabilidad se propaga
    // hacia la rama superior
    //------------------------------------------------------------------------
    // El nuevo codigo es el mismo que el anterior con el ultimo bit complementado
    uint32_t CodS2 = ( CodS & 6) | ((~CodS) & 1);
    address_pnode  PPInf2 = Rup.pointer_Cod( CodS2);
    branch<T> RInf2( PPInf2) ;
    uint32_t NInf2 = RInf2.n_nodes() ;

    //-----------------------------------------------------------------
    // Si RInf2 tiene mas de 1 nodo se arregla con una rotación
    //-----------------------------------------------------------------
    if ( NInf2 > 1)
    {   pnode  PBlack = * RInf2.ppblack ;
        address_pnode  PPup2 = Rup.pointer_father ( PBlack->up);
        bool color2 = PBlack->up->color() ;
        if ( (CodS2 & 1 ) == 0 )
        {   if ( PBlack->right != NULL and PBlack->right->is_red())
                   node<T>::rotate_right_not_aligned ( PPup2);
            else  node<T>::rotate_right_aligned ( PPup2);
        }
        else
        {   if ( PBlack->left != NULL and PBlack->left->is_red())
                    node<T>::rotate_left_not_aligned ( PPup2) ;
            else    node<T>::rotate_left_aligned( PPup2) ;
        };
        PBlack = *PPup2 ;
        PBlack->color ( color2) ;
        PBlack->left->set_black() ;
        PBlack->right->set_black() ;
        return true ;
    };
    //--------------------------------------------------------------------
    // El nodo de la rama superior desciende. Si la rama superior tiene
    // mas de 1 nodo, al finalizar el descenso , queda estable.
    // Si solo tenía 1 nodo , queda vacía y por lo tanto inestable
    // En este punto sabemos con certeza que RInf2 tiene 1 solo nodo,
    // por lo que el descenso es trivial
    //--------------------------------------------------------------------
    pnode  PAux = *RInf2.ppblack ;
    PAux->up->set_black() ;
    PAux->set_red() ;
    return ( Nup >1);
};


//########################################################################
};//              E N D    T R E E    N A M E S P A C E
//########################################################################
//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
