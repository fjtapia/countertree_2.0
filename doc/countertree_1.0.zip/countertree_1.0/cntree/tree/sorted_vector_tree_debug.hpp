///----------------------------------------------------------------------------
// FILE : debug_sorted_vector_tree.h
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SORTED_VECTOR_TREE_DEBUG_HPP
#define __CNTREE_SORTED_VECTOR_TREE_DEBUG_HPP

#if __DEBUG_CNTREE  != 0
#include <boost/cntree/tree/branch_debug.hpp>
#include <boost/cntree/tree/vector_tree_debug.hpp>
#include <boost/cntree/sorted_vector_tree.hpp>

namespace cntree
{

template < class value_t,
           class key_t ,
           class filter_t,
           class comp_key_t,
           class alloc_t
         >
bool sorted_vector_tree <value_t,key_t,filter_t,comp_key_t,alloc_t>::check ( void) const
{   //----------------------- begin-----------------------------
    if ( not vector_tree::check()) return false;
    if ( size() < 2 ) return true ;
    for ( const_iterator Alfa = begin() +1; Alfa != end() ; ++Alfa)
    {   if ( cmpr (fltr(*Alfa), fltr ( *(Alfa -1))))
        {   std::cout<<"Error in the order of the elements\n";
            return false ;
        };
    };
    return true;
};
}; //----------------------------------- end namespace boost -----------------
#endif
#endif
