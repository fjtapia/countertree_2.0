//----------------------------------------------------------------------------
/// @file suballocator.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SUBALLOCATOR_HPP
#define __CNTREE_SUBALLOCATOR_HPP


#include <boost/cntree/alloc/suballocator.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #      U S I N G    D E C L A R A T I O N S        #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
using cntree::alloc::suballocator32 ;
using cntree::alloc::suballocator64 ;
using cntree::alloc::suballocator ;


//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
