//----------------------------------------------------------------------------
/// @file   map_pool.hpp
/// @brief  This file contains the implementation of map and multimap,
///         based on the vector_tree
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_MAP_POOL_HPP
#define __COUNTERTREE_MAP_POOL_HPP

#include <boost/cntree/map.hpp>
#include <boost/cntree/suballocator.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #               M A P _ P O O L                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//-------------------------------------------------------------
/// @class  map_pool
/// @brief  This class have the same interface and functions than the
///         class map defined in the Standard Template Library ( STL),
///         plus a function  at which permit to access to the elements
///         of the map by their position
///         This class map have too, iterators with random access, which
///         permit increment and decrement any value to the iterators
/// @remarks
//----------------------------------------------------------------
template < class Key, class Data, class Comp=std::less<Key>,
class Alloc =std::allocator<std::pair <const Key, Data> > >
class map_pool : public map <Key,Data,Comp,suballocator<Alloc> >
{
public:
    //--------------------------------------------------------------------------
    //           C O N S T R U C T O R , D E S T R U C T O R
    //--------------------------------------------------------------------------
//-----------------------------------------------------------------------
//  function : map_pool
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//------------------------------------------------------------------------
explicit map_pool ( const Comp& C1 = Comp(), const Alloc & A= Alloc() ):
         map <Key,Data,Comp,suballocator<Alloc> > (C1,suballocator<Alloc>()){};

//----------------------------------------------------------------
//  function : map_pool
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template <class InputIterator>
map_pool (InputIterator first,InputIterator last,const Comp& C1=Comp(),const Alloc &A1=Alloc()):
          map <Key,Data,Comp,suballocator<Alloc> > (first,last,C1,suballocator<Alloc>()) {};

//----------------------------------------------------------------
//  function : map_pool
/// @brief  Copy constructor
/// @param [in] m :map from where copy the data
//----------------------------------------------------------------
map_pool( const map<Key,Data,Comp,Alloc>& m ):map<Key,Data,Comp,suballocator<Alloc> > (m){};

//----------------------------------------------------------------
//  function : ~map_pool
/// @brief  Destructor
//----------------------------------------------------------------
virtual ~map_pool(){ };

};


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                 C L A S S                        #             ##
//       #                                                  #             ##
//       #          M U L T I M A P _ P O O L               #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//---------------------------------------------------------------------------
/// @class  multimap_pool
/// @brief  This class have the same interface and functions than the
///  class multimap defined in the Standard Template Library ( STL), plus a
///  function at which permit to access to the elements of the map by their
///  position
///  This class multimap have too, iterators with random access, which permit
///  increment and decrement any value to the iterators
/// @remarks
//----------------------------------------------------------------------------

template <class Key, class Data, class Comp=std::less<Key>,
class Alloc=std::allocator<std::pair <const Key, Data> > >
class multimap_pool : public multimap <Key,Data,Comp,suballocator<Alloc> >
{
public:
//----------------------------------------------------------------------
//  function :multimap_pool
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------------
explicit multimap_pool ( const Comp& C1 = Comp(),const Alloc & A= Alloc() ):
         multimap <Key,Data,Comp,suballocator<Alloc> >( C1, suballocator<Alloc> ()){};

//--------------------------------------------------------------------
//  function : multimap_pool
/// @brief  Copy constructor
/// @param [in] m :multimap from where copy the data
//--------------------------------------------------------------------
multimap_pool ( const multimap<Key,Data,Comp,suballocator<Alloc> >& m ):
                multimap<Key,Data,Comp,suballocator<Alloc> >(m ) {};

//---------------------------------------------------------------------
//  function : multimap_pool
/// @brief  Constructor from a map
/// @param [in] m :map from where copy the data
//---------------------------------------------------------------------
multimap_pool ( const map<Key,Data,Comp,suballocator<Alloc> >& m ):
                      multimap<Key,Data,Comp,suballocator<Alloc> >(m ) {};

//---------------------------------------------------------------------
//  function : multimap_pool
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//-----------------------------------------------------------------------
template <class InputIterator>
multimap_pool(InputIterator first,InputIterator last,const Comp& C1=Comp(),const Alloc &A1=Alloc()):
              multimap<Key,Data,Comp,suballocator<Alloc> > (first,last,C1,suballocator<Alloc>()) {};

//----------------------------------------------------------------
//  function : ~multimap_pool
/// @brief  Destructor
//----------------------------------------------------------------
virtual ~multimap_pool(){};

};

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################

#endif

