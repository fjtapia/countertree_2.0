//----------------------------------------------------------------------------
/// @file   set.hpp
/// @brief  This file contains the implementation of set and multiset,
///         based on the vector_tree
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_SET_HPP
#define __COUNTERTREE_SET_HPP

#include <memory>
#include <functional>
#include <boost/cntree/sorted_vector_tree.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #                   S E T                          #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  set
/// @brief  This class have the same interface than the STL set,
///         plus access by position with the function at, and random access
///         iterators
/// @remarks
//----------------------------------------------------------------
template < class Key,
           class Comp = std::less<Key>,
           class Alloc = std::allocator<Key>
         >
class set
{
public :
    //--------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef tree::filter_set<Key, Key>                      Filter  ;
    typedef Key                                             Value ;
    typedef Key                                             key_type;
    typedef Key                                             value_type ;
    typedef Key *                                           pointer;
    typedef const Key *                                     const_pointer;
    typedef Comp                                            key_compare ;
    typedef Comp                                            value_compare;
    typedef Alloc                                           allocator_type;
    typedef Key &                                           reference ;
    typedef const Key &                                     const_reference;
    typedef sorted_vector_tree<Key,Value,Filter,Comp,Alloc> SVTree ;

    typedef typename SVTree::const_iterator                 iterator;
    typedef typename SVTree::const_iterator                 const_iterator ;
    typedef typename SVTree::size_type                      size_type ;
    typedef typename SVTree::size_type                      difference_type;
    typedef typename SVTree::const_iterator                 reverse_iterator;
    typedef typename SVTree::const_iterator                 const_reverse_iterator;

private :
    typedef typename SVTree::iterator                       rw_iterator;
    //--------------------------------------------------------------------------
    //                     V A R I A B L E S
    //--------------------------------------------------------------------------
    SVTree  T ;

public:
    //--------------------------------------------------------------------------
    //   C O N S T R U C T O R    &   D E S T R U C T O R
    //--------------------------------------------------------------------------
    explicit set ( const Comp  & C1 = Comp(),const Alloc & A1 = Alloc()  );

    template <class InputIterator>
    set ( InputIterator first,      InputIterator last,
          const Comp& C1 = Comp(),  const Alloc & A1= Alloc() );

    set ( const set & x );

    virtual ~set (void) ;

    set & operator = ( const set &S);

    const Key & at ( size_type Pos) const ;

    //--------------------------------------------------------------------------
    //                   I T E R A T O R S
    //--------------------------------------------------------------------------
    bool        is_mine ( iterator it) const;
    iterator    begin   ( void) const ;
    iterator    end     ( void) const ;
    iterator    rbegin  ( void) const ;
    iterator    rend    ( void) const ;

    //--------------------------------------------------------------------------
    //                       C A P A C I T Y
    //--------------------------------------------------------------------------
    bool        empty    (void) const ;
    size_type   size     (void) const ;
    size_type   max_size (void) const ;

    //--------------------------------------------------------------------------
    //                 M O D I F I E R S
    //--------------------------------------------------------------------------
    std::pair <iterator,bool> insert ( const value_type& x );
    iterator                  insert ( iterator position, const value_type& x );

    template <class InputIterator>
    void insert ( InputIterator first, InputIterator last );

    void        erase ( iterator iter );
    size_type   erase ( const key_type& x ) ;
    void        erase ( iterator first, iterator last );

    void        swap  ( set & st );
    void        clear ( void);

    //--------------------------------------------------------------------------
    //                   O B S E R V E R S
    //--------------------------------------------------------------------------
    key_compare     key_comp      ( ) const;
    value_compare   value_comp    ( ) const;
    allocator_type  get_allocator ( ) const;

    //--------------------------------------------------------------------------
    //                   O P E R A T I O N S
    //--------------------------------------------------------------------------
    iterator    find        ( const key_type& x ) const;
    size_type   count       ( const key_type& x ) const;
    iterator    lower_bound ( const key_type& x ) const;
    iterator    upper_bound ( const key_type& x ) const;

    std::pair<iterator,iterator> equal_range ( const key_type& x ) const;

//########################################################################
};//              E N D     S E T      C L A S S
//########################################################################


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #                M U L T I S E T                   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class multiset
///
/// @remarks This class have the same interface than the STL multiset,
///  plus access by position with the function at, and random access
///  iterators
//----------------------------------------------------------------
template < class Key,
           class Comp = std::less<Key>,
           class Alloc = std::allocator<Key>
         >
class multiset
{
public :
    //--------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef tree::filter_set<Key, Key>                       Filter  ;
    typedef Key                                              Value ;
    typedef Key                                              key_type;
    typedef Key                                              value_type ;
    typedef Key *                                            pointer;
    typedef const Key *                                      const_pointer;
    typedef Comp                                             key_compare ;
    typedef Comp                                             value_compare;
    typedef Alloc                                            allocator_type;
    typedef Key &                                            reference ;
    typedef const Key &                                      const_reference;
    typedef sorted_vector_tree<Key,Value,Filter,Comp,Alloc>  SVTree ;

    typedef typename SVTree::const_iterator                  iterator;
    typedef typename SVTree::const_iterator                  const_iterator ;
    typedef typename SVTree::size_type                       size_type ;
    typedef typename SVTree::size_type                       difference_type;
    typedef typename SVTree::const_iterator                  reverse_iterator;
    typedef typename SVTree::const_iterator                  const_reverse_iterator;

private :
    typedef typename SVTree::iterator                       rw_iterator;
    //--------------------------------------------------------------------------
    //                    V A R I A B L E S
    //--------------------------------------------------------------------------
    SVTree T ;

public:
    //--------------------------------------------------------------------------
    //      C O N S T R U C T O R   &   D E S T R U C T O R
    //--------------------------------------------------------------------------
    explicit multiset ( const Comp  & C1 = Comp(), const Alloc & A1 = Alloc()  );

    template <class InputIterator>
    multiset ( InputIterator first,     InputIterator last,
               const Comp& C1 = Comp(), const Alloc & A1= Alloc() );

    multiset ( const set<Key,Comp,Alloc >& x );
    multiset ( const multiset<Key,Comp,Alloc >& x );

    virtual ~multiset (void) ;

    multiset  & operator = ( const multiset &S);

    const Key & at ( size_type Pos) const;

    //--------------------------------------------------------------------------
    //                    I T E R A T O R S
    //--------------------------------------------------------------------------
    bool      is_mine ( iterator it) const;
    iterator  begin   ( void) const ;
    iterator  end     ( void) const ;
    iterator  rbegin  ( void) const ;
    iterator  rend    ( void) const ;

    //--------------------------------------------------------------------------
    //                     C A P A C I T Y
    //--------------------------------------------------------------------------
    bool        empty    ( void) const ;
    size_type   size     ( void) const ;
    size_type   max_size ( void) const ;

    //--------------------------------------------------------------------------
    //                    M O D I F I E R S
    //--------------------------------------------------------------------------
    std::pair<iterator,bool> insert ( const value_type& x );
    iterator                 insert ( iterator position, const value_type& x );

    template <class InputIterator>
    void insert ( InputIterator first, InputIterator last );


    void      erase ( iterator iter );
    size_type erase ( const key_type& x );
    void      erase ( iterator first, iterator last );

    void swap  ( set<Key,Comp,Alloc>& st );
    void clear ( void);

    //--------------------------------------------------------------------------
    //                   O B S E R V E R S
    //--------------------------------------------------------------------------
    key_compare     key_comp      ( ) const;
    value_compare   value_comp    ( ) const;
    allocator_type  get_allocator ( ) const;

    //--------------------------------------------------------------------------
    //                   O P E R A T I O N S
    //--------------------------------------------------------------------------
    iterator    find        ( const key_type& x ) const;
    size_type   count       ( const key_type& x ) const;
    iterator    lower_bound ( const key_type& x ) const;
    iterator    upper_bound ( const key_type& x ) const;

    std::pair<iterator,iterator> equal_range ( const key_type& x ) const;

//########################################################################
};//              E N D     M U L T I S E T     C L A S S
//########################################################################

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #                   S E T                          #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//##########################################################################
//                                                                        ##
//   C O N S T R U C T O R    &   D E S T R U C T O R                     ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------------------
//  function : set
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//-------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
set<Key,Comp,Alloc>::set(const Comp &C1,const Alloc &A1)
                                        : T( Filter(),C1,A1){  };

//----------------------------------------------------------------
//  function : set
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
template <class InputIterator>
set<Key,Comp,Alloc>::set (InputIterator first, InputIterator last,
                          const Comp& C1, const Alloc &A1):T(Filter(),C1,A1)
{   //-------------------------begin -----------------------------------
    for ( ; first != last ; first++) insert ( *first) ;
};

//----------------------------------------------------------------
//  function : set
/// @brief  Copy constructor
/// @param [in] x : set from where copy the data
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
set<Key,Comp,Alloc>::set ( const set & x ):T(x.T){ };

//----------------------------------------------------------------
//  function : ~set
/// @brief  Destructor
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
set <Key, Comp,Alloc>::~set(void ){} ;

//----------------------------------------------------------------
//  function : operator =
/// @brief Asignation operator
/// @param [in] S : setr from where copy the data
/// @return Reference to the set after the copy
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline set<Key,Comp,Alloc> & set<Key,Comp,Alloc>::operator = ( const set &S)
{   //-------------------------------- begin -------------------------------
    T = S.T ;
    return *this ;
};

//----------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the set
/// @param  [in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This is an random access function of the multiset.\n
///          I didn't use the operator [ ] because it is used in the
///          map class.\n
///          It is very important to be uniform access method in
///          the four classes( set, multiset, map and multimap)\n
///          This operation is O (log(N))
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline const Key & set<Key,Comp,Alloc>::at ( size_type Pos) const
{   //------------------------- begin ----------------------------
    return T[Pos];
};

//##########################################################################
//                                                                        ##
//                   I T E R A T O R S                                    ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this set
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this set
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline bool set<Key,Comp,Alloc>::is_mine ( iterator it) const
{   //--------------------------- begin -------------------------
    return T.is_mine(it) ;
};

//----------------------------------------------------------------
//  function : begin
/// @brief return one iterator to the first element of the set
/// @return iterator to the first element of the set
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::begin( void)const
{   //------------------------------- begin ----------------------------------
    return T.begin();
};

//----------------------------------------------------------------
//  function : end
/// @brief return one iterator to the next element after the last
/// @return iterator to the next element after the last
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::end( void) const
{   //----------------------------- begin ------------------------
    return T.end();
};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one iterator to the last element of the set
/// @return iterator to the last element of the set
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::rbegin( void)const
{   //---------------------------- begin ------------------------
    return T.rbegin();
};

//----------------------------------------------------------------
//  function : rend
/// @brief return one iterator to the previous elemento to the first
/// @return iterator to the previous elemento to the first
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::rend( void) const
{   //----------------------------- begin ------------------------
    return T.rend();
};

//##########################################################################
//                                                                        ##
//                       C A P A C I T Y                                  ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : empty
/// @brief indicate if the set is empty
/// @return true if the set is empty, false in any other case
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
bool set<Key,Comp,Alloc>::empty ( void) const
{   //------------------------- begin -------------------
    return size() == 0 ;
};

//----------------------------------------------------------------
//  function : size
/// @brief return the number of elements in the set
/// @return number of elements in the set
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::size_type
set<Key,Comp,Alloc>::size (void) const
{   //----------------------------- begin -----------------------
    return T.size() ;
};

//----------------------------------------------------------------
//  function : max_size
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::size_type
set<Key,Comp,Alloc>::max_size (void) const
{   //--------------------------- begin --------------------------
    return T.size_type_max() ;
};

//##########################################################################
//                                                                        ##
//                 M O D I F I E R S                                      ##
//                                                                        ##
//##########################################################################

//---------------------------------------------------------------------
//  function : insert
/// @brief insert a value in the set
/// @param [in] X : value to insert
/// @return pair of elements, the first is one iterator to the element inserted \n
///         and the second is a boolean which indcate if the iterator is end()
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
std::pair <typename set<Key,Comp,Alloc>::iterator, bool>
set<Key,Comp,Alloc>::insert ( const value_type& x )
{   //------------------------ begin -----------------------
    iterator I ;
    I = T.insert_value_unique  (x) ;
    return std::pair<iterator,bool>( I, I != end() );
};

//----------------------------------------------------------------
//  function : insert
/// @brief insert a value in the set, and receive too an iterator to
///        an element nearest the insertion point \n
/// @param [in] position : iterator to an element close to the insertion point
/// @param [in] x : element to insert
/// @return iterator to the element inserted
/// @remarks This function is unuseful in this implementation
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::insert ( iterator position, const value_type& x )
{   //---------------------------  begin ------------------------------
    return T.insert_value_unique ( x) ;
};

//----------------------------------------------------------------
//  function : insert
/// @brief Insertion of range of elements from two iterators
/// @param [in] first : Iterator to the first element of the range
/// @param [in] last : Iterator to the last lement of the range
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
template <class InputIterator>
void set<Key,Comp,Alloc>::insert ( InputIterator first, InputIterator last )
{   //---------------------- Inicio --------------------
    for (InputIterator Alfa = first ; Alfa != last; ++Alfa )
        T.insert_value_unique( *Alfa) ;
};

//----------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by iter
/// @param [in] iter : iterator to the element to erase
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void set<Key,Comp,Alloc>::erase ( iterator iter )
{   //---------------------------- begin --------------------------
    assert ( is_mine (iter));
    T.erase( iter );
};
//----------------------------------------------------------------
//  function : erase
/// @brief Erase all the elements with a key
/// @param [in] x : key of all the elements to erase
/// @return number of elements erased
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
typename set<Key,Comp,Alloc>::size_type
set<Key,Comp,Alloc>::erase ( const key_type& x )
{   //----------------------- begin ------------------------------
    iterator I = T.find(x) ;
    if ( I == T.end()) return 0 ;
    T.erase( I);
    return 1 ;
} ;
//----------------------------------------------------------------
//  function : erase
/// @brief erase a range of elements in the range first, last
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void set<Key,Comp,Alloc>::erase ( iterator first, iterator last )
{   //------------------------------ begin -----------------------------
    assert (is_mine (first) and is_mine( last));
    T.erase ( first , last);
};

//----------------------------------------------------------------
//  function : swap
/// @brief swap the data of the set st with the actual set
/// @param [in] st : set to swap
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline void set<Key,Comp,Alloc>::swap ( set & st )
{   T.swap ( st.T);
};

//----------------------------------------------------------------
//  funcxtion : clear
/// @brief Delete all the elements of the set
/// @param [in] none
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline void set<Key,Comp,Alloc>::clear ( void)
{   //---------------------------------- begin -----------------------
    T.clear();
};

//##########################################################################
//                                                                        ##
//                   O B S E R V E R S                                    ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : key_comp
/// @brief return the object used to compare two keys
/// @param [in] none
/// @return object used to compare two keys
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::key_compare
set<Key,Comp,Alloc>::key_comp ( ) const
{   //----------------------------- begin -----------------------
    return Comp();
};

//----------------------------------------------------------------
//  function : value_comp
/// @brief return the object used to compare two values
/// @param [in] none
/// @return object used to compare two values
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::value_compare
set<Key,Comp,Alloc>::value_comp ( ) const
{   //--------------------------------- begin --------------------
    return Comp();
};

//----------------------------------------------------------------
//  function : get_allocator
/// @brief return the object allocator of the set
/// @param [in] none
/// @return object allocator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::allocator_type
set<Key,Comp,Alloc>::get_allocator() const
{   //------------------------ begin ---------------------------
    return T.K ;
};

//##########################################################################
//                                                                        ##
//                   O P E R A T I O N S                                  ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : find
/// @brief return the iterator to the element with the key x
/// @param [in] x : key to find in the set
/// @return iterator to the element with the key x. If don't exist return end()
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::find ( const key_type& x ) const
{   //------------------------------------- begin ----------------------
    return T.find_unique(x);
};

//----------------------------------------------------------------
//  function : count
/// @brief return the number of elements in the set with the key x
/// @param [in] x : key to find
/// @return number of elements in the set with the key x
/// @remarks This operation is log (N)
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::size_type
set<Key,Comp,Alloc>::count ( const key_type& x ) const
{   //-------------------------------- begin ---------------------
    return T.count (x);
};
//----------------------------------------------------------------
//  function : lower_bound
/// @brief return one iterator to the first appearance of the key x if exist \n
///  and if don't exist return one iterator to the first element greather than x
/// @param [in] x : key to find
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::lower_bound ( const key_type& x ) const
{   //-------------------------------- begin --------------------------
    return T.lower_bound (x);
};

//----------------------------------------------------------------
//  function : upper_bound
/// @brief return one iterator to the first element greather than x. If
///  don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename set<Key,Comp,Alloc>::iterator
set<Key,Comp,Alloc>::upper_bound ( const key_type& x ) const
{   //---------------------------------- begin -------------------------
    return T.upper_bound (x);
};

//----------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of iterators, the first is the lower_bound (x) and
///  the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of iterators
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
std::pair<typename set<Key,Comp,Alloc>::iterator,typename set<Key,Comp,Alloc>::iterator>
set<Key,Comp,Alloc>::equal_range ( const key_type& x ) const
{   //------------------------------------------- begin -------------------------------
    return T.equal_range (x);
};


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #                M U L T I S E T                   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//##########################################################################
//                                                                        ##
//      C O N S T R U C T O R   &   D E S T R U C T O R                   ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : multiset
/// @brief Constructor of the class multiset
/// @param [in] C1 : object for comparison
/// @param [in] A1 : object for to allocate elements
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
multiset<Key,Comp,Alloc>::multiset ( const Comp  & C1 ,
                                              const Alloc & A1   )
                                            : T(Filter() ,C1,A1){};

//-------------------------------------------------------------------------
//  function : multiset
/// @brief Constructor of the class multiset, with the insertion of a range
///        of elements between the iterators first and last
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : object for comparison
/// @param [in] A1 : object for to allocate elements
//--------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
template <class InputIterator>
multiset<Key,Comp,Alloc>::multiset ( InputIterator first, InputIterator last,
                                     const Comp& C1 , const Alloc & A1 )
                                    : T(Filter(),C1,A1)
{   //---------------------begin ----------------------------
    for ( ; first != last ; first++)  insert ( *first) ;
};

//-----------------------------------------------------------------------
//  function : multiset
/// @brief Constructor of the class multiset, copying the data from a set
/// @param [in] x : set from where insert the elements
//------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
multiset<Key,Comp,Alloc>::multiset ( const set<Key,Comp,Alloc >& x )
                                    :T(x.T) { };

//-----------------------------------------------------------------------
//  function : multiset
/// @brief Constructor of the class multiset, copying the data from a set
/// @param [in] x : set from where insert the elements
//------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
multiset<Key,Comp,Alloc>::multiset ( const multiset<Key,Comp,Alloc >& x )
                                    :T(x.T) { };
//----------------------------------------------------------------
//  function : ~multiset
/// @brief destructor of the class multiset
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
multiset<Key,Comp,Alloc>::~multiset (void) {};

//----------------------------------------------------------------
//  function : operator =
/// @brief Asignation operator
/// @param [in] S : set from we copy the elements
/// @return reference to the set after the insertion of the elements
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline multiset<Key,Comp,Alloc>  &
multiset<Key,Comp,Alloc>::operator = ( const multiset &S)
{   //--------------------------------- begin -------------------
    T = S.T ;
    return *this ;
};
//----------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the set
/// @param  [in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This is an random access function of the multiset.\n
///          I didn't use the operator [ ] because it is used in the
///          map class.\n
///          It is very important to be uniform access method in
///          the four classes( set, multiset, map and multimap)\n
///          This operation is O (log(N))
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline const Key & multiset<Key,Comp,Alloc>::at ( size_type Pos) const
{   //------------------------------------ begin ---------------------
    return T[Pos];
};

//##########################################################################
//                                                                        ##
//                    I T E R A T O R S                                   ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this multiset
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this multiset
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline bool multiset<Key,Comp,Alloc>::is_mine ( iterator it) const
{   //---------------------------- begin ---------------------------
    return T.is_mine(it) ;
};

//----------------------------------------------------------------
//  function : begin
/// @brief Return an iterator to the first element of the multiset.
///        If don't exist returns end()
/// @param [in] none
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::begin( void) const
{   //------------------------------- begin ------------------------
    return T.begin();
};

//----------------------------------------------------------------
//  function : end
/// @brief Return an iterator to the first element after the last
///        of the multiset.
/// @param [in] none
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::end( void)const
{   //------------------------------- begin --------------------
    return T.end();
};

//----------------------------------------------------------------
//  function : rbegin
/// @brief Return an iterator to the last element of the multiset. If it is
//         empty returns end()
/// @param [in] none
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::rbegin( void)const
{   //--------------------------------- begin ----------------------
    return T.rbegin();
};

//----------------------------------------------------------------
//  function : rend
/// @brief return one iterator to the previous element to the first
/// @return iterator to the previous element to the first
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::rend( void) const
{   //-------------------------------- begin ------------------------
    return T.rend();
};

//##########################################################################
//                                                                        ##
//                     C A P A C I T Y                                    ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : empty
/// @brief Return if the multiset is empty
/// @param [in] none
/// @return true if the multiset is empty
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline bool multiset<Key,Comp,Alloc>::empty ( void) const
{   //-------------------------------- begin ----------------------
    return size() == 0 ;
};

//----------------------------------------------------------------
//  function : size
/// @brief return the number of elements in the multiset
/// @return number of elements in the set
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::size_type
multiset<Key,Comp,Alloc>::size (void) const
{   //---------------------------------- begin ---------------------
    return T.size() ;
};

//----------------------------------------------------------------
//  function : max_size
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::size_type
multiset<Key,Comp,Alloc>::max_size (void) const
{   //----------------------------- begin ------------------------
    return T.size_type_max() ;
};

//##########################################################################
//                                                                        ##
//                    M O D I F I E R S                                   ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : insert
/// @brief insert a value in the multiset
/// @param [in] X : value to insert
/// @return pair of elements, the first is one iterator to the element inserted \n
///         and the second is a boolean which indcate if the iterator is end()
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
std::pair<typename multiset<Key,Comp,Alloc>::iterator,bool>
multiset<Key,Comp,Alloc>::insert ( const value_type& x )
{   //------------------------- begin ---------------------------------
    iterator I = T.insert_value ( x) ;
    return std::pair<iterator,bool>( I, I != end() );
};

//----------------------------------------------------------------
//  function :  insert
/// @brief insert a value in the multiset, and receive too, an iterator to
///        an element nearest the insertion point \n
///        This function is unuseful in this implementation
/// @param [in] position : iterator to an element close to the insertion point
/// @param [in] x : element to insert
/// @return iterator to the element inserted
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::insert ( iterator position, const value_type& x )
{   //------------------------------- begin --------------------------------
    return T.insert_value ( x) ;
};

//----------------------------------------------------------------
//  function : insert
/// @brief Insertion of range of elements from two iterators
/// @param [in] first : Iterator to the first element of the range
/// @param [in] last : Iterator to the last lement of the range
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
template <class InputIterator>
void multiset<Key,Comp,Alloc>::insert ( InputIterator first, InputIterator last )
{   //--------------------------- Inicio ------------------------------------
    for (InputIterator Alfa = first ; Alfa != last; ++Alfa )
        T.insert_value ( *Alfa) ;
};

//----------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by iter
/// @param [in] iter : iterator to the element to erase
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void multiset<Key,Comp,Alloc>::erase ( iterator iter )
{   //------------------------ begin -----------------------
    assert (is_mine (iter));
    T.erase( iter);
};

//----------------------------------------------------------------
//  function : erase
/// @brief Erase all the elements with a key
/// @param [in] x : key of all the elements to erase
/// @return number of elements erased
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
typename multiset<Key,Comp,Alloc>::size_type
multiset<Key,Comp,Alloc>::erase ( const key_type& x )
{   //-------------------------- begin ---------------------------
    std::pair<iterator,iterator> P = T.equal_range(x);
    return T.erase ( P.first, P.second);
} ;

//----------------------------------------------------------------
//  function : erase
/// @brief erase a range of elements in the range [first, last)
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void multiset<Key,Comp,Alloc>::erase(iterator first,iterator last)
{   //------------------------------ begin ----------------------------
    assert( is_mine (first) and  is_mine (last));
    T.erase ( first, last);
};

//----------------------------------------------------------------
//  function : swap
/// @brief swap the data of the multiset st with the actual multiset
/// @param [in] st : multiset to swap
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void multiset<Key,Comp,Alloc>::swap ( set<Key,Comp,Alloc>& st )
{   //----------------------------- begin --------------------------
    T.swap ( st.T);
};

//----------------------------------------------------------------
//  function : clear
/// @brief Delete all the elements of the set
/// @param [in] none
/// @return none
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
void multiset<Key,Comp,Alloc>::clear ( void)
{   //----------------------------- begin ------------------------
    T.clear();
};

//##########################################################################
//                                                                        ##
//                   O B S E R V E R S                                    ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : key_comp
/// @brief return the object used to compare two keys
/// @param [in] none
/// @return object used to compare two keys
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::key_compare
multiset<Key,Comp,Alloc>::key_comp ( ) const
{   //-------------------------------- begin ----------------------
    return Comp();
};

//----------------------------------------------------------------
//  function : value_comp
/// @brief return the object used to compare two values
/// @param [in] none
/// @return object used to compare two values
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::value_compare
multiset<Key,Comp,Alloc>::value_comp ( ) const
{   //-------------------------------- begin ---------------------
    return Comp();
};

//----------------------------------------------------------------
//  function : get_allocator
/// @brief return the object allocator of the multiset
/// @param [in] none
/// @return object allocator
//-------------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::allocator_type
multiset<Key,Comp,Alloc>::get_allocator() const
{   //-------------------------------- begin ------------------------
    return T.T_Alloc ;
};

//##########################################################################
//                                                                        ##
//                   O P E R A T I O N S                                  ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : find
/// @brief return the iterator to the first element with the key x
/// @param [in] x : key to find in the multiset
/// @return iterator to the element with the key x. If don't exist return end()
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::find ( const key_type& x ) const
{   //------------------------------- begin ----------------------------
    return T.find(x);
};

//----------------------------------------------------------------
//  function : count
/// @brief return the number of elements in the multiset with the key x
/// @param [in] x : key to find
/// @return number of elements in the set with the key x
/// @remarks This operation is log (N)
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::size_type
multiset<Key,Comp,Alloc>::count ( const key_type& x ) const
{   //------------------------------------ begin ------------------------
    return T.count (x);
};

//----------------------------------------------------------------
//  function : lower_bound
/// @brief return one iterator to the first appearance of the key x
///        if exist \n and if don't exist return one iterator to the
///        first element greather than x
/// @param [in] x : key to find
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::lower_bound ( const key_type& x ) const
{   //------------------------------------ begin ---------------------
    return T.lower_bound (x);
};

//----------------------------------------------------------------
//  function : upper_bound
/// @brief return one iterator to the first element greather than x.
///        If don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return iterator
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline typename multiset<Key,Comp,Alloc>::iterator
multiset<Key,Comp,Alloc>::upper_bound ( const key_type& x ) const
{   //------------------------------- begin -------------------------
    return T.upper_bound(x);
};

//----------------------------------------------------------------
//  function :equal_range
/// @brief return a pair of iterators, the first is the lower_bound (x) and
///        the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of iterators
//----------------------------------------------------------------
template < class Key, class Comp, class Alloc >
inline std::pair < typename multiset<Key,Comp,Alloc>::iterator,
                   typename multiset<Key,Comp,Alloc>::iterator  >
multiset<Key,Comp,Alloc>::equal_range ( const key_type& x ) const
{   //----------------------------- begin -----------------------------
    return T.equal_range (x);
};



//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################

#endif

