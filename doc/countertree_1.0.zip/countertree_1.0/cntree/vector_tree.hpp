//----------------------------------------------------------------------------
/// @file   vector_tree.hpp
/// @brief  This file contains the implementation of the vector_tree
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_VECTOR_TREE_HPP
#define __CNTREE_VECTOR_TREE_HPP
#include <boost/cntree/tree/definitions.hpp>
#include <memory>
#include <functional>
#include <boost/cntree/tree/iterator.hpp>
#include <boost/cntree/tree/branch.hpp>


namespace cntree
{

//-------------------------------------------------------------
/// @class  vector_tree
/// @brief  This class have the same interface than the STL vector,
///         but istead of be a vector is a tree. \n
///         Due to this all the operations ( insert, delete, access)
///         a O( logN). \n
//
/// @remarks
//----------------------------------------------------------------
template < typename value_t,typename alloc_t = std::allocator<value_t> >
class vector_tree :protected tree::basic_tree<value_t>
{
public:
	//--------------------------------------------------------------------------
	//                    D E F I N I T I O N S
	//--------------------------------------------------------------------------
	typedef       value_t                           value_type;
	typedef       value_type *                      pointer;
	typedef const value_type *                      const_pointer;
	typedef       value_type &                      reference;
	typedef const value_type &                      const_reference;
	typedef       alloc_t                           allocator_type;

	typedef tree::basic_tree<value_type>            basic_tree;
	typedef tree::branch <value_type>               branch ;

	typedef tree::node<value_type>    node ;
	typedef typename node::pnode               pnode ;
	typedef typename node::const_pnode         const_pnode    ;
	typedef typename node::address_pnode       address_pnode ;
	typedef typename node::refnode             refnode   ;
	typedef typename node::const_refnode       const_refnode ;

	typedef  tree::size_type                        size_type;
	typedef  tree::difference_type                  difference_type;
	typedef  tree::iterator<value_type>             iterator;
	typedef  tree::const_iterator<value_type>       const_iterator;
	typedef  tree::iterator<value_type>             reverse_iterator;
	typedef  tree::const_iterator<value_type>       const_reverse_iterator;


protected:
	//--------------------------------------------------------------------------
	//                     V A R I A B L E S
	//--------------------------------------------------------------------------
	typedef typename alloc_t::template rebind<node >::other node_alloc_t;

	using basic_tree::root ;
	using basic_tree::first ;
	using basic_tree::last ;

	size_type n_level  ;

	node_alloc_t  node_alloc ;
	alloc_t       value_alloc ;

public:
	//--------------------------------------------------------------------------
	//     C O N S T R U C T O R S     A N D    D E S T R U C T O R
	//--------------------------------------------------------------------------
	vector_tree ( const alloc_t &ALLC= alloc_t ());
	vector_tree ( const vector_tree & VT ) ;
	vector_tree( size_type n, const value_type & Val=value_type(),
		         const alloc_t &A= std::allocator<value_type>()  );

	template <class InputIterator>
	vector_tree ( InputIterator it_first ,  InputIterator it_last,
		          const alloc_t& A= std::allocator<value_type>()   );

	virtual  ~vector_tree (void) ;

	//--------------------------------------------------------------------------
	//                     I T E R A T O R S
	//
	//    F I N D _ P O S , B E G I N , E N D , R B E G I N , R E N D
	//--------------------------------------------------------------------------
	bool is_mine ( iterator P1) const;
	bool is_mine ( const_iterator P1) const;

	iterator  	    find_pos ( size_type Pos1);
	const_iterator  find_pos ( size_type Pos1) const;

	iterator   	    begin ( void);
	const_iterator  begin ( void)const;

	iterator   	    rbegin ( void);
	const_iterator  rbegin ( void) const;

	iterator  	    end ( void);
	const_iterator  end ( void)  const;

	iterator  	    rend ( void);
	const_iterator  rend ( void) const;

	//--------------------------------------------------------------------------
	//                     M O D I F I E R S
	//                        O F    T H E
	//                     C O N T A I N E R
	//--------------------------------------------------------------------------
	vector_tree<value_type,alloc_t> &
	operator= (const vector_tree<value_type,alloc_t> &A);

	template <class InputIterator>
	void assign ( InputIterator it_first, InputIterator it_last );

	void assign ( size_type n, const value_type& u );
	void clear(void);
	void swap ( vector_tree <value_type, alloc_t > & A );
#if __DEBUG_CNTREE != 0
	bool check (  void ) const ;
#endif

	//--------------------------------------------------------------------------
	//                     C A P A C I T Y
	//--------------------------------------------------------------------------
	size_type   size ( void) const;
#if __DEBUG_CNTREE != 0
	size_type   levels ( void) const;
#endif
	size_type   max_size (void) const;
	void        resize ( size_type sz,value_type c = value_type() );
	size_type	capacity () const;
	bool        empty () const;
	void        reserve ( size_type n );

    //--------------------------------------------------------------------------
    //                E L E M E N T     A C C E S S
    //--------------------------------------------------------------------------
    value_type       &     at ( size_type Pos );
    const value_type &     at ( size_type Pos)const;

    value_type       &     operator[] ( size_type Pos);
    const value_type &     operator[] ( size_type Pos)const;

    value_type       &     front (void );
    const value_type &     front ( void) const;

    value_type       &     back ( void);
    const value_type &     back (void ) const;

    //--------------------------------------------------------------------------
    //                     I N S E R T I O N S
    //                            O F
    //                      E L E M E N T S
    //--------------------------------------------------------------------------
    iterator    push_front  ( const value_type &D );
    iterator    push_back   ( const value_type & D );

    iterator    insert_pos  ( const value_type & D , size_type Pos);
    iterator    insert      ( iterator  P1 , const value_type &D );
    void        insert      ( iterator  P1 , size_type n , const value_type &D );

    template <typename InputIterator >
    void  insert ( iterator  P1 , InputIterator first1 , InputIterator last1 );

    //--------------------------------------------------------------------------
    //                     D E L E T I O N S
    //                            O F
    //                      E L E M E N T S
    //--------------------------------------------------------------------------
    void        pop_front   ( void );
    void        pop_back    ( void );

    void        erase       ( iterator P1);
    void        erase       ( const_iterator P1);

    size_type   erase       ( iterator first_it, iterator last_it);
    size_type   erase       ( const_iterator first_it, const_iterator last_it);

    void        erase_pos   ( size_type Pos);
    void        erase_pos   ( size_type Prim, size_type Ult);

    //--------------------------------------------------------------------------
    //               O T H E R S        F U N C T I O N S
    //--------------------------------------------------------------------------
#if __DEBUG_CNTREE != 0
    void Imprimir(void)const;
#endif
    alloc_t get_allocator() const;

protected:

    //--------------------------------------------------------------------------
    //            F U N C T I O N S   O F    B A S I C _ T R E E
    //--------------------------------------------------------------------------
    pnode  ptr_pos ( size_type Pos);

    //--------------------------------------------------------------------------
    //            P R O T E C T E D     F U N C T I O N S
    //--------------------------------------------------------------------------
    vector_tree<value_type,alloc_t> * remove_const ( void )const;
    static iterator  remove_const ( const_iterator  CI);

    address_pnode   pointer_father ( pnode P );
    address_pnode   upper_branch ( branch &R , uint32_t & Cod );

    void increment_path ( pnode P );
    void decrement_path ( pnode P );

    void insert_first_pointer   ( pnode PAux );
    void insert_first_element   ( const value_type &Aux );

    void erase_internal     ( pnode PAux );
    void insert_internal    ( pnode PAux , pnode P1, bool Left  );

//########################################################################
};//              E N D  V E C T O R _ T R E E    C L A S S
//########################################################################


//##########################################################################
//                                                                        ##
//               C O N S T R U C T O R S                                  ##
//                      A N D                                             ##
//                D E S T R U C T O R                                     ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : vector_tree
/// @brief  Constructor from an object Allocator
/// @param [in] A : Allocator
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
vector_tree<value_type,alloc_t>::vector_tree ( const alloc_t &ALLC):
n_level(0),value_alloc(ALLC){  } ;

//----------------------------------------------------------------
//  function : vector_tree
/// @brief  Copy constructor
/// @param [in] VT : vector_tree from where copy the data
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
vector_tree<value_type,alloc_t>::vector_tree ( const vector_tree & VT )
                                : n_level(0),value_alloc(VT.value_alloc)
{   //------------------------------ Inicio ---------------------------
    *this = VT ;
} ;

//----------------------------------------------------------------
//  function : vector_tree
/// @brief  Constructor from a value repeated a number of times and
///         an object Allocator
/// @param [in] n : Number of repetitions
/// @param [in] Val : Value to insert
/// @param [in] A : Allocator
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
vector_tree<value_type,alloc_t>::vector_tree( size_type n, const value_type& Val,
                                           const alloc_t &A ):n_level(0),value_alloc(A)
{   //-------------------------------- begin --------------------------
    for ( size_type i = 0 ; i < n ; i ++)push_back (Val);
} ;

//----------------------------------------------------------------
//  function : vector_tree
/// @brief  Constructor from a pair of iterators and an object
///         Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
template <class InputIterator>
vector_tree<value_type,alloc_t>::vector_tree ( InputIterator it_first ,
              InputIterator it_last,
              const alloc_t& A ):n_level(0),value_alloc(A)
{   //-------------------------------- begin -----------------------------
    assign (it_first, it_last) ;
} ;

//----------------------------------------------------------------
//  function : ~vector_tree
/// @brief  Destructor
//----------------------------------------------------------------
template < typename value_type , typename alloc_t>
vector_tree<value_type,alloc_t>::~vector_tree (void)
{   clear();
};

//##########################################################################
//                     I T E R A T O R S                                  ##
//                                                                        ##
//    F I N D _ P O S , B E G I N , E N D , R B E G I N , R E N D         ##
//##########################################################################
//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this vector_tree
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this vector_tree
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline bool vector_tree<value_type,alloc_t>::is_mine ( iterator P1) const
{   //------------------------------- begin ------------------------------
    return ( P1.ptr_basic_tree() == ( basic_tree *)this );
};

//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this vector_tree
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this vector_tree
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline bool vector_tree<value_type,alloc_t>::is_mine ( const_iterator P1) const
{   //------------------------------- begin ------------------------------
    return ( P1.ptr_basic_tree() == ( const basic_tree*)this );
};
//----------------------------------------------------------------------
//  function : find_pos
/// @brief Find a position in the vector_tree
/// @param [in] Pos : Position to find
/// @return Iterator to the position. If don't exists throw an exception
/// @remarks This operation is O ( log N)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::iterator
vector_tree<value_type,alloc_t>::find_pos ( size_type Pos1)
{   //-------------------------- begin --------------------------
    if ( Pos1 < 0) return rend();
    if ( Pos1 >= size()  )  return end() ;
    return iterator (ptr_pos (Pos1) , this) ;
};

//----------------------------------------------------------------------
//  function : find_pos
/// @brief Find a position in the vector_tree
/// @param [in] Pos : Position to find
/// @return const_iterator to the position. If don't exists throws
///         an exception
/// @remarks This operation is O ( log N)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::const_iterator
vector_tree<value_type,alloc_t>::find_pos ( size_type Pos1) const
{   //--------------------- Inicio -----------------------------
    if ( Pos1 < 0) return rend();
    if ( Pos1 >= size()  )  return end() ;
    return const_iterator (ptr_pos (Pos1) , this) ;
};

//----------------------------------------------------------------
//  function : begin
/// @brief return one iterator to the first element
/// @return iterator to the first element
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::iterator
vector_tree<value_type,alloc_t>::begin ( void)
{   //-------------------------- Inicio ---------------------------
    return iterator::begin(this);
};

//----------------------------------------------------------------
//  function : begin
/// @brief Return one const_iterator to the first element
/// @return Const_iterator to the first element
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::const_iterator
vector_tree<value_type,alloc_t>::begin ( void)const
{   //-------------------------- Inicio ---------------------------
    return  const_iterator::begin(this);
};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one iterator to the last element
/// @return iterator to the last element
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::iterator
vector_tree<value_type,alloc_t>::rbegin ( void)
{   //-------------------------- Inicio ---------------------------
    return iterator::rbegin(this) ;
};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one const_iterator to the last element
/// @return const_iterator to the last element
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::const_iterator
vector_tree<value_type,alloc_t>::rbegin ( void) const
{   //-------------------------- Inicio ---------------------------
    return const_iterator::rbegin(this);
};

//----------------------------------------------------------------
//  function : end
/// @brief Return one iterator to the next element after the last
/// @return Iterator to the next element after the last
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::iterator
vector_tree<value_type,alloc_t>::end ( void)
{   return iterator::end(this);
};

//----------------------------------------------------------------
//  function : end
/// @brief Return one const_iterator to the next element after the last
/// @return Const_terator to the next element after the last
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::const_iterator
vector_tree<value_type,alloc_t>::end ( void)  const
{   return const_iterator::end(this);
};

//----------------------------------------------------------------
//  function : rend
/// @brief return one iterator to the previous elemento to the first
/// @return iterator to the previous elemento to the first
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::iterator
vector_tree<value_type,alloc_t>::rend ( void)
{   return iterator::rend(this );
};

//----------------------------------------------------------------
//  function : rend
/// @brief return one const_iterator to the previous elemento to the first
/// @return const_iterator to the previous elemento to the first
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::const_iterator
vector_tree<value_type,alloc_t>::rend ( void) const
{   return const_iterator::rend(this );
};

//##########################################################################
//                                                                        ##
//                     M O D I F I E R S                                  ##
//                        O F    T H E                                    ##
//                     C O N T A I N E R                                  ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : operator =
/// @brief Asignation operator
/// @param [in] A : vector_tree from where copy the data
/// @return Reference to the vector_tree after the copy
//---------------------------------------------------------------
template < typename value_type , typename alloc_t>
vector_tree<value_type,alloc_t> &
vector_tree<value_type,alloc_t>::operator= (const vector_tree<value_type,alloc_t> &A)
{   //------------- Inicio -------------------
    clear() ;
    pnode  P= NULL ;
    pnode PA = A.root ;
    if ( PA != NULL )
    {   P = node_alloc.allocate ( 1) ;
        node_alloc.construct ( P ,*PA ) ;
        P->up = NULL ;
        root = P ;
    };
    while ( PA != NULL )
    {   if ( P->right == NULL and PA->right != NULL )
        {   P->right = node_alloc.allocate (1) ;
            node_alloc.construct (P->right, *(PA->right)) ;
            P->right->up = P ;
            P = P->right ;
            PA = PA->right ;
        }
        else
        {   if ( P->left == NULL and PA->left != NULL )
            {   P->left = node_alloc.allocate (1) ;
                node_alloc.construct (P->left ,* ( PA->left)) ;
                P->left->up = P ;
                P = P->left ;
                PA = PA->left ;
            }
            else
            {   P = P->up ;
                PA = PA->up ;
            };
        };
    };
    n_level = A.n_level ;
    if (root == NULL) first= last = NULL ;
    else
    {   pnode P1 = root ;
        while ( P1->left != NULL ) P1 = P1->left ;
        first = P1 ;
        P1 = root ;
        while ( P1->right != NULL ) P1 = P1->right ;
        last = P1 ;
    };
    return *this ;
};

//----------------------------------------------------------------
//  function : assign
/// @brief Assign a range of data, dropping all the elements of the
///        container
/// @param [in] it_first : iterator to the first element to insert
/// @param [in] it_last : Iterator to the end of the range
/// @return none
//---------------------------------------------------------------
template < typename value_type, typename alloc_t >
template <class InputIterator>
inline void vector_tree<value_type,alloc_t>::assign ( InputIterator it_first,
                                                      InputIterator it_last )
{   //---------------------------- begin -------------------------
    clear() ;
    for ( ; it_first != it_last ; ++it_first) push_back ( *it_first);
};

//----------------------------------------------------------------
//  function : assign
/// @brief Assign a range of data, dropping all the elements of the
///        container
/// @param [in] n : number of elements to insert
/// @param [in] u : value to insert
/// @return none
//---------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::assign ( size_type n, const value_type& u )
{   //---------------------------- begin --------------------------
    if (  n < 0 ) throw std::invalid_argument("");
    clear () ;
    for ( size_type i = 0 ; i < n ; ++i) push_back(u);
};

//----------------------------------------------------------------
//  function : clear
/// @brief Delete all the elements of the vector_tree
/// @param [in] none
/// @return none
//----------------------------------------------------------------
template < typename value_type , typename alloc_t>
void vector_tree<value_type,alloc_t>::clear(void)
{   //------------ Begin -----------------------
    pnode P1 = root ;
    pnode P2 = NULL ;
    while ( P1 != NULL )
    {   P2 = P1 ;
        if ( P1->right != NULL )
        {   P1= P1->right ;
            P2->right = NULL ;
        }
        else
        {   if ( P1->left != NULL )
            {   P1 = P1->left ;
                P2->left = NULL ;
            }
            else
            {   P1 = P1->up ;
                node_alloc.destroy ( P2) ;
                node_alloc.deallocate ( P2,1) ;
            };
        };
    };
    root = first = last = NULL ;
    n_level = 0 ;
};

//----------------------------------------------------------------
//  function : swap
/// @brief swap the data between the two vector_tree
/// @param [in] A : vector_tree to swap
/// @return none
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::swap ( vector_tree <value_type, alloc_t > & A )
{   //----------------------- begin ----------------------
    std::swap ( root    , A.root   );
    std::swap ( first   , A.first  );
    std::swap ( last    , A.last   );
    std::swap ( n_level , A.n_level);
};

//##########################################################################
//                                                                        ##
//                     C A P A C I T Y                                    ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : size
/// @brief return the number of elements in the vector_tree
/// @return number of elements in the vector_tree
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::size ( void) const
{   return basic_tree::n_elem();
};

#if __DEBUG_CNTREE != 0
//----------------------------------------------------------------
//  function : levels
/// @brief return the number of levels in the vector_tree
/// @return number of levels in the vector_tree
/// @remarks This function is for debug
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::levels ( void) const
{   return n_level;
};
#endif

//----------------------------------------------------------------
//  function :max_size
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::max_size (void) const
{   //return bct::size_type_max;
    return std::numeric_limits<size_type>::max();
};

//----------------------------------------------------------------
//  function : resize
/// @brief resize the current vector size and change to sz.\n
///        If sz is smaller than the current size, delete elements to end\n
///        If sz is greater than the current size, insert elements to the
///        end with the value c
/// @param [in] sz : new size of the vector_tree after the resize
/// @param [in] c : Value to insert if sz is greather than the current size
/// @return none
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::resize ( size_type sz,value_type c )
{   //------------------------ begin ----------------------------
    if ( sz < 0 ) throw std::invalid_argument("");
    if ( size() >= sz)  while  ( sz != size())pop_back() ;
    else  for ( size_type i = size() ; i < sz; ++i) push_back (c);
};

//----------------------------------------------------------------
//  function : capacity
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::capacity () const
{   //return bct::size_type_max;
    return std::numeric_limits<size_type>::max();
};

//----------------------------------------------------------------
//  function : empty
/// @brief indicate if the map is empty
/// @return true if the map is empty, false in any other case
//----------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline bool vector_tree<value_type,alloc_t>::empty () const
{   return (size() == 0 );
};

//------------------------------------------------------------------------
//  function : reserve
/// @brief Change the capacity for to contain , at least n elements
/// @param [in] n : number of elements for the new capacity
/// @return none
/// @remarks This function has not utility. It is provided only for
///          compatibility with the STL vector interface
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::reserve ( size_type n ){};

//##########################################################################
//                                                                        ##
//                E L E M E N T     A C C E S S                           ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : at
/// @brief  Checked access to an element by their position in the vector_tree
/// @param  [in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This operation is  O (log(N))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline value_type &
vector_tree<value_type,alloc_t>::at  ( size_type Pos )
{  return  ptr_pos (Pos)->data;
};

//------------------------------------------------------------------------
//  function : at
/// @brief  Checked access to an element by their position in the vector_tree
/// @param  [in] Pos : Position to read
/// @return Const reference to the object selected
/// @remarks This operation is O (log(N))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline const value_type &
vector_tree<value_type,alloc_t>::at ( size_type Pos)const
{   return remove_const()->at(Pos);
};

//------------------------------------------------------------------------
//  function : operator[ ]
/// @brief  Checked access to an element by their position in the vector_tree
/// @param  [in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This operation is O (log(N))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline value_type &
vector_tree<value_type,alloc_t>::operator[] ( size_type Pos)
{   return (at(Pos));
};

//------------------------------------------------------------------------
//  function : operator[ ]
/// @brief  Checked access to an element by their position in the vector_tree
/// @param  [in] Pos : Position to read
/// @return Const reference to the object selected
/// @remarks This operation is  O(log(N))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline const value_type &
vector_tree<value_type,alloc_t>::operator[] ( size_type Pos)const
{   return at(Pos);
};

//------------------------------------------------------------------------
//  function : front
/// @brief  Return a reference to the first element in the vector_tree
/// @param  [in]  none
/// @return reference to the first element
/// @remarks This operation is  O(constant))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline value_type & vector_tree<value_type,alloc_t>::front (void )
{   //-------------------------------- begin ----------------------
    if ( first == NULL )  throw std::invalid_argument("");
    return first->data ;
};

//------------------------------------------------------------------------
//  function : front
/// @brief  Return a const_reference to the first element in the vector_tree
/// @param  [in]  none
/// @return const_reference to the first element
/// @remarks This operation is  O(constant))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline const value_type & vector_tree<value_type,alloc_t>::front ( void) const
{   //-------------------------------- begin ----------------------
    if  ( first == NULL ) throw std::invalid_argument("");
    return first->data ;
};

//------------------------------------------------------------------------
//  function : back
/// @brief  Return a reference to the last element in the vector_tree
/// @param  [in]  none
/// @return reference to the last element
/// @remarks This operation is  O(constant))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline value_type & vector_tree<value_type,alloc_t>::back ( void)
{   //-------------------------------- begin ----------------------
    if ( last == NULL ) throw std::invalid_argument("");
    return last->data ;
};

//------------------------------------------------------------------------
//  function : back
/// @brief  Return a const_reference to the last element in the vector_tree
/// @param  [in]  none
/// @return const_reference to the last element
/// @remarks This operation is  O(constant))
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline const value_type & vector_tree<value_type,alloc_t>::back (void ) const
{   //-------------------------------- begin ----------------------
    if ( last == NULL ) throw std::invalid_argument("");
    return last->data ;
};

//##########################################################################
//                                                                        ##
//                     I N S E R T I O N S                                ##
//                            O F                                         ##
//                      E L E M E N T S                                   ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : push_front
/// @brief insert an element in the front of the container
/// @param [in] D : value to insert
/// @return iterator to the element inserted
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < typename value_type , typename alloc_t>
tree::iterator<value_type>
vector_tree<value_type,alloc_t>::push_front ( const value_type &D )
{   //------------------- Inicio ---------------------------------
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux,  D ) ;
    increment_path(first);
    insert_internal( PAux, first, true);
    return iterator ( PAux, this );
};

//------------------------------------------------------------------------
//  function : push_back
/// @brief Insert one element in the back of the container
/// @param [in] D : value to insert
/// @return iterator to the element inserted
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
template < typename value_type , typename alloc_t>
tree::iterator<value_type>
vector_tree<value_type,alloc_t>::push_back ( const value_type & D )
{   //------------------- Inicio ---------------------------------
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux,  D ) ;
    increment_path(last);
    insert_internal( PAux, last, false);
    return iterator ( PAux ,this);
};

//------------------------------------------------------------------------
//  function : insert_pos
/// @brief insert an element in a specified position
/// @param [in] D : value to insert
/// @param [in] Pos : Position to insert the value
/// @return iterator to the element inserted
/// @remarks This operation is O ( log(N) )
//------------------------------------------------------------------------
template < typename value_type , typename alloc_t>
tree::iterator<value_type>
vector_tree<value_type,alloc_t>::insert_pos(const value_type &D,size_type Pos)
{   //------------------- Inicio ---------------------------------
    if ( Pos < 0 or Pos > size()) throw std::invalid_argument("");
    if ( Pos == 0      ) return push_front (D);
    if ( Pos == size() ) return push_back  (D);

    //-------------------------------------------------------------
    // Busqueda del puntero para enlazar el node
    //-------------------------------------------------------------
    address_pnode PP1 =  (address_pnode)&root;
    pnode P2 = root ;
    size_type N1 = 0 ;
    while ( *PP1 != NULL )
    {   P2 = *PP1 ;
        P2->N++ ;
        if ( Pos > (N1 = P2->n_left()) )
        {   Pos -= ( N1 + 1 ) ;
            PP1 =  (&(P2->right)) ;
        }
        else PP1 =  (&(P2->left)) ;
    };
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux,  D ) ;
    insert_internal ( PAux , P2, (&(P2->left)== PP1 ) ) ;
    return iterator ( PAux,this) ;
};

//------------------------------------------------------------------------
//  function : insert
/// @brief insert an element in a  position specified by an iterator
/// @param [in] P1 : Itera which indicates the position to insert the value
/// @param [in] D : value to insert
/// @return iterator to the element inserted
/// @remarks If the iterator is rend()  there is an error  because we
///          can't insert before it
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline tree::iterator<value_type>
vector_tree<value_type,alloc_t>::insert ( iterator  P1 , const value_type &D )
{   //------------------------------ begin ----------------------------
    size_type Pos = 0 ;
    if ( not is_mine ( P1) or ( Pos = P1.pos() ) < 0) throw std::invalid_argument("");
    return insert_pos ( D , Pos);
};
//------------------------------------------------------------------------
//  function : insert
/// @brief insert n elements with the value D element in the position
///        specified by an iterator
/// @param [in] P1 : Iterator which indicates the position to insert the value
/// @param [in] n : Number of elements to insert
/// @param [in] D : value to insert
/// @return none
/// @remarks If the iterator is rend()  there is an error  because we
///          can't insert before it
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void  vector_tree<value_type,alloc_t>::insert ( iterator  P1 , size_type n ,
                                                       const value_type &D )
{   //------------------------------ begin ----------------------------
    size_type Pos = 0 ;
    if ( not is_mine( P1) or ( Pos = P1.pos()) < 0  ) throw std::invalid_argument("");
    for ( size_type i = 0 ; i < n ; ++i)
        insert_pos ( D , Pos+i);
};
//------------------------------------------------------------------------
//  function : insert
/// @brief insert n elements with the value D element in the position
///        specified by an iterator
/// @param [in] P1 : Iterator which indicates the position to insert the value
/// @param [in] first : InputIterator to thje first element
/// @param [in] last : InputIterator to the next element of the last
/// @return none
/// @remarks If the iterator is rend()  there is an error  because we
///          can't insert before it
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
template <typename InputIterator >
void  vector_tree<value_type,alloc_t>::insert (iterator P1,
                                                      InputIterator first1 ,
                                                      InputIterator last1 )
{   //------------------------------ begin ----------------------------
    size_type Pos = 0 ;
    if ( not is_mine( P1) or ( Pos = P1.pos()) < 0  )  throw std::invalid_argument("");

    for ( ; first1 != last1 ; ++first1, ++Pos)
        insert_pos ( (* first1) , Pos);
};

//##########################################################################
//                                                                        ##
//                     D E L E T I O N S                                  ##
//                            O F                                         ##
//                      E L E M E N T S                                   ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : pop_front
/// @brief erase the first element of the container
/// @param [in] none
/// @return none
/// @remarks This operation is O (constant)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::pop_front ( void )
{   //-------------------- Inicio ---------------------------------
    if  ( size() < 1  ) throw std::invalid_argument("");
    pnode PAux =first ;
    erase_internal ( PAux ) ;
    node_alloc.destroy ( PAux ) ;
    node_alloc.deallocate ( PAux, 1 ) ;
};

//------------------------------------------------------------------------
//  function :pop_back
/// @brief erase the last element of the container
/// @param [in] none
/// @return none
/// @remarks This operation is O(constant)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::pop_back ( void)
{   //-------------------- Inicio ---------------------------------
    if ( size() < 1  ) throw std::invalid_argument("");
    pnode PAux =last ;
    erase_internal ( PAux ) ;
    node_alloc.destroy ( PAux ) ;
    node_alloc.deallocate ( PAux,1 ) ;
};

//------------------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by the iterator P1
/// @param [in] P1 : iterator to the element to erase
/// @return none
/// @remarks This operation is O ( constant)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::erase ( iterator P1)
{   //-------------------- Inicio ---------------------------------
    if ( size() < 1 or not is_mine(P1)) throw std::invalid_argument("");
    erase_internal ( P1.ptr() ) ;
    node_alloc.destroy ( P1.ptr() ) ;
    node_alloc.deallocate  ( P1.ptr(),1 ) ;
};
//------------------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by the iterator P1
/// @param [in] P1 : iterator to the element to erase
/// @return none
/// @remarks This operation is O ( constant)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::erase ( const_iterator P1)
{   //-------------------- Inicio ---------------------------------
    erase ( remove_const ( P1));
};


//------------------------------------------------------------------------
//  function : erase
/// @brief erase a range of elements between first_it and last_it
/// @param [in] first_it : iterator to the first element
/// @param [in] last_it : iterator to the final element of the range
/// @return number of elements erased
/// @remarks
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::erase ( iterator first_it, iterator last_it)
{   //--------------------------- begin ----------------------------
    if ( not is_mine( first_it) or not is_mine( last_it)) throw std::invalid_argument("");
    if ( first_it == last_it ) return 0 ;
    size_type N= last_it - first_it ;
    iterator Alfa = first_it, Beta = first_it ;
    do
    {   Alfa = Beta ;
        Beta++ ;
        erase(Alfa);
    } while ( Beta != last_it);
    return N ;
};
//------------------------------------------------------------------------
//  function : erase
/// @brief erase a range of elements between first_it and last_it
/// @param [in] first_it : iterator to the first element
/// @param [in] last_it : iterator to the final element of the range
/// @return number of elements erased
/// @remarks
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
typename vector_tree<value_type,alloc_t>::size_type
vector_tree<value_type,alloc_t>::erase ( const_iterator first_it, const_iterator last_it)
{   //--------------------------- begin ----------------------------
    return erase ( remove_const(first_it), remove_const (last_it));
};

//------------------------------------------------------------------------
//  function : erase_pos
/// @brief erase the element of the position pos
/// @param [in] pos : position to delete
/// @return void
/// @remarks This operation is O ( log(N) )
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::erase_pos( size_type Pos)
{   //-------------------- Inicio ---------------------------------
    if( Pos < 0 or Pos >= size()  )  throw std::invalid_argument("");

    iterator C = find_pos ( Pos) ;
    erase_internal ( C.ptr() ) ;
    node_alloc.destroy ( C.ptr() ) ;
    node_alloc.deallocate ( C.ptr(), 1 ) ;
};

//------------------------------------------------------------------------
//  function : erase_pos
/// @brief erase the lements between the position Prim and the position Ult.
///        The position Ult is deleted
/// @param [in] Prim : position to the first element to erase
/// @param [in] Position to the last element to erase
/// @return void
/// @remarks
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
void vector_tree<value_type,alloc_t>::erase_pos ( size_type Prim, size_type Ult)
{   //--------------- Inicio  ------------------
    if ( Prim < 0 or Ult < 0 or Prim > Ult or Ult >= size() ) throw std::invalid_argument("");

    size_type N = Ult - Prim +1 ;
    iterator C2 = find_pos ( Prim), C1 ;
    for ( size_type i = 0 ; i < N ; i ++)
    {   C1 = C2 ;
        C2++ ;
        erase_internal ( C1.ptr() ) ;
        node_alloc.destroy ( C1.ptr() ) ;
        node_alloc.deallocate ( C1.ptr(), 1 ) ;
    };
    return ;
};
//##########################################################################
//                                                                        ##
//               O T H E R S        F U N C T I O N S                     ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : get_allocator
/// @brief return the object allocator of the vector_tree
/// @param [in] none
/// @return object allocator
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline alloc_t vector_tree<value_type,alloc_t>::get_allocator() const
{   return value_alloc ;
};

//##########################################################################
//                                                                        ##
//            F U N C T I O N S   O F    B A S I C _ T R E E              ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------------
//  function : ptr_pos
/// @brief Find a position in the vector_tree
/// @param [in] Pos : Position to find
/// @return pointer to the position. If don't exists throw an exception
/// @remarks This operation is O ( log N)
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::pnode
vector_tree<value_type,alloc_t>::ptr_pos ( size_type Pos)
{   //-------------------------- begin --------------------------
    if ( Pos < 0 or Pos >= size()) throw std::invalid_argument("");
    if ( Pos == 0 ) return first ;
    if ( Pos == size()-1) return last ;
    pnode PH = root ;
    size_type NI ;
    while ( ( NI = PH->n_left() ) != Pos)
    {   if ( Pos < NI )  PH = PH->left ;
        else
        {   PH = PH->right;
            Pos -= ( NI +1) ;
        };
    };
    return PH ;
};


//##########################################################################
//                                                                        ##
//            P R O T E C T E D     F U N C T I O N S                     ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : remove_const
/// @brief remove the attribute const of a const pointer to the vector_tree
/// @param [in] none
/// @return pointer to vector_tree
/// @remarks
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline vector_tree<value_type,alloc_t> *
vector_tree<value_type,alloc_t>::remove_const ( void )const
{   //--------------------- Inicio -----------------------------
    return const_cast <vector_tree <value_type,alloc_t>*> ( this);
};

//------------------------------------------------------------------------
//  function : remove_const
/// @brief convert a const_iterator to an iterator
/// @param [in] CI : const_iterator to convert
/// @return iterator
/// @remarks
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline tree::iterator<value_type>
vector_tree<value_type,alloc_t>::remove_const ( const_iterator  CI )
{   //--------------------- Inicio -----------------------------
    node * P1 = const_cast < node *> ( CI.ptr());
    basic_tree * P2 = const_cast <basic_tree  *> ( CI.ptr_basic_tree());

    return iterator ( P1,P2 );
};


//------------------------------------------------------------------------
//  function : pointer_father
/// @brief return a pointer to pointer to the node black of the branch
/// @param [in] P : pointer to a node
/// @return pointer to pointer to the black node of the branch
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline typename vector_tree<value_type,alloc_t>::address_pnode
vector_tree<value_type,alloc_t>::pointer_father ( pnode P )
{   //----------------------- Inicio --------------------------
    if  ( P == NULL )  throw std::invalid_argument("");
    pnode Pup = P->up ;
    if ( Pup == NULL )
    {   assert ( root == P ) ;
        return ( &root) ;
    };
    return ((Pup->left == P)?& ( Pup->left ) : &(Pup->right )) ;
};

//------------------------------------------------------------------------
//  function : upper_branch
/// @brief Take the address of the pointer to the upper branch.\n
///        It provides too, the code of the pointer in the upper branch wich
///        connect the two branch
/// @param [in] R : lower branch
/// @param [in] Cod : code of the pointer which connect the two branchs\n
///             The description of this code is\n
///                 000 : pointer left black node\n
///                 001 : pointer right black node\n
///                 010 : pointer left  of left node\n
///                 011 : pointer right of left node\n
///                 100 : pointer left of right node\n
///                 101 : pointer right of right node
/// @return Address of the pointer to the upper branch
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
typename vector_tree<value_type,alloc_t>::address_pnode
vector_tree<value_type,alloc_t>::upper_branch ( branch &R , uint32_t & Cod )
{   //--------------------------- Inicio ----------------------
    Cod = 0 ;
    pnode PBlack = *R.ppblack;
    pnode up = PBlack->up ;
    pnode Inf = PBlack ;
    if ( up == NULL ) return NULL ;
    if ( up->right == Inf ) Cod ++ ;
    if ( up->is_red() )
    {   Inf = up ;
        up = up->up ;
        Cod += (up->left == Inf ) ? 2 : 4 ;
    };
    if ( up->is_black() )
    {   Inf = up ;
        up = up->up ;
        if ( up == NULL ) return  &root ;
        return  ((up->left == Inf)?&(up->left):&(up->right)) ;
    };
    assert(false);
    return NULL ;
};

//------------------------------------------------------------------------
//  function :increment_path
/// @brief increment the path from the pointer P to the root
/// @param [in] P : initial pointer
/// @return none
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::increment_path ( pnode  P )
{   //------------------------ Inicio ----------------------------
    while ( P != NULL)
    {   P->N++;
        P = P->up ;
    };
};

//------------------------------------------------------------------------
//  function : decrement_path
/// @brief decrement the path from  the pointer P to the root
/// @param [in] P : initial pointer
/// @return none
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::decrement_path ( pnode P )
{   //------------------------ Inicio ----------------------------
    while ( P != NULL)
    {   P->N--;
        P = P->up ;
    };
};

//------------------------------------------------------------------------
// function : insert_first_pointer
/// @brief insertion with the node constructed
/// @param [in] PAux : pointer to the new node
/// @return none
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::insert_first_pointer( pnode PAux )
{   //------------------------------- Inicio ----------------------------------
    if  ( root != NULL) throw std::invalid_argument("");

    first= last=root = PAux ;
    n_level = 1 ;
    PAux->init() ;
    PAux->set_black() ;
};

//------------------------------------------------------------------------
//  function : insert_first_element
/// @brief insertion with the node not constructed
/// @param [in] PAux : pointer to the new node
/// @return none
//------------------------------------------------------------------------
template < typename value_type, typename alloc_t >
inline void vector_tree<value_type,alloc_t>::insert_first_element( const value_type &Aux )
{   //------------------------------- Inicio ----------------------------------
    if ( root != NULL) throw std::invalid_argument("");
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux,  Aux ) ;
    insert_first_pointer (PAux);
};

//------------------------------------------------------------------------
//  function :erase_internal
/// @brief disconnect the node from the vector_tree, and leave it balanced
///        and with the nodes actualized
/// @param [in] PAux : pointer to the node to delete
/// @return none
//  @remarks The counters are decremented by this function
//------------------------------------------------------------------------
template < typename value_type , typename alloc_t>
void vector_tree<value_type,alloc_t>::erase_internal ( pnode PAux )
{   //------------------------------ Inicio ------------------------
    if ( PAux == NULL or root == NULL or( PAux->up == NULL and root != PAux))
        throw std::invalid_argument ("vector_tree::erase_internal");
    if ( size() == 1)
    {   root = first = last = NULL ;
        n_level = 0 ;
        return ;
    };
    //--------------------------------------------------------------
    // Calculo de first y last
    //--------------------------------------------------------------
    if ( PAux == first)
    {   first= ( first->right != NULL)? first->right:first->up ;
    };

    if ( PAux == last)
    {   last = (last->left != NULL)?last->left : last->up ;
    } ;
    //--------------------------------------------------------------
    // Busqueda del sustituto para colocarlo en el lugar de PAux
    //--------------------------------------------------------------
    pnode P = PAux ;
    if ( P->left != NULL)
    {   P = P->left ;
        if ( P->right == NULL )
            node::swap_contiguous_left ( pointer_father(PAux));
        else
        {   while ( P->right != NULL) P = P->right ;
            node::swap_node ( pointer_father(PAux), pointer_father(P));
        };
    };
    //-----------------------------------------------------------------
    // En este punto sabemos que el node apuntado por PP esta en la
    // ultima hoja y que puede ser desconectado
    //------------------------------------------------------------------
    P = PAux ;
    decrement_path ( P);
    uint32_t Cod2 = 0 ;
    if ( P->is_red())
    {   Cod2 = ( P->up->left == P ) ? 2 :4 ;
        P = P->up ;
    };
    // Ahora P apunta al node negro de la rama
    address_pnode PP = pointer_father ( P) ;
    branch H ( PP);

    uint32_t Cod = 0;
    address_pnode PPup = upper_branch ( H, Cod) ;

    bool Estable = H.disconnect_node( Cod2, PAux);
    if ( Estable ) return ;

    branch RInf ( H ), Rup ( H ) ;
    while ( not Estable)
    {
        if ( PPup == NULL)
        {   Estable = true ;
            n_level-- ;
            if ( root != NULL ) root->set_black() ;
        }
        else
        {   Rup.ppblack = PPup ;
            Estable = branch::reverse_cake ( Rup, RInf , Cod );
            RInf = Rup ;
            PPup = upper_branch ( RInf, Cod);
        };
    };
    return ;
};

//------------------------------------------------------------------------
//  function : insert_internal
/// @brief Insert a node in the vector_tree and make a rebalanced if necessary
/// @param [in] PAux : pointer to the node for to be inserted
/// @param [in] P1 : pointer to the node where insert PAux
/// @param [in] Left : indicates which node of P1 link to PAux
/// @return none
/// @remarks If the vector_tree is empty P1 and Left are not checked\n
///          This function works well when the vector_tree is empty\n
///          All the counters of the nodes from the insertion point to
///          the root must be previously incremented
//------------------------------------------------------------------------
template < typename value_type , typename alloc_t>
void vector_tree<value_type,alloc_t>::insert_internal(pnode PAux,pnode P1,bool Left)
{   //------------------------------- Inicio ----------------------------------
    if ( PAux == NULL )
        throw std::invalid_argument  ("vector_tree::insert_internal");

    //------------------------------------------------------------------------
    // Cuando el vector_tree está vacío *PP1 == NULL
    //------------------------------------------------------------------------
    if ( root == NULL)
    {   insert_first_pointer (PAux );
        return  ;
    };
    if ( P1 == NULL or ((Left)?P1->left:P1->right) != NULL )
        throw std::invalid_argument  ("vector_tree::insert_internal");

    //------------------------------------------------------------------------
    // Calculo de la direccion al puntero del nodo negro y el codigo del puntero
    //---------------------------------------------------------------------------
    uint32_t Cod = ( Left)?0:1 ;
    pnode PBlack = P1 ;
    if ( PBlack->is_red() )
    {   PBlack = PBlack->up ;
        Cod += ((PBlack->left == P1)?2:4 );
    };
    address_pnode PP1 =  pointer_father( PBlack);

    //-----------------------------------------------------------------------
    // Insercion del node en la branch
    //-----------------------------------------------------------------------
    branch H (PP1);
    H.insert_node( PAux, Cod);
    if ( H.n_nodes() < 4)
    {   if ( first->left != NULL) first = first->left ;
        if ( last->right != NULL) last = last->right;
        return;
    } ;

    //-----------------------------------------------------------------------
    // La branch es inestable y hay que Partir Galleta
    //-----------------------------------------------------------------------
    branch RInf ( H ), Rup ( H) ;
    size_type  NInf = RInf.n_nodes() , Nup = 0 ;
    bool Estable = ( NInf != 4 ) ;
    while ( not Estable)
    {   PP1= upper_branch( RInf,Cod) ;
        branch::break_cake( RInf) ;
        if ( PP1 == NULL)
        {   root->set_black() ;
            n_level++ ;
            Estable = true ;
        }
        else
        {   Rup = branch ( PP1);
            Nup = Rup.n_nodes() ;
            Estable = (Nup == 4)?false : true ;
            //----------------------------------------------------------------
            // Si la rama  que ha recibido el node de la rotura de galleta de
            // la rama inferior, tiene mas de 3 nodes, Ha de partir galleta y
            // continuar el proceso en la rama superior
            // Si el código del enlace  del que cuelga es menor que 2, sabemos
            // positivamente que la rama no tiene mas de 3 nodes , y que no
            // necesita hacer rotaciones .
            // Si el código es mayor que 2, y no tiene mas de 3 nodes, implica
            // que hay que hacer una rotación. En cada una de las 4 posibles
            // variantes hay una rotación diferente.
            // Despues de esta rotacion la rama y por tanto el vector_tree quedan
            // estables, por lo que el proceso finaliza
            //------------------------------------------------------------------
            if (  Nup == 3 )
            {   switch ( Cod )
                {   case 2: Rup.rotate_right_aligned()   ; break ;
                    case 3: Rup.rotate_right_not_aligned() ; break ;
                    case 4: Rup.rotate_left_not_aligned() ; break ;
                    case 5: Rup.rotate_left_aligned()   ; break ;
                    default: ;
               };
            };
            RInf = Rup;
            NInf = Nup ;
        }; // end if
    }; // end while
    //----------------------------------------------------------------------
    // Si PP1 == NULL , indica que hemos alcanzado el node root.
    // En este punto solo tenemos que incrementar el contador de niveles
    //----------------------------------------------------------------------
    //----------------------------------------------------------------------
    // Calculo de first y last
    //----------------------------------------------------------------------
    if ( PAux ->left == NULL)
    {   if ( first->left == PAux or PAux->right == first)
            first = PAux ;
    };
    if ( PAux->right == NULL)
    {   if ( last->right == PAux or PAux->left == last)
            last = PAux ;
    }
};
//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
