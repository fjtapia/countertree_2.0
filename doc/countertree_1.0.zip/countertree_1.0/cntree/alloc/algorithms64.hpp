//----------------------------------------------------------------------------
/// @file algorithms64.hpp
/// @brief This file contains the description of the classes heap_fixed_node
///        and heap_node
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanying file LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_ALLOC_ALGORITHMS64_HPP
#define __CNTREE_ALLOC_ALGORITHMS64_HPP

#include <boost/cntree/alloc/definitions.hpp>
#include <boost/cntree/alloc/config.hpp>
#include <cassert>
#include <stdexcept>
#include <string.h>
#include <iostream>

namespace cntree
{
namespace alloc
{
typedef uint64_t * NOALIAS PW64 ;

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                B A S I C                         #             ##
//       #                                                  #             ##
//       #         A L G O R I T H M S     6 4  B i t s     #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : first_zero64
/// @brief Calculate the position of the first bit with value 0 , beginning
///        from the bit 0 to the bit 63
/// @param [in] N : Number to examinate
/// @return Position of the first bit with value 0 .
/// @remarks
//------------------------------------------------------------------------
inline uint64_t first_zero64 ( uint64_t N)
{   //----------------------- begin ------------------------------
#if __DEBUG_CNTREE != 0
    assert ( N != MAX64 ) ;
#endif
    uint64_t Pos = 0 ;

    if ( (N & 0xffffffff)== 0xffffffffULL )
    {   N >>= 32 ;
        Pos += 32 ;
    };
    if ( (N & 0xffff)== 0xffff )
    {   N >>= 16 ;
        Pos += 16 ;
    };
    if ( (N & 0xff)== 0xff )
    {   N >>= 8 ;
        Pos += 8 ;
    };
    if ( (N & 0xf)== 0xf )
    {   N >>= 4 ;
        Pos += 4 ;
    };
    if ( (N & 0x3)== 0x3 )
    {   N >>= 2 ;
        Pos += 2 ;
    };
    if ( (N & 0x1)== 0x1 )
    {   Pos += 1 ;
    };
    return Pos ;
};
inline uint64_t shift_right64 ( uint64_t N , uint64_t NBits)
{   return ( NBits > 63) ? 0 : (N>>NBits) ;
};

inline uint64_t shift_left64 ( uint64_t N , uint64_t NBits)
{   return ( NBits > 63) ? 0 : (N<<NBits) ;
};
//------------------------------------------------------------------------
//  function : set_zero64
/// @brief Set to zero the bit Pos in a uint64_t element N
/// @param [in] N : word where put to zero a bit
/// @param [in] Pos : position of the bit in  set to zero
//------------------------------------------------------------------------
inline void set_zero64 ( uint64_t &N , uint64_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 64 ) ;
#endif
    ( N &= (~(1ULL<<Pos)));
};

//------------------------------------------------------------------------
//  function : set_one64
/// @brief Set to one the bit Pos in a uint64_t element N
/// @param [in] N : word where put to one a bite
/// @param [in] Pos : position of the bit in  set to one
//------------------------------------------------------------------------
inline void set_one64 ( uint64_t &N , uint64_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 64 ) ;
#endif
    ( N |= (1ULL<<Pos));
};

//------------------------------------------------------------------------
//  function : read_bit64
/// @brief Return the content of the bit Pos in the uint64_t element N
/// @param [in] N : uint64_t element from read the birt
/// @param [in] Pos : Position of the bit readed
/// @return Value of the bit (true :1 , false :0)
/// @remarks
//------------------------------------------------------------------------
inline bool read_bit64 ( uint64_t N , uint64_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 64 ) ;
#endif
    return (  (N & (1ULL<<Pos )) != 0 );
};
//------------------------------------------------------------------------
//  function :
/// @brief
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------

static const int index64[64] = {
   63,  0, 58,  1, 59, 47, 53,  2,
   60, 39, 48, 27, 54, 33, 42,  3,
   61, 51, 37, 40, 49, 18, 28, 20,
   55, 30, 34, 11, 43, 14, 22,  4,
   62, 57, 46, 52, 38, 26, 32, 41,
   50, 36, 17, 19, 29, 10, 13, 21,
   56, 45, 25, 31, 35, 16,  9, 12,
   44, 24, 15,  8, 23,  7,  6,  5
};
static const uint64_t debruijn64 = 0x07EDD5E59A4E28C2ULL;
//------------------------------------------------------------------------
//  function :bitScanForward64
/// @author Martin Läuter(1997),Charles E.Leiserson,Harald Prokop,Keith H.Randall
/// @brief return the least significant one bit
/// @param [in] bb bitboard to scan
/// @return index (0..63) of least significant one bit
/// @remarks "Using de Bruijn Sequences to Index a 1 in a Computer Word"
//------------------------------------------------------------------------
inline int bitScanForward64(uint64_t bb1)
{   //------------------------- begin --------------------------------
#if __DEBUG_CNTREE != 0
   assert (bb1 != 0);
#endif
   const int64_t &bb = (int64_t)bb1;
   return index64[((bb & -bb) * debruijn64) >> 58];
};

}; //---------------------- end namespace tool --------------------------------
}; //---------------------- end namespace lga --------------------------------
#endif

