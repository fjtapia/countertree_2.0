//----------------------------------------------------------------------------
/// @file basic_suballoc64.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_BASIC_SUBALLOC64_HPP
#define __CNTREE_BASIC_SUBALLOC64_HPP

#include <boost/cntree/alloc/pool64.hpp>
#include <limits>

namespace cntree
{
namespace alloc
{


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                   C L A S S                      #             ##
//       #                                                  #             ##
//       #       B A S I C _ S U B A L L O C 6 4            #             ##
//       #         < A L L O C A T O R , T1 >               #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class basic_suballoc64
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template<typename Allocator, typename T1 >
class basic_suballoc64
{
public :
    //--------------------------------------------------------------------------
    //            P U B L I C    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef typename Allocator::value_type	    value_type; //Element type
    typedef typename Allocator::pointer	        pointer; //Pointer to element
    typedef typename Allocator::reference	    reference; //Reference to element
    typedef typename Allocator::const_pointer	const_pointer; //Constant pointer to element
    typedef typename Allocator::const_reference const_reference; //Constant reference to element
    typedef typename Allocator::size_type		size_type; //Quantities of elements
    typedef typename Allocator::difference_type difference_type ; //Difference between two pointers
    static uint64_t const SizeElem = sizeof (value_type );

    typedef typename Allocator::template rebind < uint8_t>::other AllocByte;
    typedef  alloc::pool64 <SizeElem ,AllocByte>  MyPool ;

    //--------------------------------------------------------------------------
    //                 P R I V A T E      V A R I A B L E S
    //--------------------------------------------------------------------------
protected:
    Allocator A ;
    static MyPool  Pila ;

public:

    explicit basic_suballoc64 ( void) { };
    ~basic_suballoc64 ( void) {};
    //--------------------------------------------------------------------------
    //    convert an allocator<T> to allocator<U>
    //--------------------------------------------------------------------------
    template<typename U>
    struct rebind
    {   typedef  typename Allocator::template rebind<U>::other base_other ;
        typedef basic_suballoc64 <base_other,U> other;
    };

    //##########################################################################
    //                      ADDRESS AND SIZE                                  ##
    //##########################################################################
    //------------------------------------------------------------------------
    //  function : address
    /// @brief provide the address of a reference to an object
    /// @param [in] r : reference
    /// @return Address of the reference
    //------------------------------------------------------------------------
    pointer address(reference r)
    {   //---------------------------- begin -------------------------
        return &r;
    };

    //------------------------------------------------------------------------
    //  function : address
    /// @brief provide the address of a const_reference to an object
    /// @param [in] r : reference
    /// @return Address of the const_reference
    //------------------------------------------------------------------------
    const_pointer address(const_reference r)
    {   //------------------------------ begin -----------------------------
        return &r;
    };

    //------------------------------------------------------------------------
    //  function : max_size
    /// @brief Maximun size of memory for to allocate
    /// @return maximun size of memory
    /// @remarks
    //------------------------------------------------------------------------
    size_type max_size() const
    {   //--------------------------- begin ------------------------
        return std::numeric_limits<size_type>::max() / SizeElem;
    };


    //##########################################################################
    //                  MEMORY   ALLOCATION                                   ##
    //##########################################################################
    //------------------------------------------------------------------------
    //  function : allocate
    /// @brief Allocate a block of memory
    /// @param [in] cnt : number of objects to allocate
    /// @param [in] pointer unused
    /// @return pointer to the object allocated
    /// @remarks
    //------------------------------------------------------------------------
    pointer allocate(size_type cnt, const_pointer Alfa = NULL)
    {   //------------------------------------ begin --------------------------------------
        return (cnt == 1)?static_cast<pointer>(Pila.allocate()):static_cast<pointer>(A.allocate (cnt));
    };

    //------------------------------------------------------------------------
    //  function : deallocate
    /// @brief deallocate a block of memory
    /// @param [in] p : pointer to deallocate
    /// @param [in] n : number of objects to deallocate
    /// @return
    /// @remarks
    //------------------------------------------------------------------------
    void deallocate(pointer p, size_type n= 1 )
    {   //----------------------------- begin -------------------------
        if  ( n < 1) throw std::invalid_argument("");
        if ( n == 1 ) Pila.deallocate ( static_cast< void*> (p) );
        else  A.deallocate ( p , n );
    };


    //##########################################################################
    //               OBJECT CONSTRUCTION & DESTRUCTION                        ##
    //##########################################################################
    //------------------------------------------------------------------------
    //  function : construct
    /// @brief Construct a new object in the memory pointed by p
    /// @param [in] p : pointer to the memory for to construct the object
    /// @param [in] t : object used as parameter as copy constructor
    /// @return
    /// @remarks
    //------------------------------------------------------------------------
    void construct(pointer p, const value_type & t)
    {   //------------------------------------- begin -----------------------------
        //new(p) value_type(t);
        A.construct (p,t);
    };
    //------------------------------------------------------------------------
    //  function : destroy
    /// @brief destroy the object without freeing the memory
    /// @param [in] p : pointer p to the object to destroy
    /// @return
    /// @remarks
    //------------------------------------------------------------------------
    void destroy(pointer p)
    {   //------------------------------- begin ---------------------------
        //p->~T();
        A.destroy (p);
    };


//########################################################################
};//        E N D     S U B A L L O C A T O R 6 4     C L A S S
//########################################################################




//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                   C L A S S                      #             ##
//       #                                                  #             ##
//       #       B A S I C _ S U B A L L O C 6 4            #             ##
//       #       < A L L O C A T O R , V O I D >            #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class basic_suballoc64
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template<typename Allocator >
class basic_suballoc64<Allocator, void >
{
public :
    //--------------------------------------------------------------------------
    //            P U B L I C    D E F I N I T I O N S
    //--------------------------------------------------------------------------
    typedef typename Allocator::value_type	    value_type; //Element type
    typedef typename Allocator::pointer	        pointer; //Pointer to element
    typedef typename Allocator::const_pointer	const_pointer; //Constant pointer to element
    typedef typename Allocator::size_type		size_type; //Quantities of elements
    typedef typename Allocator::difference_type difference_type ; //Difference between two pointers
    typedef typename Allocator::template rebind <void>::other AllocByte;

    typedef  void *  MyPool ;
    static MyPool Pila ;

    //--------------------------------------------------------------------------
    //    convert an allocator<T> to allocator<U>
    //--------------------------------------------------------------------------
    template<typename U>
    struct rebind
    {   typedef  typename Allocator::template rebind<U>::other base_other ;
        typedef basic_suballoc64 <base_other,U> other;
    };


//########################################################################
};//        E N D     B A S I C _ S U B A L L O C 6 4     C L A S S
//########################################################################

//##########################################################################
//                Initialization  static variables                        ##
//##########################################################################
template<typename Allocator, typename T1>
typename  basic_suballoc64 <Allocator,T1>::MyPool basic_suballoc64<Allocator,T1>::Pila ;

//template<typename Allocator>
//typename  basic_suballocator32<Allocator,void>::MyPool basic_suballocator32<Allocator,T1>::Pila = NULL ;


//########################################################################
};//              E N D    A L L O C      N A M E S P A C E
//########################################################################

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
