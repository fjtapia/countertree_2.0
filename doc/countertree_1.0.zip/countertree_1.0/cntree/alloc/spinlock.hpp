//----------------------------------------------------------------------------
/// @file spinlock.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanying file LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_ALLOC_SPINLOCK_HPP
#define __CNTREE_ALLOC_SPINLOCK_HPP

#include <pthread.h>
#include <cassert>
#include <stdexcept>


namespace cntree
{
namespace alloc
{

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #          C L A S S     S P I N L O C K           #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
class spinlock
{
//------------------ V A R I A B L E S ----------------------------------
pthread_spinlock_t  SP ;

public:

//------------------------------------------------------------------------
//  function : spinlock
/// @brief Constructor of the class
/// @param [in] shared : Indicate if the spinlock is shared or private
/// @remarks
//------------------------------------------------------------------------
spinlock( bool shared= true)
{   //---------------------------- begin --------------------------------
    int ret=pthread_spin_init(&SP,
                              (shared)?PTHREAD_PROCESS_SHARED :PTHREAD_PROCESS_PRIVATE);
    assert ( ret == 0 ) ;
};


//------------------------------------------------------------------------
//  function : ~spinlock
/// @brief Destroy the spinlock
/// @remarks
//------------------------------------------------------------------------
~spinlock(void)
{   //----------------------------- begin ---------------------
    int ret= pthread_spin_destroy(&SP);
    assert( ret == 0 ) ;
};
//------------------------------------------------------------------------
//  function : lock
/// @brief  Lock the spinlock
/// @remarks
//------------------------------------------------------------------------
void lock( void)
{   //----------------------------------- begin ---------------------
    int ret = pthread_spin_lock( &SP);
    assert( ret == 0 ) ;
};

//------------------------------------------------------------------------
//  function : try_lock
/// @brief try to lock the spin lock, if locked
/// @return true Ok
/// @remarks
//------------------------------------------------------------------------
bool try_lock( void)
{   //-------------------------------- begin --------------------
    int ret = pthread_spin_trylock( &SP);
    return ( ret == 0  ) ;
};

//------------------------------------------------------------------------
//  function : unlock
/// @brief unlock the spin lock
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------
void unlock( void)
{   //---------------------------------- begin -----------------------------
    int ret = pthread_spin_unlock( &SP);
    assert ( ret == 0  ) ;
};

}; // ------------------- enf of class spinlock ----------------------------



}; //---------------------- end namespace alloc --------------------------------
}; //---------------------- end namespace cntree --------------------------------
#endif

