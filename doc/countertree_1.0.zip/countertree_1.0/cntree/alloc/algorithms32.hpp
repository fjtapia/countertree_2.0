//----------------------------------------------------------------------------
/// @file algorithms32.hpp
/// @brief This file contains the description of the classes heap_fixed_node
///        and heap_node
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanying file LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_ALLOC_ALGORITHMS32_HPP
#define __CNTREE_ALLOC_ALGORITHMS32_HPP

#include <boost/cntree/alloc/definitions.hpp>
#include <boost/cntree/alloc/config.hpp>
#include <cassert>
#include <stdexcept>
#include <string.h>
#include <iostream>

namespace cntree
{
namespace alloc
{

//typedef uint32_t * NOALIAS PW32 ;
typedef uint32_t *  PW32 ;
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                B A S I C                         #             ##
//       #                                                  #             ##
//       #         A L G O R I T H M S     3 2  B i t s     #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
// extraido de http://skalkoto.blogspot.com/2008/01/bit-operations-find-first-zero-bit.html
inline int BitCount(unsigned int u)
{
    unsigned int uCount;
    uCount = u - ((u >> 1) & 033333333333)- ((u >> 2) & 011111111111);
    return ((uCount + (uCount >> 3))& 030707070707) % 63;
}

inline int First0Bit(int i)
{   i=~i;
    return BitCount((i&(-i))-1);
}
//------------------------------------------------------------------------
//  function : first_zero
/// @brief Calculate the position of the first bit with value 0 , beginning
///        from the bit 0 to the bit 63
/// @param [in] N : Number to examinate
/// @return Position of the first bit with value 0 .
/// @remarks
//------------------------------------------------------------------------
inline uint32_t first_zero32 ( uint32_t N)
{   //----------------------- begin ------------------------------
#if __DEBUG_CNTREE  != 0
    assert ( N != MAX32) ;
#endif
    uint32_t Pos = 0 ;

    if ( (N & 0xffff)== 0xffff )
    {   N >>= 16 ;
        Pos += 16 ;
    };
    if ( (N & 0xff)== 0xff )
    {   N >>= 8 ;
        Pos += 8 ;
    };
    if ( (N & 0xf)== 0xf )
    {   N >>= 4 ;
        Pos += 4 ;
    };
    if ( (N & 0x3)== 0x3 )
    {   N >>= 2 ;
        Pos += 2 ;
    };
    if ( (N & 0x1)== 0x1 )
    {   Pos += 1 ;
    };
    return Pos ;
};
//------------------------------------------------------------------------
//  function : set_zero32
/// @brief Set to zero the bit Pos in a uint32_t element N
/// @param [in] N : word where put to zero a bit
/// @param [in] Pos : position of the bit in  set to zero
//------------------------------------------------------------------------
inline void set_zero32 ( uint32_t &N , uint32_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 32 ) ;
#endif
    ( N &= (~(1U<<Pos)));
};

//------------------------------------------------------------------------
//  function : set_one32
/// @brief Set to one the bit Pos in a uint32_t element N
/// @param [in] N : word where put to one a bite
/// @param [in] Pos : position of the bit in  set to one
//------------------------------------------------------------------------
inline void set_one32 ( uint32_t &N , uint32_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 32 ) ;
#endif
    ( N |= (1U<<Pos));
};

//------------------------------------------------------------------------
//  function : read_bit32
/// @brief Return the content of the bit Pos in the uint32_t element N
/// @param [in] N : uint32_t element from read the birt
/// @param [in] Pos : Position of the bit readed
/// @return Value of the bit (true :1 , false :0)
/// @remarks
//------------------------------------------------------------------------
inline bool read_bit32 ( uint32_t N , uint32_t Pos )
{   //------------------ begin --------------------------
#if __DEBUG_CNTREE != 0
    assert ( Pos < 32 ) ;
#endif
    return (  (N & (1U<<Pos )) != 0 );
};
//------------------------------------------------------------------------
//  function :
/// @brief
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------

static const int MultiplyDeBruijnBitPosition[32] =
{
  0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8,
  31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9
};
//------------------------------------------------------------------------
//  function :bitScanForward32
/// @author Martin Läuter(1997),Charles E.Leiserson,Harald Prokop,Keith H.Randall
/// @brief return the least significant one bit
/// @param [in] bb bitboard to scan
/// @return index (0..31) of least significant one bit
/// @remarks "Using de Bruijn Sequences to Index a 1 in a Computer Word"
//------------------------------------------------------------------------
inline int bitScanForward32(uint32_t V1)
{   //------------------------- begin --------------------------------
#if __DEBUG_CNTREE != 0
   assert (V1 != 0);
#endif
    const int32_t  &v = (int32_t) V1 ;
    return MultiplyDeBruijnBitPosition[((uint32_t)((v & -v) * 0x077CB531U)) >> 27];
};

//########################################################################
};//              E N D    A L L O C     N A M E S P A C E
//########################################################################

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif


