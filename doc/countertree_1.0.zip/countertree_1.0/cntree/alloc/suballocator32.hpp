//----------------------------------------------------------------------------
/// @file suballocator32.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SUBALLOCATOR32_HPP
#define __CNTREE_SUBALLOCATOR32_HPP

#include <boost/cntree/alloc/basic_suballoc32.hpp>
#include <limits>

namespace cntree
{
namespace alloc
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #    F O R W A R D   D E C L A R A T I O N S       #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
template<typename Allocator2 > class suballocator32;

template<typename Allocator2 > class suballocator64;

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #       C L A S S E S     F O R   T H E            #             ##
//       #                                                  #             ##
//       #         M E T A P R O G R A M M I N G            #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class Filter32
///
/// @remarks This class is for prevent the passing of a suballocator
///          as template parameter for other suballocator
//----------------------------------------------------------------

template <class Allocator1 >
struct Filter32
{   typedef Allocator1 name ;
};

template <class U >
struct Filter32 < suballocator32< U > >
{   typedef U name ;
};

template <class U >
struct Filter32 < suballocator64< U > >
{   typedef U name ;
};

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #    C L A S S    S U B A L L O C A T O R 3 2      #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class suballocator32
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template<typename Allocator>
class suballocator32 :
      public basic_suballoc32 <typename Filter32<Allocator>::name,
                               typename Allocator::value_type>
{
public :
    //------------------------------------------------------------------------
    //  function : basic_suballoc32
    /// @brief constructor of the class
    //------------------------------------------------------------------------
    explicit suballocator32() {};

    //------------------------------------------------------------------------
    //  function : basic_suballoc32
    /// @brief Copy constructor
    /// @param [in] The parameter is not used
    //------------------------------------------------------------------------
    suballocator32( suballocator32<Allocator> const&) {};

    //------------------------------------------------------------------------
    //  function : basic_suballoc32
    /// @brief Copy constructor fron an allocator of other type
    /// @param [in] The parameter is not used
    //------------------------------------------------------------------------
    template<typename U>
    suballocator32(suballocator32<U> const&) {};

    //------------------------------------------------------------------------
    //  function : ~basic_suballoc32
    /// @brief Destructor of the class
    //------------------------------------------------------------------------
    virtual ~suballocator32() { };

    //--------------------------------------------------------------------------
    //    convert an allocator<T> to allocator<U>
    //--------------------------------------------------------------------------
    template<typename U>
    struct rebind
    {   typedef  typename Allocator::template rebind<U>::other base_other ;
        typedef suballocator32 <base_other> other;
    };


    //##########################################################################
    //                     BOOLEAN  OPERATORS                                 ##
    //##########################################################################
    //------------------------------------------------------------------------
    //  function : operator==
    /// @brief equality operator
    /// @param [in] reference to the suballocator to compare
    /// @return always return true
    /// @remarks
    //------------------------------------------------------------------------
    bool operator==(suballocator32 const&)
    {   //---------------------------------- begin -----------------------
        return true;
    };
    //------------------------------------------------------------------------
    //  function : operator !=
    /// @brief inequality operator
    /// @param [in]reference to the suballocator to compare
    /// @return always return false
    /// @remarks
    //------------------------------------------------------------------------
    bool operator!=(suballocator32 const& )
    {   //------------------------------ begin ----------------------------------
        return false;
    };

    //------------------------------------------------------------------------
    //  function : operator==
    /// @brief equality operator
    /// @param [in] reference to the suballocator to compare
    /// @return always return true
    /// @remarks
    //------------------------------------------------------------------------
    template <typename Allocator2>
    bool operator==(suballocator32<Allocator2> const&)
    {   //---------------------------------- begin -----------------------
        return true;
    };
    //------------------------------------------------------------------------
    //  function : operator !=
    /// @brief inequality operator
    /// @param [in]reference to the suballocator to compare
    /// @return always return false
    /// @remarks
    //------------------------------------------------------------------------
    template <typename Allocator2>
    bool operator!=(suballocator32<Allocator2> const& )
    {   //------------------------------ begin ----------------------------------
        return false;
    };


//########################################################################
};//        E N D     S U B A L L O C A T O R 3 2      C L A S S
//########################################################################

//########################################################################
};//              E N D    A L L O C     N A M E S P A C E
//########################################################################

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
