///----------------------------------------------------------------------------
// FILE : sorted_vector_tree.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SORTED_VECTOR_TREE_HPP
#define __CNTREE_SORTED_VECTOR_TREE_HPP

#include <memory>
#include <functional>
#include <boost/cntree/vector_tree.hpp>
#include <boost/cntree/tree/filter.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                   C L A S S                      #             ##
//       #                                                  #             ##
//       #       S O R T E D _ V E C T O R _ T R E E        #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class  sorted_vector_tree
/// @brief  This class is a vector_tree sorted, with all the
///         functions needed for manage the ordered information. \n
///         It has access by position and random access iterators
///         Due to this all the operations ( insert, delete, access)
///         a O( logN). \n
/// @param  value_t : value to store
/// @param  key_t : value used to compare
/// @param  filter_t Object used to obtain a key_t from a value_t
/// @param  comp_key_t : object used to compare two keys
/// @param  alloc_t : object used to allocate the nodes in the memory

/// @remarks
//----------------------------------------------------------------
template < typename value_t,
           typename key_t      = value_t,
           typename filter_t   = tree::filter_set<key_t,value_t>,
           typename comp_key_t = std::less<key_t>,
           typename alloc_t    = std::allocator<value_t>
        >
class sorted_vector_tree :public vector_tree<value_t,alloc_t>
{
public:
    //--------------------------------------------------------------------------
    //                    D E F I N I T I O N S
    //--------------------------------------------------------------------------

    typedef cntree::vector_tree<value_t,alloc_t>         vector_tree ;
    typedef typename vector_tree::size_type              size_type    ;
    typedef typename vector_tree::difference_type        difference_type;
    typedef typename vector_tree::iterator               iterator     ;
    typedef typename vector_tree::const_iterator         const_iterator     ;
    typedef typename vector_tree::reverse_iterator       reverse_iterator ;
    typedef typename vector_tree::const_reverse_iterator const_reverse_iterator;

    typedef typename vector_tree::pnode                  pnode ;
    typedef typename vector_tree::const_pnode            const_pnode   ;
    typedef typename vector_tree::address_pnode          address_pnode ;
    typedef typename vector_tree::refnode                refnode   ;
    typedef typename vector_tree::const_refnode          const_refnode ;

    typedef typename vector_tree::value_type             value_type;
    typedef typename vector_tree::pointer                pointer;
    typedef typename vector_tree::const_pointer          const_pointer;
    typedef typename vector_tree::reference              reference;
    typedef typename vector_tree::const_reference        const_reference;
    typedef typename vector_tree::allocator_type         allocator_type;

    typedef tree::basic_tree<value_t>             basic_tree;
    typedef tree::branch <value_t>                branch ;
    typedef tree::node<value_t>                   node ;

    //-----------------------------------------------------------------
    //  using sentences of vector_tree elements
    //  This is necesary for the GNU compiler
    //-----------------------------------------------------------------
    using vector_tree::root;
    using vector_tree::node_alloc;
    using vector_tree::value_alloc;
    using vector_tree::size;
    using vector_tree::begin ;
    using vector_tree::end ;
    using vector_tree::find_pos ;
    using vector_tree::first ;
    using vector_tree::last ;

    //-----------------------------------------------------------------
    //  using sentences of vector_tree elements
    //  This is necesary for the CLANG compiler
    //-----------------------------------------------------------------
    
    using vector_tree::pointer_father;
    using vector_tree::upper_branch ;

    using vector_tree::increment_path ;
    using vector_tree::decrement_path ;

    using vector_tree::insert_first_pointer ;
    using vector_tree::insert_first_element  ;

    using vector_tree::erase_internal   ;
    using vector_tree::insert_internal  ;

private:
    //--------------------------------------------------------------------------
    //          P R I V A T E    V A R I A B L E S
    //-------------------------------------------------------------------------
    filter_t      fltr ;
    comp_key_t    cmpr ;

public:
    //--------------------------------------------------------------------------
    //   C O N S T R U C T O R S    A N D   D E S T R U C T O R
    //--------------------------------------------------------------------------
    sorted_vector_tree ( const filter_t &F1= filter_t(),
                         const comp_key_t& C1=comp_key_t(),
                         const alloc_t &ALLC=alloc_t()      ) ;

    sorted_vector_tree (const sorted_vector_tree & ST );

    virtual ~sorted_vector_tree (void) ;

    void swap (sorted_vector_tree  & A );
#if __DEBUG_CNTREE != 0
    bool check ( void) const;
#endif

    //--------------------------------------------------------------
    //     A S I G N A C I O N , B O R R A D O , F U S I O N
    //--------------------------------------------------------------
#if __DEBUG_CNTREE != 0
    sorted_vector_tree &  operator= ( const vector_tree &A);
#endif
    sorted_vector_tree & operator= (const sorted_vector_tree &A);

    //--------------------------------------------------------------------------
    //                E L E M E N T     A C C E S S
    //--------------------------------------------------------------------------
    iterator        find ( const key_t & K);
    const_iterator  find ( const key_t & K) const;

    iterator        find_unique ( const key_t & K);
    const_iterator  find_unique ( const key_t & K) const;

    iterator        lower_bound ( const key_t & K);
    const_iterator  lower_bound ( const key_t & K)const;

    iterator        upper_bound ( const key_t & K);
    const_iterator  upper_bound ( const key_t & K) const;

    //--------------------------------------------------------------------------
    //                     I T E R A T O R S
    //--------------------------------------------------------------------------
    std::pair<iterator, iterator>            equal_range ( const key_t &K);
    std::pair<const_iterator,const_iterator> equal_range ( const key_t &K) const;

    size_type count ( const key_t &K) const;

    //--------------------------------------------------------------------------
    //     I N S E R T I O N S   O F     E L E M E N T S
    //--------------------------------------------------------------------------
    iterator    insert_value        ( const value_t &Val) ;
    iterator    insert_value_unique (const value_t & Val) ;
    comp_key_t  key_comp            (void ) const;

private:
    sorted_vector_tree<value_t,key_t,filter_t,comp_key_t,alloc_t> * remove_const ( void )const;

//########################################################################
};//       E N D  S O R T E D _ V E C T O R _ T R E E    C L A S S
//########################################################################
#define __SVT sorted_vector_tree<value_t,key_t,filter_t,comp_key_t,alloc_t>
#define __SVT_ITERATOR typename sorted_vector_tree<value_t,key_t,filter_t,comp_key_t,alloc_t>::iterator
#define __SVT_CONST_ITERATOR typename sorted_vector_tree<value_t,key_t,filter_t,comp_key_t,alloc_t>::const_iterator
//------------------------------------------------------------------------
//  function : sorted_vector_tree
/// @brief This function is teh construct of the class
/// @param [in] F1 : object filter_t
/// @param [in] C1 : object comp_key_t
/// @param [in] A : object alloc_t
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t  , typename filter_t  ,
           typename comp_key_t,   typename alloc_t  >
inline __SVT::sorted_vector_tree ( const filter_t &F1, const comp_key_t& C1,
                     const alloc_t &ALLC):vector_tree (ALLC),fltr(F1),cmpr(C1){};

//------------------------------------------------------------------------
//  function : sorted_vector_tree
/// @brief copy constructor
/// @param [in] ST : object to copy
//------------------------------------------------------------------------
template < typename value_t, typename key_t  , typename filter_t  ,
           typename comp_key_t,   typename alloc_t           >
inline __SVT::sorted_vector_tree (const sorted_vector_tree & ST ):
                    vector_tree(ST),fltr (ST.fltr),cmpr(ST.cmpr){};

//------------------------------------------------------------------------
//  function : ~sorted_vector_tree
/// @brief destructor of the class
/// @param [in] none
/// @remarks This function is virtual
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT::~sorted_vector_tree (void){ };

//------------------------------------------------------------------------
//  function : swap
/// @brief swap two sorted vector_tree
/// @param [in] A : sorted_vector_tree to swap
/// @return none
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline void __SVT::swap (sorted_vector_tree  & A )
{   //----------------------- begin -------------------------------
    this->vector_tree::swap(A) ;
    std::swap ( cmpr, A.cmpr);
};


//--------------------------------------------------------------
//     A S I G N A C I O N , B O R R A D O , F U S I O N
//--------------------------------------------------------------
#if __DEBUG_CNTREE != 0
//------------------------------------------------------------------------
//  function :
/// @brief
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT & __SVT::operator= ( const vector_tree &A)
{   //-------------------------- begin ---------------------------
    throw std::invalid_argument ("SortedTree::operator=");
    return *this;
};
#endif
//------------------------------------------------------------------------
//  function : operator =
/// @brief Assignation operator
/// @param [in] A : sorted_vector_tree to copy
/// @return reference to the actual object after the copy
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT & __SVT::operator= (const sorted_vector_tree &A)
{   //----------------------------- begin -----------------------------
    this->vector_tree::operator= (A) ;
    return *this ;
};

//##########################################################################
//                                                                        ##
//                E L E M E N T     A C C E S S                           ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : find
/// @brief Return an iterator to the first element with this Key
///        if don't exist return end()
/// @param [in] Key : key to search
/// @return iterrator to the element if exist, or end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT_ITERATOR __SVT::find ( const key_t & K)
{   //---------------------------- Inicio -------------------------------
    pnode P1 = root ;
    iterator C = end();
    //-------------------------------------------------------------------
    // Si encontramos un valor igual, lo apuntamos , y seguimos buscando
    // por la left
    //-------------------------------------------------------------------
    while ( P1 != NULL)
    {   if ( cmpr ( fltr(P1->data) , K)) P1 = P1->right ;
        else
        {   if (not cmpr(K , fltr(P1->data))) C = iterator( P1, this ) ;
            P1 = P1->left ;
        };
    };
    return C ;
};
//------------------------------------------------------------------------
//  function : find
/// @brief Return an const_iterator to the first element with this Key
///        if don't exist return end()
/// @param [in] Key : key to search
/// @return const_iterrator to the element if exist, or end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT_CONST_ITERATOR __SVT::find ( const key_t & K) const
{   //---------------------------- begin ------------------------------------------
    return remove_const()->find(K) ;
};

//------------------------------------------------------------------------
//  function : find_unique
/// @brief Return an iterator to the element with this Key. If don't exist
///        return end() \n
///        This function supouse there is only one element with the key
/// @param [in] Key : key to search
/// @return iterrator to the element if exist, or end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT_ITERATOR  __SVT::find_unique ( const key_t & K)
{   //-------------------------------- begin ---------------------------------------
    pnode P1 = root ;
    bool SW = true ;
    //-------------------------------------------------------------------
    // Si encontramos un valor igual, lo apuntamos , y seguimos buscando
    // por la left
    //-------------------------------------------------------------------
    while ( SW and P1 != NULL)
    {   if ( cmpr ( fltr(P1->data) , K)) P1 = P1->right ;
        else
        {   if (cmpr(K , fltr(P1->data))) P1 = P1->left ;
            else                          SW = false ;
        };
    };

    return ( SW)?end() :iterator( P1, this ) ;
};
//------------------------------------------------------------------------
//  function : find_unique
/// @brief Return an iterator to the element with this Key. If don't exist
///        return end() \n
///        This function supouse there is only one element with the key
/// @param [in] Key : key to search
/// @return iterrator to the element if exist, or end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT_CONST_ITERATOR __SVT::find_unique ( const key_t & K) const
{   //------------------------------- begin --------------------------------------
    return remove_const()->find_unique(K) ;
};

//------------------------------------------------------------------------
//  function : lower_bound
/// @brief find a key in the tree. If there are repeated
///        elements, return an iterator to the first of them.
///        If the key don't exist return an iterator to the first element
///        greater than the key
/// @param [in] K : key to search
/// @return iterator to the element. If don't exist end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT_ITERATOR __SVT::lower_bound ( const key_t & K)
{   //---------------------------- Inicio -------------------------------
    pnode P1 = root;
    pnode P2 = root ;
    iterator C = end() ;
    bool SWR = false ;
    //-------------------------------------------------------------------
    // Si encontramos un valor igual, lo apuntamos , y seguimos buscando
    // por la left
    //-------------------------------------------------------------------
    while ( P1 != NULL)
    {   P2 = P1 ;
        P1 = ( SWR = cmpr(fltr(P1->data),K) )? P1->right :P1->left;
        if ( not SWR)
        {   if ( not cmpr(K , fltr(P2->data))) C = iterator( P2, this ) ;
        };
    };

    if ( C == end())
    {   if (SWR)
        {   P2 = P2->next() ;
            C = ( P2 == NULL)? end() :iterator ( P2, this)  ;
        }
        else C = iterator( P2 , this ) ;
    };
    return C ;
};

//------------------------------------------------------------------------
//  function : lower_bound
/// @brief find a key in the tree. If there are repeated
///        elements, return an iterator to the first of them.
///        If the key don't exist return an iterator to the first element
///        greater than the key
/// @param [in] K : key to search
/// @return iterator to the element. If don't exist end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT_CONST_ITERATOR __SVT::lower_bound ( const key_t & K)const
{   //------------------------- begin ---------------------------------
    return remove_const()->lower_bound(K);
};

//------------------------------------------------------------------------
//  function :upper_bound
/// @brief return an iterator to the first element greater than K. If
///        don't exist return end()
/// @param [in] K : value to find
/// @return iterator to the first element greater than K
///         If don't exist return end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT_ITERATOR  __SVT::upper_bound ( const key_t & K)
{   //---------------------------------- begin ------------------------------------
    iterator Alfa = end() ;
    pnode P1  = root ;
    while ( P1 != NULL )
    {   if ( cmpr( K , fltr(P1->data)))
        {   Alfa = iterator ( P1, this);
            P1 = P1->left ;
        }
        else P1 = P1->right ;
    };
    return Alfa ;
};

//------------------------------------------------------------------------
//  function :upper_bound
/// @brief return a const_iterator to the first element greater than K. If
///        don't exist return end()
/// @param [in] K : value to find
/// @return const_iterator to the first element greater than K
///         If don't exist return end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT_CONST_ITERATOR __SVT::upper_bound ( const key_t & K) const
{   //--------------------- begin ------------------------------
    return remove_const()->upper_bound (K) ;
};

//##########################################################################
//                                                                        ##
//                     I T E R A T O R S                                  ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of iterators, lower_bound and upper bound
///        of a key K
/// @param [in] K : key to find
/// @return pair of iterators, the first is le lower_bound and the second
//          is the upper bound
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline std::pair<__SVT_ITERATOR,__SVT_ITERATOR> __SVT::equal_range ( const key_t &K)
{   //------------------------------- begin -----------------------------------
    return  std::pair<iterator,iterator> (lower_bound(K),upper_bound(K));
};
//------------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of const_iterators, lower_bound and upper bound
///        of a key K
/// @param [in] K : key to find
/// @return pair of const_iterators, the first is le lower_bound and the second
//          is the upper bound
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline std::pair<__SVT_CONST_ITERATOR,__SVT_CONST_ITERATOR>
__SVT::equal_range ( const key_t &K) const
{   //-------------------------- begin ---------------------------------------
    return std::pair<const_iterator,const_iterator> (lower_bound(K),upper_bound(K));
};

//------------------------------------------------------------------------
//  function : count
/// @brief Count the number of elements with the key K
/// @param [in] K : key ti find
/// @return number of repetitions of the key K
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline typename __SVT::size_type __SVT::count ( const key_t &K) const
{   //------------------------- begin ---------------------------------
    const_iterator C1 =lower_bound (K), C2 = upper_bound(K) ;
    if ( C1 == C2 ) return 0 ;
    return ( C2.pos() - C1.pos() );
};

//##########################################################################
//                                                                        ##
//                     I N S E R T I O N S                                ##
//                            O F                                         ##
//                      E L E M E N T S                                   ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function :insert_value
/// @brief Insert a value Val in the sorted tree
/// @param [in] Val : value to insert
/// @return iterator to the node inserted.
/// @remarks his function permit the insertion of repeated elements
//------------------------------------------------------------------------

template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT_ITERATOR __SVT::insert_value(const value_t &Val)
{   //------------------------- Begin --------------------------------
    //if ( root == NULL) return push_front ( Val);

    //if (not  cmpr (fltr(Val),fltr(last->data )) )  return push_back ( Val);
    //if (     cmpr (fltr(Val),fltr(first->data)) )  return push_front( Val);

    bool SW = false ;
    pnode    P1 = root;
    pnode   P2 = root;

    while ( P2 != NULL)
    {
        P1 = P2;
        P2->N++;
        //P2 = (SW=cmpr(fltr(Val),fltr(P1->data)))? P1->left:P1->right;
        P2 = (SW=cmpr(fltr(Val),fltr(P2->data)))? P2->left:P2->right;
    };
    //increment_path( P1);
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux, Val ) ;
    insert_internal(PAux, P1, SW);
    return iterator ( PAux, this) ;
};

//------------------------------------------------------------------------
//  function :insert_value_unique
/// @brief insert a value in the tree. If the value exist, it
///        is not inserted
/// @param [in] Val : value to insert
/// @return Iterator to the element inserted. If exist , return end()
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
__SVT_ITERATOR __SVT::insert_value_unique(const value_t & Val)
{   //------------------- Inicio ---------------------------------
    //if ( root == NULL) return push_front( Val);
    //else
    //{   if ( cmpr (fltr(last->data),fltr (Val))) return  push_back ( Val) ;
    //    if(cmpr (fltr(Val), fltr(first->data))) return  push_front( Val);
    //};
    bool SW =false;
    pnode P1 = NULL;
    pnode P2= root;
    while ( P2 != NULL)
    {   P1 = P2;
        P2->N++;
        //SW =  cmpr (fltr(Val), fltr(P1->data))   ;
        //P2 = ( SW)? P1->left : P1->right ;
        //P2 =(SW=cmpr(fltr(Val),fltr(P1->data)))?P1->left:P1->right ;
        P2 =(SW=cmpr(fltr(Val),fltr(P2->data)))?P2->left:P2->right ;
    };
    //--------------------------------------------------------------------
    // Para saber si existe. Si SW es true buscamos en alterior a P1. Si
    // no es es , quiere decir que no existe
    // Si SW es false, si no es P1 , no existe
    //--------------------------------------------------------------------

    pnode P3 = P1 ;
    if ( SW)
    {   //---------------------------------------------------------------
        // Subir por la dcha todo lo que puedas y luego un salto hacia
        // arriba a la izda
        // Si no es posible saltar a la izda devuelve NULL, porque no
        // tiene nada posterior
        //---------------------------------------------------------------
        pnode PAux = P3->up;
        while ( PAux != NULL and PAux->left == P3 )
        {   P3 = PAux ;
            PAux = PAux->up ;
        };
        P3 =( PAux != NULL and PAux->right != P3 ) ?NULL :PAux ;
    };

    if ( P3 != NULL and not cmpr(fltr(P3->data),fltr(Val))
                    and not cmpr(fltr(Val),fltr(P3->data))  )
    {   decrement_path(P1);
        return end() ;
    };
    //increment_path ( P1 ) ;
    pnode PAux = node_alloc.allocate (1) ;
    node_alloc.construct( PAux,  Val ) ;
    insert_internal(PAux, P1, SW);
    return iterator ( PAux, this) ;
};
//------------------------------------------------------------------------
//  function : key_comp
/// @brief return the object used to compare two keys
/// @param [in] none
/// @return object comp_key
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline comp_key_t __SVT::key_comp (void ) const
{   //---------------------- begin ----------------------------
    return cmpr;
};


//------------------------------------------------------------------------
//  function : remove_const
/// @brief Function for to obtain sorted_vector_tree pointer from  a
///        const sorted_vector_tree
/// @param [in] none
/// @return pointer
/// @remarks
//------------------------------------------------------------------------
template < typename value_t, typename key_t, typename filter_t ,
           typename comp_key_t, typename alloc_t >
inline __SVT * __SVT::remove_const ( void )const
{   //--------------------------------- begin -----------------------------------------
    return const_cast <sorted_vector_tree*> ( this);
};
#undef __SVT
#undef __SVT_ITERATOR
#undef __SVT_CONST_ITERATOR

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
