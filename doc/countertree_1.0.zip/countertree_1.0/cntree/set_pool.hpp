//----------------------------------------------------------------------------
/// @file   set_pool.hpp
/// @brief  This file contains the implementation of set and multiset,
///         based on the vector_tree
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_SET_POOL_HPP
#define __COUNTERTREE_SET_POOL_HPP

#include <boost/cntree/set.hpp>
#include <boost/cntree/suballocator.hpp>
namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #               S E T _ P O O L                    #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  set_pool
/// @brief  This class have the same interface than the STL set,
///         plus access by position with the function at, and random access
///         iterators
/// @remarks
//----------------------------------------------------------------
template < class Key,
           class Comp = std::less<Key>,
           class Alloc = std::allocator<Key>
         >
class set_pool : public set <Key, Comp , suballocator <Alloc> >
{ public :

//-------------------------------------------------------------------------
//  function : set_pool
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//-------------------------------------------------------------------------
explicit set_pool(const Comp & C1=Comp(),const Alloc &A1=Alloc()) :
         set <Key,Comp,suballocator<Alloc> > (C1,suballocator<Alloc>()) {};

//----------------------------------------------------------------
//  function : set_pool
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template <class InputIterator>
set_pool ( InputIterator first,InputIterator last,const Comp& C1=Comp(),const Alloc &A1=Alloc()):
           set <Key, Comp , suballocator <Alloc> >( first,last,C1,suballocator<Alloc>() ){};

//----------------------------------------------------------------
//  function : set_pool
/// @brief  Copy constructor
/// @param [in] x : set from where copy the data
//----------------------------------------------------------------
set_pool ( const set <Key,Comp,suballocator<Alloc> > &x):set <Key,Comp,suballocator<Alloc> >(x){};

//----------------------------------------------------------------
//  function : ~set_pool
/// @brief  Destructor
//----------------------------------------------------------------
virtual ~set_pool (void){} ;


} ;


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #           M U L T I S E T _ P O O L              #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class multiset_pool
///
/// @remarks This class have the same interface than the STL multiset,
///  plus access by position with the function at, and random access
///  iterators
//----------------------------------------------------------------
template < class Key,
           class Comp = std::less<Key>,
           class Alloc = std::allocator<Key>
         >
class multiset_pool :public multiset<Key,Comp,suballocator<Alloc> >
{
public:
//----------------------------------------------------------------
//  function : multiset_pool
/// @brief Constructor of the class multiset
/// @param [in] C1 : object for comparison
/// @param [in] A1 : object for to allocate elements
//----------------------------------------------------------------
explicit multiset_pool(const Comp &C1=Comp(), const Alloc &A1=Alloc()):
         multiset<Key,Comp,suballocator<Alloc> >(C1,suballocator<Alloc>()) {};

//-------------------------------------------------------------------------
//  function : multiset_pool
/// @brief Constructor of the class multiset, with the insertion of a range
///        of elements between the iterators first and last
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : object for comparison
/// @param [in] A1 : object for to allocate elements
//--------------------------------------------------------------------------
template <class InputIterator>
multiset_pool(InputIterator first,InputIterator last,const Comp& C1=Comp(),const Alloc &A1=Alloc()):
              multiset<Key,Comp,suballocator<Alloc> >(first,last,C1,suballocator<Alloc> () ){} ;

//-----------------------------------------------------------------------
//  function : multiset_pool
/// @brief Constructor of the class multiset, copying the data from a set
/// @param [in] x : set from where insert the elements
//------------------------------------------------------------------------
multiset_pool ( const set<Key,Comp,Alloc >& x ):multiset<Key,Comp,suballocator<Alloc> >(x){};


//-----------------------------------------------------------------------
//  function : multiset_pool
/// @brief Constructor of the class multiset, copying the data from a set
/// @param [in] x : set from where insert the elements
//------------------------------------------------------------------------
multiset_pool ( const multiset<Key,Comp,Alloc >& x):multiset<Key,Comp,suballocator<Alloc> >(x){};

//----------------------------------------------------------------
//  function : ~multiset_pool
/// @brief destructor of the class multiset
//----------------------------------------------------------------
virtual ~multiset_pool (void){} ;


} ;

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################

#endif

