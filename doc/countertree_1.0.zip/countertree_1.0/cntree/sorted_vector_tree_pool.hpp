///----------------------------------------------------------------------------
// FILE : sorted_vector_tree_pool.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SORTED_VECTOR_TREE_POOL_HPP
#define __CNTREE_SORTED_VECTOR_TREE_POOL_HPP


#include <boost/cntree/sorted_vector_tree.hpp>
#include <boost/cntree/suballocator.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                   C L A S S                      #             ##
//       #                                                  #             ##
//       #  S O R T E D _ V E C T O R _ T R E E _ P O O L   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class  sorted_vector_tree_pool
/// @brief  This class is a vector_tree sorted, with all the
///         functions needed for manage the ordered information. \n
///         It has access by position and random access iterators
///         Due to this all the operations ( insert, delete, access)
///         a O( logN). \n
/// @param  value_t : value to store
/// @param  key_t : value used to compare
/// @param  filter_t Object used to obtain a key_t from a value_t
/// @param  comp_key_t : object used to compare two keys
/// @param  alloc_t : object used to allocate the nodes in the memory

/// @remarks
//----------------------------------------------------------------
template < typename value_t,
           typename key_t      = value_t,
           typename filter_t   = tree::filter_set<key_t,value_t>,
           typename comp_key_t = std::less<key_t>,
           typename alloc_t    = std::allocator<value_t>
        >
class sorted_vector_tree_pool
:public sorted_vector_tree <value_t,key_t,filter_t,comp_key_t,suballocator<alloc_t> >
{
public:

//------------------------------------------------------------------------
//  function : sorted_vector_tree_pool
/// @brief This function is teh construct of the class
/// @param [in] F1 : object filter_t
/// @param [in] C1 : object comp_key_t
/// @param [in] A : object alloc_t
/// @remarks
//------------------------------------------------------------------------
sorted_vector_tree_pool  (const filter_t &F1= filter_t(),
                          const comp_key_t& C1=comp_key_t(),
                          const alloc_t &ALLC=alloc_t() )    :
sorted_vector_tree <value_t,key_t,filter_t,comp_key_t,suballocator<alloc_t> > (F1,C1,suballocator<alloc_t>()){};

//------------------------------------------------------------------------
//  function : sorted_vector_tree_pool
/// @brief copy constructor
/// @param [in] ST : object to copy
//------------------------------------------------------------------------
sorted_vector_tree_pool (const sorted_vector_tree<value_t,key_t,filter_t,comp_key_t,suballocator<alloc_t> >& ST ):
                         sorted_vector_tree <value_t,key_t,filter_t,comp_key_t,suballocator<alloc_t> > (ST) { };

//------------------------------------------------------------------------
//  function : ~sorted_vector_tree_pool
/// @brief destructor of the class
/// @remarks This function is virtual
//------------------------------------------------------------------------
virtual ~sorted_vector_tree_pool (void){} ;
};


//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
