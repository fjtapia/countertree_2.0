//----------------------------------------------------------------------------
/// @file   vector_tree_pool.hpp
/// @brief  This file contains the implementation of the vector_tree
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_VECTOR_TREE_POOL_HPP
#define __CNTREE_VECTOR_TREE_POOL_HPP

#include <boost/cntree/vector_tree.hpp>
#include <boost/cntree/suballocator.hpp>


namespace cntree
{

//-------------------------------------------------------------
/// @class  vector_tree_pool
/// @brief  This class have the same interface than the STL vector,
///         but istead of be a vector is a tree. \n
///         Due to this all the operations ( insert, delete, access)
///         a O( logN). \n
//
/// @remarks
//----------------------------------------------------------------
template < typename value_t,typename alloc_t = std::allocator<value_t> >
class vector_tree_pool :public vector_tree <value_t, suballocator <alloc_t> >
{
public:

//----------------------------------------------------------------
//  function : vector_tree_pool
/// @brief  Constructor from an object Allocator
/// @param [in] A : Allocator
//----------------------------------------------------------------
vector_tree_pool ( const alloc_t &ALLC= alloc_t ()):vector_tree <value_t, suballocator <alloc_t> >() {};

//----------------------------------------------------------------
//  function : vector_tree_pool
/// @brief  Copy constructor
/// @param [in] VT : vector_tree from where copy the data
//----------------------------------------------------------------
vector_tree_pool ( const vector_tree<value_t, suballocator <alloc_t> > & VT ):
	                    vector_tree <value_t, suballocator <alloc_t> >(VT){};

//----------------------------------------------------------------
//  function : vector_tree_pool
/// @brief  Constructor from a value repeated a number of times and
///         an object Allocator
/// @param [in] n : Number of repetitions
/// @param [in] Val : Value to insert
/// @param [in] A : Allocator
//----------------------------------------------------------------
vector_tree_pool (tree::size_type n,const value_t & Val=value_t(),const alloc_t &A= std::allocator<value_t>()):
                  vector_tree <value_t, suballocator <alloc_t> > ( n,Val, suballocator<alloc_t> ()){};

//----------------------------------------------------------------
//  function : vector_tree_pool
/// @brief  Constructor from a pair of iterators and an object
///         Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template <class InputIterator>
vector_tree_pool ( InputIterator it_first ,  InputIterator it_last,
		          const alloc_t& A= std::allocator<value_t>()   ):
                  vector_tree <value_t, suballocator <alloc_t> >(it_first,it_last, suballocator<alloc_t> ()){};

//----------------------------------------------------------------
//  function : ~vector_tree_pool
/// @brief  Destructor
//----------------------------------------------------------------
virtual  ~vector_tree_pool (void){} ;

};


//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################


#endif
