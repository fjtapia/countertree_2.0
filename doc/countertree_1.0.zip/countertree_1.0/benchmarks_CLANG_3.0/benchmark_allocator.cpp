///----------------------------------------------------------------------------
// FILE : Benchmark_allocator.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the cntree::set, and std::multiset with cntree::multiset
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
//#define __CNTREE_MULTITHREAD 1
#define FSBALLOCATOR_USE_THREAD_SAFE_LOCKING_PTHREAD
#include <iostream>
#include <stdlib.h>
#include <set>
#include <time.h>

#include <ext/typelist.h>
#include <ext/array_allocator.h>
#include <ext/new_allocator.h>
#include <ext/malloc_allocator.h>
#include <ext/mt_allocator.h>
#include <ext/pool_allocator.h>
//#include <boost/countertree/set.hpp>
#include <FSBAllocator/FSBAllocator.hh>
#include <FSBAllocator/SmartPtr.hh>
#include <boost/cntree/suballocator.hpp>
//#include "tbb.h"
//#include "tbb_allocator.h"
//#include "scalable_allocator.h"
//#include "cache_aligned_allocator.h"
#include <boost/pool/pool_alloc.hpp>
//#include <boost/pool/details/mutex.hpp>
#define NELEM 50000000

using std::cout ;
using std::endl;
using std::cin ;


uint64_t * * K ;
template <typename  Alloc> void Prueba ( void ) ;
int  main ( void)
{   //---------------------- Variables----------------------------
    K = new uint64_t* [NELEM];

    //typedef __gnu_cxx::__common_pool_policy<__gnu_cxx::__pool, Thread> pool_policy;


    typedef std::allocator<uint64_t>                                     T1 ;
    typedef cntree::suballocator32< std::allocator<uint64_t> >           T2 ;


    typedef __gnu_cxx::malloc_allocator<uint64_t> 		                 T3;
    typedef cntree::suballocator<__gnu_cxx::malloc_allocator<uint64_t> > T4;

    typedef __gnu_cxx::__mt_alloc<uint64_t>          	                 T5;
    typedef cntree::suballocator<__gnu_cxx::__mt_alloc<uint64_t> >       T6;

    typedef __gnu_cxx::__pool_alloc<uint64_t> 		                     T7;
    typedef FSBAllocator<uint64_t>                                       T8 ;
    typedef boost::fast_pool_allocator<uint64_t>                         T9 ;

    //typedef tbb::tbb_allocator<uint64_t>                 T11 ;
    //typedef tbb::scalable_allocator<uint64_t>            T12 ;
    //typedef tbb::cache_aligned_allocator<uint64_t>       T13 ;

    //--------------------------------------------------------------
    //                  P R U E B A S
    //--------------------------------------------------------------
    uint32_t Option =0 ;

    cout<<"                 MENU   \n";
    cout<<"               ======== \n";
    cout<<"1.-std::allocator---------------------->\n";
    cout<<"2.-std::allocator + suballocator------->\n";
    cout<<"3.-malloc_allocator-------------------->\n";
    cout<<"4.-malloc_allocator + suballocator----->\n";
    cout<<"5.-mt_allocator------------------------>\n";
    cout<<"6.-mt_allocator + suballocator--------->\n";
    cout<<"7.-pool_allocator---------------------->\n";
    cout<<"8.-FSBAllocator------------------------>\n";
    cout<<"9.-boost::fast_pool_allocator --------->\n";
    cout<<"10.- EXIT\n\n";
    cout<<"Select Option ->";
    cin>>Option ;
    switch ( Option)
    {
    case 1: cout<<"1.-std::allocator---------------------->\n";
            Prueba<T1 > () ;
            break ;

    case 2: cout<<"2.-std::allocator + suballocator------->\n";
            Prueba<T2 > () ;
            break ;

    case 3: cout<<"3.-malloc_allocator-------------------->\n";
            Prueba<T3 > () ;
            break ;

    case 4: cout<<"4.-malloc_allocator + suballocator----->\n";
            Prueba<T4 > () ;
            break ;

    case 5: cout<<"5.-mt_allocator------------------------>\n";
            Prueba<T5 > () ;
            break;

    case 6: cout<<"6.-mt_allocator + suballocator---------->\n";
            Prueba<T6 > () ;
            break;

    case 7: cout<<"7.-pool_allocator---------------------->\n";
            Prueba<T7 > () ;
            break;

    case 8: cout<<"8.-FSBAllocator------------------------>\n";
            Prueba<T8 > () ;
            break;

    case 9: cout<<"9.-boost::fast_pool_allocator --------->\n";
            Prueba<T9 > () ;
            break;

    default: break;

    };
    delete [] K ;
    cout<<(system ( "ps -C benchmark_allocator -o size"));

    return 0 ;
};


template <typename  Alloc>
void Prueba ( void )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;
    Alloc  A  ;
    for (uint64_t i = 0 ; i < NELEM ; ++i)  K[i] = NULL ;
    //------------------------------------------------------------------
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
        A.construct (K[i], i) ;
    };
    cout<<(system ( "ps -C benchmark_allocator -o size"))<<endl;
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   if ( *(K[i] ) != i )
            std::cout<<"Error en "<<i<<std::endl;
        A.deallocate ( K[i],1);
    };
    cout<<(system ( "ps -C benchmark_allocator -o size"))<<endl;
    //------------------------------------------------------------------
    cout<<"Allocate of "<<NELEM<<" elements ------------>";
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    finish = clock() ;

    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   A.deallocate ( K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";

    //------------------------------------------------------------------

    //------------------------------------------------------------------
    cout<<"deallocate all from the first to the last -->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i++ )
    {   A.deallocate (K[i],1);
    };
    finish = clock() ;
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //----------------------------------------------------

    //------------------------------------------------------------------
    cout<<"deallocate all from the last to the first -->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 1 ; i <= NELEM ; i++ )
    {   A.deallocate (K[NELEM -i],1);
    };
    finish = clock() ;
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //----------------------------------------------------

    //----------------------------------------------------
    cout<<"deallocate odd elements -------------->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
    finish = clock() ;
    for (uint64_t i = 1 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //-------------------------------------------------------

    cout<<"deallocate odd elements and reallocate -------->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   K[i] = A.allocate (1);
    };
    finish = clock() ;
    for (uint64_t i = 1 ; i < NELEM ; i++ )
    {   A.deallocate (K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //-------------------------------------------------------
    //cout<<"---------------------------------------------------\n";
};

