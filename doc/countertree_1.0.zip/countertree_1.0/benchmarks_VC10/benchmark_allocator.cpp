///----------------------------------------------------------------------------
// FILE : benchmark_allocator.cpp
//
// DESCRIPTION : This program is for to compare the speed of the several
///              allocators
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
//#define __CNTREE_MULTITHREAD 1
//#define __DEBUG_HEAP_ALLOCATOR 1
//#define FSBALLOCATOR_USE_THREAD_SAFE_LOCKING_PTHREAD
#include <iostream>
#include <stdlib.h>
#include <set>
#include <time.h>


#include <boost/cntree/suballocator.hpp>
#include <boost/pool/pool_alloc.hpp>
#include <FSBAllocator/FSBAllocator.hh>
#include <FSBAllocator/SmartPtr.hh>

#define NELEM 50000000

using std::cout ;
using std::endl;
using std::cin ;


uint64_t * * K ;
template <typename  Alloc> void Prueba ( void ) ;

char comando[] = "tasklist /FI \"IMAGENAME eq benchmark_allocator.exe\" ";

int  main ( void)
{   //---------------------- Variables----------------------------
    K = new uint64_t* [NELEM];

    typedef std::allocator<uint64_t>                             T1 ;
    typedef cntree::suballocator< std::allocator<uint64_t> >     T2 ;
    typedef boost::fast_pool_allocator<uint64_t>                 T3 ;
    typedef FSBAllocator<uint64_t>                               T4 ;
    //--------------------------------------------------------------
    //                  P R U E B A S
    //--------------------------------------------------------------
    cout<<comando<<std::endl ;
    uint32_t Option =0 ;

    cout<<"                 MENU   \n";
    cout<<"               ======== \n";
    cout<<"1.-std::allocator----------------------------->\n";
    cout<<"2.-std::allocator + suballocator-------------->\n";
    cout<<"3.-boost::fast_pool_allocator ---------------->\n";
    cout<<"4.-FSB allocator ----------------------------->\n";
    cout<<"5.- EXIT\n\n";
    cout<<"Select Option ->";
    cin>>Option ;
    switch ( Option)
    {
    case 1: cout<<"std::allocator----------------------------------------------->\n";
            Prueba<T1 > () ;
            break ;

    case 2: cout<<"std::allocator + suballocator ------------------------------->\n";
            Prueba<T2 > () ;
            break;

    case 3: cout<<"boost::fast_pool_allocator------------------------------------>\n";
            Prueba<T3 > () ;
            break;

    case 4: cout<<"FSB allocator------------------------------------------------->\n";
            Prueba<T4 > () ;
            break;

    default: break;

    };
    delete [] K ;
    cout<<(system (comando))<<endl;
    return 0 ;
};


template <typename  Alloc>
void Prueba ( void )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;
    Alloc  A  ;
    for (uint64_t i = 0 ; i < NELEM ; ++i)  K[i] = NULL ;

    //------------------------------------------------------------------
    cout<<"Starting ------------>\n";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
        A.construct (K[i], i) ;
    };
    cout<<(system (comando))<<endl;
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   if ( *(K[i] ) != i )
            std::cout<<"Error en "<<i<<std::endl;
        A.deallocate ( K[i],1);
    };
    cout<<(system (comando))<<endl;

    //------------------------------------------------------------------
    cout<<"Allocate of "<<NELEM<<" elements ------------>";
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    finish = clock() ;
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   A.deallocate ( K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";

    //------------------------------------------------------------------

    //------------------------------------------------------------------
    cout<<"deallocate all from the first to the last -->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i++ )
    {   A.deallocate (K[i],1);
    };
    finish = clock() ;
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //----------------------------------------------------

    //------------------------------------------------------------------
    cout<<"deallocate all from the last to the first -->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 1 ; i <= NELEM ; i++ )
    {   A.deallocate (K[NELEM -i],1);
    };
    finish = clock() ;
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //----------------------------------------------------

    //----------------------------------------------------
    cout<<"deallocate odd elements -------------->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
    finish = clock() ;
    for (uint64_t i = 1 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    //-------------------------------------------------------

    cout<<"deallocate odd elements and reallocate -------->";
    for (uint64_t i = 0 ; i < NELEM ; ++i )
    {   K[i] = A.allocate (1);
    };
    start = clock();
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   A.deallocate (K[i],1);
    };
    for (uint64_t i = 0 ; i < NELEM ; i+= 2 )
    {   K[i] = A.allocate (1);
    };
    finish = clock() ;
    for (uint64_t i = 1 ; i < NELEM ; i++ )
    {   A.deallocate (K[i],1);
    };
	duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";

    //-------------------------------------------------------
    cout<<"---------------------------------------------------\n";
};

