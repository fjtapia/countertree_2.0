﻿///----------------------------------------------------------------------------
// FILE : benchmark_set_allocator.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the cntree::set, and std::multiset with cntree::multiset
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <iostream>
#include <stdlib.h>
#include <memory>
#include <set>
#include <time.h>

#include <boost/cntree/set_pool.hpp>
#include <boost/cntree/suballocator.hpp>
#include <boost/pool/pool_alloc.hpp>
#include <FSBAllocator/FSBAllocator.hh>
#include <FSBAllocator/SmartPtr.hh>

#define NELEM 30000000

using std::cout ;
using std::endl;
char comando[] = "tasklist /FI \"IMAGENAME eq benchmark_set_allocator.exe\" ";
uint64_t A[NELEM];
template <typename  Alloc> void Prueba ( void ) ;

template <typename  Alloc> int Conjunto ( void ) ;

int  main ( void)
{   //---------------------- Variables----------------------------
    typedef std::allocator<uint64_t>                            T1 ;
    typedef cntree::suballocator <std::allocator<uint64_t> >    T2 ;
    typedef boost::fast_pool_allocator<uint64_t>                T3 ;
    typedef FSBAllocator<uint64_t>                              T4 ;

    //--------------------------------------------------------------
    //                  P R U E B A S
    //--------------------------------------------------------------
    uint32_t Option =0 ;
    cout<<"                 MENU   \n";
    cout<<"               ======== \n";
    cout<<"1.-std::allocator--------------------------->\n";
    cout<<"2.-std::allocator + suballocator------------>\n";
    cout<<"3.-boost::fast_pool_allocator--------------->\n";
    cout<<"4.-FSBAllocator----------------------------->\n";
    cout<<"5.- EXIT\n\n";
    cout<<"Select Option ->";
    std::cin>>Option ;
    switch ( Option)
    {   case 1 :    cout<<"std::allocator-------------------------------------------->\n";
                    Conjunto<T1 > () ;
                    break ;

         case 2 :   cout<<"std::allocator + SubAllocator ---------------------------------->\n";
                    Conjunto<T2 > () ;
                    break;

        case 3 :    cout<<"fast_pool_allocator -------------------------------------------->\n";
                    Conjunto<T3 > () ;
                    break ;

        case 4 :    cout<<"FSBAllocator-------------------------------------------->\n";
                    Conjunto<T4 > () ;
                    break;

        default : break ;
    };

    return 0 ;

};
template <typename  Alloc>
int  Conjunto ( void)
{   //---------------------- Variables----------------------------
    uint32_t Option =0 ;
    cout<<"\n\n\n\n";
    cout<<"         SELECCIONE ESTRUCTURA  \n";
    cout<<"      ============================== \n";
    cout<<"1.-std::set -------------------->\n";
    cout<<"2.-std::multiset---------------->\n";
    cout<<"3.-cntree::set ----------------->\n";
    cout<<"4.-cntree::multiset------------->\n";
    cout<<"5.- EXIT\n\n";
    cout<<"Select Option ->";
    std::cin>>Option ;
    switch ( Option)
    {   case 1 :    cout<<"std::set-------------------------------------------->\n";
                    Muestreo<std::set<uint64_t,std::less<uint64_t>,Alloc> > () ;
                    break ;

        case 2 :    cout<<"std::multiset-------------------------------------------->\n";
                    Muestreo<std::multiset<uint64_t,std::less<uint64_t>,Alloc> > () ;
                    break ;

        case 3 :    cout<<"cntree::set-------------------------------------------->\n";
                    Muestreo<cntree::set<uint64_t,std::less<uint64_t>,Alloc> > () ;
                    break;

        case 4 :    cout<<"cntree::multiset-------------------------------------------->\n";
                    Muestreo<cntree::multiset<uint64_t,std::less<uint64_t>,Alloc> > () ;
                    break;

        default :   std::cout<<"error en la seleccion de estructura --->\n";
    };
    return 0 ;
};


template <class Structure>
void Muestreo ( void)
{   //------------------------ Inicio -----------------------------
    Structure S ;
    int i ;
    //------------------------ Inicio -----------------------------
    for (  i = 0 ; i < NELEM; i ++ )
    {    S.insert( i);
    };
    cout<<(system ( comando))<<endl;
    S.clear();

    cout<<"----------Insertion of "<< NELEM<<" elements---------\n" ;
    cout<<"Many elements , sorted elements\n";
    for ( i = 0 ; i < NELEM ; i ++) A[i] = NELEM +i ;
    Prueba<Structure>( S ) ;

    cout<<"Many elements , few repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ( (rand()%65000) *(rand() %65000) + (rand()%65000)) ;
    Prueba<Structure>( S ) ;

    cout<<"Many elements , quite repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ((rand()%65000)  *(rand() %65000) + (rand()%65000))  % (NELEM/2);
    Prueba<Structure>( S ) ;

    cout<<"Many element many repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] =  rand() %10000;
    Prueba<Structure>( S ) ;

    cout<<"Equal elements\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = NELEM;
    Prueba<Structure>( S ) ;
    cout<<(system ( comando))<<endl;
};

template <typename  Structure>
void Prueba ( Structure & S )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;
    int i;

    start = clock();
    for ( i = 0 ; i < NELEM; i ++ )
    {    S.insert( A[i] );
    };
    finish = clock() ;
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    S.clear() ;

    cout<<"---------------------------------------------------\n";
};

